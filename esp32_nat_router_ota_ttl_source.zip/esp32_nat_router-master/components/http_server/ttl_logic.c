/* SPDX-License-Identifier: MIT */
#include "ttl_logic.h"

#include <string.h>

/* Find "key=" in an urlencoded string and copy its value (up to '&').
 * Returns false if the key is absent or the value does not fit. */
static bool qs_get(const char *qs, const char *key, char *out, size_t out_len)
{
    size_t klen = strlen(key);
    const char *p = qs;

    while (*p) {
        const char *end = strchr(p, '&');
        size_t seg = end ? (size_t)(end - p) : strlen(p);

        if (seg > klen && strncmp(p, key, klen) == 0 && p[klen] == '=') {
            size_t vlen = seg - klen - 1;
            if (vlen >= out_len) {
                return false;
            }
            memcpy(out, p + klen + 1, vlen);
            out[vlen] = '\0';
            return true;
        }
        if (!end) {
            break;
        }
        p = end + 1;
    }
    return false;
}

/* Strict 1-3 digit decimal parse, range-checked. */
static bool parse_ttl_value(const char *s, int *out)
{
    size_t n = strlen(s);
    if (n < 1 || n > 3) {
        return false;
    }
    int v = 0;
    for (size_t i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
        v = v * 10 + (s[i] - '0');
    }
    if (v < TTL_MIN_VALUE || v > TTL_MAX_VALUE) {
        return false;
    }
    *out = v;
    return true;
}

ttl_err_t ttl_parse_request(const char *body, ttl_req_t *out)
{
    char tmp[16];

    if (!body || !out) {
        return TTL_ERR_ACTION;
    }
    memset(out, 0, sizeof(*out));

    if (!qs_get(body, "action", tmp, sizeof(tmp))) {
        return TTL_ERR_ACTION;
    }
    if (strcmp(tmp, "save") == 0) {
        out->action = TTL_ACT_SAVE;
    } else if (strcmp(tmp, "apply") == 0) {
        out->action = TTL_ACT_APPLY;
    } else {
        return TTL_ERR_ACTION;
    }

    if (!qs_get(body, "enabled", tmp, sizeof(tmp))) {
        return TTL_ERR_ENABLED;
    }
    if (strcmp(tmp, "1") == 0) {
        out->enabled = true;
    } else if (strcmp(tmp, "0") == 0) {
        out->enabled = false;
    } else {
        return TTL_ERR_ENABLED;
    }

    if (qs_get(body, "value", tmp, sizeof(tmp))) {
        int v;
        if (!parse_ttl_value(tmp, &v)) {
            return TTL_ERR_VALUE;
        }
        out->has_value = true;
        out->value = v;
    }
    if (out->enabled && !out->has_value) {
        return TTL_ERR_VALUE;
    }
    return TTL_OK;
}

int ttl_effective_value(const ttl_req_t *req)
{
    return (req && req->enabled && req->has_value) ? req->value : 0;
}

int ttl_display_value(int saved, int last)
{
    if (saved >= TTL_MIN_VALUE && saved <= TTL_MAX_VALUE) {
        return saved;
    }
    if (last >= TTL_MIN_VALUE && last <= TTL_MAX_VALUE) {
        return last;
    }
    return TTL_DEFAULT_VALUE;
}

const char *ttl_err_msg(ttl_err_t err)
{
    switch (err) {
    case TTL_OK:          return "ok";
    case TTL_ERR_ACTION:  return "action must be save or apply";
    case TTL_ERR_ENABLED: return "enabled must be 0 or 1";
    case TTL_ERR_VALUE:   return "TTL must be a number from 1 to 255";
    }
    return "invalid request";
}
