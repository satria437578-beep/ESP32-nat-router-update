/* Pure-C helpers for the Web UI TTL rewrite endpoint (/api/ttl).
 * No ESP-IDF dependencies so they can be unit-tested on the host
 * (see tests/host).
 *
 * SPDX-License-Identifier: MIT
 */
#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TTL_MIN_VALUE      1
#define TTL_MAX_VALUE      255
#define TTL_DEFAULT_VALUE  64

typedef enum {
    TTL_ACT_SAVE = 0,   /* persist to NVS only (active after Apply/reboot) */
    TTL_ACT_APPLY = 1,  /* persist to NVS and activate immediately */
} ttl_action_t;

typedef struct {
    ttl_action_t action;
    bool enabled;
    bool has_value;
    int  value;         /* valid only if has_value */
} ttl_req_t;

typedef enum {
    TTL_OK = 0,
    TTL_ERR_ACTION,
    TTL_ERR_ENABLED,
    TTL_ERR_VALUE,
} ttl_err_t;

/* Parse an application/x-www-form-urlencoded body:
 *   action=save|apply & enabled=0|1 & value=1..255
 * "value" is mandatory when enabled=1, optional (remembered) when enabled=0. */
ttl_err_t ttl_parse_request(const char *body, ttl_req_t *out);

/* Value written to NVS key "sta_ttl" / used by the packet path (0 = off). */
int ttl_effective_value(const ttl_req_t *req);

/* Value to show in the number box: the active/saved TTL if enabled,
 * otherwise the last remembered one, otherwise 64. */
int ttl_display_value(int saved, int last);

const char *ttl_err_msg(ttl_err_t err);

#ifdef __cplusplus
}
#endif
