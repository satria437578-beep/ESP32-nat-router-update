/* Web interface (HTTP server)
 *
 * Pages:
 *   /          - Status dashboard: connection state, clients, heap, uptime, login
 *   /config    - Router configuration: AP/STA settings, static IP, MAC addresses
 *   /mappings  - DHCP reservations and port forwarding management
 *   /firewall  - ACL firewall rules (4 lists, add/delete, hit statistics)
 *   /vpn       - WireGuard VPN configuration and status
 *   /scan      - WiFi network scanner (STA uplink only)
 *
 * Password-protected pages use cookie-based sessions (30-min timeout).
 * HTML templates are defined in pages.h as C macro strings.
 */
#include <stdlib.h>
#include <string.h>
#include "driver/gpio.h"
#include "esp_netif.h"
#include "lwip/ip_addr.h"
#include "lwip/inet.h"

#include <esp_wifi.h>
#include <esp_event.h>
#include <esp_log.h>
#include <esp_system.h>
#include <esp_timer.h>
#include <sys/param.h>
#include "nvs_flash.h"
#include "esp_netif.h"
//#include "esp_eth.h"
//#include "protocol_examples_common.h"

#include <esp_http_server.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "lwip/lwip_napt.h"
#include "lwip/sockets.h"

#include "pages.h"
#include "favicon_png.h"
#include "router_globals.h"
#include "vpn_config.h"
#include "pcap_capture.h"
#include "acl.h"
#include "remote_console.h"
#include "cJSON.h"
#include "esp_ota_ops.h"
#include "ota_manager.h"
#include "ota_validate.h"
#include "ttl_logic.h"
#include "esp_app_format.h"
#include "esp_app_desc.h"
#include "esp_chip_info.h"
#include "mbedtls/pkcs5.h"
#include "mbedtls/md.h"
#include "mbedtls/base64.h"

static const char *TAG = "HTTPServer";

/* Stream one HTTP chunk and abort the handler immediately if the send fails.
 *
 * httpd_resp_send_chunk() blocks up to config.send_wait_timeout when the client
 * is gone or its TCP window is full.  The page handlers issue dozens of chunks
 * in sequence; without checking the result, a dead client makes the handler
 * spin through every remaining chunk (one timeout each), wedging the single
 * httpd worker and pinning that connection's buffers/socket.
 *
 * Returning ESP_FAIL on the first failed chunk lets httpd tear the connection
 * down at once.  Handlers that stream with SEND_CHUNK must NOT hold a heap
 * allocation across the chunk loop: a bail-out returns immediately and would
 * leak it.  Render from a stack buffer, or free before streaming begins. */
#define SEND_CHUNK(req, ...) \
    do { \
        if (httpd_resp_send_chunk((req), __VA_ARGS__) != ESP_OK) { \
            return ESP_FAIL; \
        } \
    } while (0)

/* Escape src into a fixed stack buffer (truncating if needed) and free the
 * heap copy from html_escape().  Page handlers use this so they never hold an
 * html_escape() allocation across a chunked SEND_CHUNK render. */
char* html_escape(const char* src);
static void html_escape_to(char *dst, size_t dst_len, const char *src)
{
    char *e = html_escape(src ? src : "");
    strlcpy(dst, e ? e : "", dst_len);
    free(e);
}

/* Get client IP address string from HTTP request */
static const char *get_client_ip(httpd_req_t *req, char *buf, size_t buf_len)
{
    int sockfd = httpd_req_to_sockfd(req);
    struct sockaddr_in6 addr6;
    socklen_t addr_len = sizeof(addr6);
    if (getpeername(sockfd, (struct sockaddr *)&addr6, &addr_len) == 0) {
        /* ESP-IDF httpd uses IPv6 sockets; IPv4 clients appear as
         * ::ffff:x.x.x.x (IPv4-mapped IPv6).  Extract the IPv4 part. */
        if (addr6.sin6_family == AF_INET6) {
            struct in_addr ipv4;
            memcpy(&ipv4, addr6.sin6_addr.s6_addr + 12, 4);
            inet_ntoa_r(ipv4, buf, buf_len);
        } else {
            struct sockaddr_in *addr4 = (struct sockaddr_in *)&addr6;
            inet_ntoa_r(addr4->sin_addr, buf, buf_len);
        }
    } else {
        strncpy(buf, "unknown", buf_len);
    }
    return buf;
}

/* Web UI interface access bitmask (RC_BIND_AP, RC_BIND_STA, RC_BIND_VPN).
 * Loaded from NVS in start_webserver(). Default: all interfaces allowed. */
static uint8_t s_web_bind = RC_BIND_AP | RC_BIND_STA | RC_BIND_VPN;

/* Check whether an incoming HTTP connection is allowed based on which
 * network interface it arrived on.  Called by esp_http_server before any
 * data is exchanged; returning ESP_FAIL closes the socket immediately.
 *
 * getsockname() on the accepted socket returns the local IP that was used
 * by the client — i.e. the address of the interface the packet arrived on.
 * esp_http_server uses IPv6 sockets, so IPv4 connections appear as
 * ::ffff:x.x.x.x (IPv4-mapped).  The same extraction used in get_client_ip()
 * is applied here for the local side.
 */
static esp_err_t http_open_fn(httpd_handle_t hd, int sockfd)
{
    /* Enable TCP keepalive on every accepted connection.  A client that leaves
     * WiFi without closing leaves the socket in ESTABLISHED forever; without
     * probes lwIP never notices and the socket (and its few KB of buffers) leaks
     * until the table fills.  With keepalive the dead peer is detected and the
     * socket torn down automatically.  ~30 s idle, then 3 probes 5 s apart. */
    int ka = 1, ka_idle = 30, ka_intvl = 5, ka_cnt = 3;
    setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, &ka, sizeof(ka));
    setsockopt(sockfd, IPPROTO_TCP, TCP_KEEPIDLE, &ka_idle, sizeof(ka_idle));
    setsockopt(sockfd, IPPROTO_TCP, TCP_KEEPINTVL, &ka_intvl, sizeof(ka_intvl));
    setsockopt(sockfd, IPPROTO_TCP, TCP_KEEPCNT, &ka_cnt, sizeof(ka_cnt));

    struct sockaddr_in6 local_addr6;
    socklen_t addr_len = sizeof(local_addr6);
    uint32_t local_ip = 0;  /* network byte order */

    if (getsockname(sockfd, (struct sockaddr *)&local_addr6, &addr_len) == 0) {
        if (local_addr6.sin6_family == AF_INET6) {
            /* IPv4-mapped IPv6: last 4 bytes of s6_addr are the IPv4 address */
            memcpy(&local_ip, local_addr6.sin6_addr.s6_addr + 12, 4);
        } else {
            local_ip = ((struct sockaddr_in *)&local_addr6)->sin_addr.s_addr;
        }
    }

    /* Identify which interface the connection arrived on */
    bool on_ap  = (local_ip != 0 && local_ip == my_ap_ip);
    bool on_sta = (local_ip != 0 && local_ip == my_ip);
    bool on_vpn = false;
    if (local_ip != 0 && vpn_connected && vpn_address && vpn_address[0]) {
        ip4_addr_t vpn_addr;
        if (ip4addr_aton(vpn_address, &vpn_addr) && local_ip == vpn_addr.addr) {
            on_vpn = true;
        }
    }

    /* Enforce interface access policy */
    bool allowed = false;
    if (on_ap  && (s_web_bind & RC_BIND_AP))  allowed = true;
    if (on_sta && (s_web_bind & RC_BIND_STA)) allowed = true;
    if (on_vpn && (s_web_bind & RC_BIND_VPN)) allowed = true;

    /* An unknown local address used to be allowed through, which turned the
     * whole interface restriction into a suggestion. getsockname() does not
     * fail on an accepted socket in practice; if it ever does, refusing is the
     * only answer that keeps the setting meaningful. Serial console recovery
     * (web_ui bind all) is documented for the lockout case either way. */
    if (local_ip == 0) {
        ESP_LOGW(TAG, "HTTP connection rejected (local address unknown)");
        return ESP_FAIL;
    }

    if (!allowed) {
        ESP_LOGW(TAG, "HTTP connection rejected (interface not allowed, local=" IPSTR ")",
                 IP2STR((ip4_addr_t *)&local_ip));
        return ESP_FAIL;
    }

    return ESP_OK;
}

static void web_server_start_captive_dns(void);

esp_timer_handle_t restart_timer;

/* Session management for password protection */
#define MAX_SESSION_TOKEN_LEN 32
#define SESSION_TIMEOUT_US (30 * 60 * 1000000LL) // 30 minutes

static char current_session_token[MAX_SESSION_TOKEN_LEN + 1] = {0};
static bool session_active = false;
static int64_t session_expiry_time = 0;

static void restart_timer_callback(void* arg)
{
    ESP_LOGI(TAG, "Restarting now...");
    esp_restart();
}

esp_timer_create_args_t restart_timer_args = {
        .callback = &restart_timer_callback,
        /* argument specified here will be passed to timer callback function */
        .arg = (void*) 0,
        .name = "restart_timer"
};

/* Session management helper functions */

/* Generate random session token */
static void generate_session_token(char* token_out, size_t len)
{
    const char hex_chars[] = "0123456789abcdef";
    for (size_t i = 0; i < len - 1; i++) {
        token_out[i] = hex_chars[esp_random() % 16];
    }
    token_out[len - 1] = '\0';
}

/* Clear session state */
static void clear_session(void)
{
    session_active = false;
    current_session_token[0] = '\0';
    session_expiry_time = 0;
}

/* Password checking uses shared functions from router_globals.h:
 * is_web_password_set(), verify_web_password(), set_web_password_hashed() */

/* Extract cookie value from request headers */
static bool get_cookie_value(httpd_req_t *req, const char* cookie_name,
                              char* value_out, size_t max_len)
{
    size_t cookie_header_len = httpd_req_get_hdr_value_len(req, "Cookie");
    if (cookie_header_len == 0) {
        return false;
    }

    char* cookie_header = malloc(cookie_header_len + 1);
    if (cookie_header == NULL) {
        return false;
    }

    if (httpd_req_get_hdr_value_str(req, "Cookie", cookie_header, cookie_header_len + 1) != ESP_OK) {
        free(cookie_header);
        return false;
    }

    /* Match the name only at a cookie boundary — a plain strstr() for
     * "session=" also matches a cookie called "xsession", letting a caller
     * supply the value the check is meant to verify. */
    char search_pattern[64];
    snprintf(search_pattern, sizeof(search_pattern), "%s=", cookie_name);
    size_t pattern_len = strlen(search_pattern);

    char* cookie_start = NULL;
    for (char* p = cookie_header; (p = strstr(p, search_pattern)) != NULL; p += pattern_len) {
        bool at_boundary = (p == cookie_header) ||
                           (p[-1] == ';') ||
                           (p[-1] == ' ' && p >= cookie_header + 2 && p[-2] == ';');
        if (at_boundary) {
            cookie_start = p + pattern_len;
            break;
        }
    }

    if (cookie_start == NULL) {
        free(cookie_header);
        return false;
    }

    // Find the end of the cookie value (semicolon or end of string)
    char* cookie_end = strchr(cookie_start, ';');
    size_t cookie_len = cookie_end ? (size_t)(cookie_end - cookie_start) : strlen(cookie_start);

    if (cookie_len >= max_len) {
        cookie_len = max_len - 1;
    }

    strncpy(value_out, cookie_start, cookie_len);
    value_out[cookie_len] = '\0';

    free(cookie_header);
    return true;
}

/* Check if request has valid session cookie */
/* CSRF check: if the browser sends an Origin header it must match one of our
 * own IP addresses (AP or STA).  Requests without Origin (curl, API clients)
 * are allowed through.
 * Returns true if the request is safe to process. */
static bool check_csrf(httpd_req_t *req)
{
    char origin[64];
    if (httpd_req_get_hdr_value_str(req, "Origin", origin, sizeof(origin)) != ESP_OK) {
        return true;  /* No Origin — non-browser or same-origin fetch, allow */
    }
    /* Same-origin check: the Origin host[:port] must equal the Host header the
     * browser used to reach us. This covers access by mDNS hostname
     * (e.g. http://esp32.local) or a non-default port, which the IP checks below
     * would miss. A cross-site attacker's Origin won't match our Host, so it's
     * still rejected. */
    char host[64];
    if (httpd_req_get_hdr_value_str(req, "Host", host, sizeof(host)) == ESP_OK) {
        char expected_host[72];
        snprintf(expected_host, sizeof(expected_host), "http://%s", host);
        if (strcmp(origin, expected_host) == 0) return true;
    }

    char expected[32];
    ip4_addr_t addr;

    /* Accept requests originating from the AP interface */
    addr.addr = my_ap_ip;
    snprintf(expected, sizeof(expected), "http://" IPSTR, IP2STR(&addr));
    if (strcmp(origin, expected) == 0) return true;

    /* Also accept requests originating from the STA interface */
    if (my_ip != 0) {
        addr.addr = my_ip;
        snprintf(expected, sizeof(expected), "http://" IPSTR, IP2STR(&addr));
        if (strcmp(origin, expected) == 0) return true;
    }

    /* Also accept requests originating from the VPN/WireGuard interface */
    if (vpn_tunnel_ip != 0) {
        addr.addr = vpn_tunnel_ip;
        snprintf(expected, sizeof(expected), "http://" IPSTR, IP2STR(&addr));
        if (strcmp(origin, expected) == 0) return true;
    }

    return false;
}

/* Check if request has valid session cookie */
static bool is_authenticated(httpd_req_t *req)
{
    // If no session is active, not authenticated
    if (!session_active) {
        return false;
    }

    // Check if session has expired
    int64_t current_time = esp_timer_get_time();
    if (current_time > session_expiry_time) {
        clear_session();
        return false;
    }

    // Extract session cookie
    char session_token[MAX_SESSION_TOKEN_LEN + 1];
    if (!get_cookie_value(req, "session", session_token, sizeof(session_token))) {
        return false;
    }

    /* Constant-time compare: strcmp() returns as soon as two bytes differ, so
     * response timing leaks how much of the token a guess got right. */
    size_t expected_len = strlen(current_session_token);
    if (strlen(session_token) != expected_len) {
        return false;
    }
    uint8_t diff = 0;
    for (size_t i = 0; i < expected_len; i++) {
        diff |= (uint8_t)(session_token[i] ^ current_session_token[i]);
    }
    if (diff != 0) {
        return false;
    }

    // Extend session expiry on successful auth
    session_expiry_time = current_time + SESSION_TIMEOUT_US;

    return true;
}

/* Cookie header buffer - must be static because httpd_resp_set_hdr stores pointer, not copy */
static char session_cookie_header[128];

/* Create new session and set cookie */
static esp_err_t create_session(httpd_req_t *req)
{
    // Generate new session token
    generate_session_token(current_session_token, sizeof(current_session_token));

    // Set session active and expiry
    session_active = true;
    session_expiry_time = esp_timer_get_time() + SESSION_TIMEOUT_US;

    // Set cookie in response (using static buffer because httpd stores pointer)
    /* Max-Age makes this a persistent cookie (matching SESSION_TIMEOUT_US) so it
     * survives page reloads and the iOS captive-portal browser, which discards
     * session-only cookies aggressively. */
    /* HttpOnly keeps the token out of document.cookie, so an XSS bug on any
     * page cannot hand the session to an attacker. Nothing here reads the
     * cookie from JavaScript. */
    snprintf(session_cookie_header, sizeof(session_cookie_header),
             "session=%s; Path=/; Max-Age=1800; SameSite=Strict; HttpOnly", current_session_token);
    httpd_resp_set_hdr(req, "Set-Cookie", session_cookie_header);

    ESP_LOGI(TAG, "Session created, expires in 30 minutes");
    return ESP_OK;
}

/* --- Config Export/Import helpers --- */

/*
 * Encrypted config file format (JSON envelope):
 *   {"enc":1,"s":"<hex 16-byte salt>","n":"<hex 24-byte nonce>","c":"<base64 ciphertext>"}
 *
 * Key derivation : PBKDF2-HMAC-SHA256, 10 000 iterations, 32-byte output
 * Encryption     : XChaCha20-Poly1305 AEAD (24-byte nonce, 16-byte auth tag)
 *
 * The XChaCha20-Poly1305 implementation is the one bundled with the WireGuard
 * managed component; the symbols are already compiled into the binary.
 */

/* Forward-declare XChaCha20-Poly1305 from managed_components/esp_wireguard */
extern void xchacha20poly1305_encrypt(uint8_t *dst, const uint8_t *src, size_t src_len,
                                      const uint8_t *ad, size_t ad_len,
                                      const uint8_t *nonce, const uint8_t *key);
extern bool xchacha20poly1305_decrypt(uint8_t *dst, const uint8_t *src, size_t src_len,
                                      const uint8_t *ad, size_t ad_len,
                                      const uint8_t *nonce, const uint8_t *key);

#define ENC_SALT_LEN    16
#define ENC_NONCE_LEN   24
#define ENC_KEY_LEN     32
#define ENC_TAG_LEN     16
#define ENC_PBKDF2_ITER 10000

/* Encrypted payload is larger than the raw JSON: base64(plaintext + 16 tag)
 * plus the JSON envelope headers (~100 bytes).
 * Max plaintext 8 192 B → cipher 8 208 B → base64 ~10 944 B → total ~11 100 B.
 * Use 16 384 as the import limit to cover both plain and encrypted files. */
#define CONFIG_IMPORT_MAX_SIZE 16384

static char *bytes_to_hex(const uint8_t *src, size_t len)
{
    char *hex = malloc(len * 2 + 1);
    if (!hex) return NULL;
    for (size_t i = 0; i < len; i++) {
        sprintf(hex + i * 2, "%02x", src[i]);
    }
    hex[len * 2] = '\0';
    return hex;
}

static int hex_to_bytes(const char *src, uint8_t *dst, size_t len)
{
    for (size_t i = 0; i < len; i++) {
        unsigned int byte;
        if (sscanf(src + i * 2, "%2x", &byte) != 1) return -1;
        dst[i] = (uint8_t)byte;
    }
    return 0;
}

/* Derive a 32-byte key from passphrase + salt using PBKDF2-HMAC-SHA256. */
static void config_derive_key(const char *pass, const uint8_t *salt, uint8_t key[ENC_KEY_LEN])
{
    mbedtls_pkcs5_pbkdf2_hmac_ext(MBEDTLS_MD_SHA256,
                                  (const uint8_t *)pass, strlen(pass),
                                  salt, ENC_SALT_LEN,
                                  ENC_PBKDF2_ITER,
                                  ENC_KEY_LEN, key);
}

/*
 * Encrypt plain JSON string with the given passphrase.
 * Returns a malloc'd JSON envelope string, or NULL on allocation failure.
 */
/*
 * Encrypt plaintext JSON into a JSON envelope.
 * Takes ownership of `plain` (frees it) to reduce peak heap usage —
 * the caller must NOT free plain after this call.
 */
static char *config_encrypt_json(char *plain, size_t plain_len, const char *pass)
{
    uint8_t salt[ENC_SALT_LEN], nonce[ENC_NONCE_LEN], key[ENC_KEY_LEN];
    esp_fill_random(salt, sizeof(salt));
    esp_fill_random(nonce, sizeof(nonce));
    config_derive_key(pass, salt, key);

    size_t cipher_len = plain_len + ENC_TAG_LEN;
    uint8_t *cipher = malloc(cipher_len);
    if (!cipher) { free(plain); return NULL; }
    xchacha20poly1305_encrypt(cipher, (const uint8_t *)plain, plain_len,
                              NULL, 0, nonce, key);
    free(plain); /* Release early — no longer needed after encryption */

    /* Hex-encode salt and nonce */
    char salt_hex[ENC_SALT_LEN * 2 + 1];
    char nonce_hex[ENC_NONCE_LEN * 2 + 1];
    for (int i = 0; i < ENC_SALT_LEN; i++)  sprintf(salt_hex  + i*2, "%02x", salt[i]);
    for (int i = 0; i < ENC_NONCE_LEN; i++) sprintf(nonce_hex + i*2, "%02x", nonce[i]);
    salt_hex[ENC_SALT_LEN * 2]   = '\0';
    nonce_hex[ENC_NONCE_LEN * 2] = '\0';

    /* Query base64 output size (b64_needed includes trailing NUL) */
    size_t b64_needed = 0;
    mbedtls_base64_encode(NULL, 0, &b64_needed, cipher, cipher_len);
    size_t b64_str_len = b64_needed > 0 ? b64_needed - 1 : 0;

    /* Build JSON prefix and suffix so we can base64-encode directly into
     * the output buffer, avoiding a separate b64 allocation. */
    size_t pre_len = (size_t)snprintf(NULL, 0,
                        "{\"enc\":1,\"s\":\"%s\",\"n\":\"%s\",\"c\":\"",
                        salt_hex, nonce_hex);
    size_t out_len = pre_len + b64_str_len + 2 + 1; /* 2 for "}, 1 for NUL */
    char *out = malloc(out_len);
    if (!out) { free(cipher); return NULL; }

    /* Write JSON prefix */
    snprintf(out, pre_len + 1,
             "{\"enc\":1,\"s\":\"%s\",\"n\":\"%s\",\"c\":\"",
             salt_hex, nonce_hex);

    /* Base64-encode ciphertext directly into the output buffer */
    size_t b64_written = 0;
    mbedtls_base64_encode((unsigned char *)(out + pre_len),
                          out_len - pre_len, &b64_written,
                          cipher, cipher_len);
    free(cipher);

    /* Close the JSON envelope (overwrite the base64 NUL terminator) */
    memcpy(out + pre_len + b64_written, "\"}", 3); /* includes NUL */
    return out;
}

/*
 * Decrypt an envelope produced by config_encrypt_json().
 * Returns a malloc'd null-terminated plaintext string, or NULL on failure
 * (wrong passphrase or corrupt data → authentication tag mismatch).
 */
static char *config_decrypt_json(const char *enc_json, const char *pass)
{
    cJSON *j = cJSON_Parse(enc_json);
    if (!j) return NULL;

    cJSON *s_item = cJSON_GetObjectItem(j, "s");
    cJSON *n_item = cJSON_GetObjectItem(j, "n");
    cJSON *c_item = cJSON_GetObjectItem(j, "c");
    if (!cJSON_IsString(s_item) || !cJSON_IsString(n_item) || !cJSON_IsString(c_item)) {
        cJSON_Delete(j); return NULL;
    }

    uint8_t salt[ENC_SALT_LEN], nonce[ENC_NONCE_LEN];
    if (hex_to_bytes(s_item->valuestring, salt,  ENC_SALT_LEN)  != 0 ||
        hex_to_bytes(n_item->valuestring, nonce, ENC_NONCE_LEN) != 0) {
        cJSON_Delete(j); return NULL;
    }

    /* Base64-decode ciphertext */
    size_t b64_in_len = strlen(c_item->valuestring);
    size_t cipher_len = 0;
    mbedtls_base64_decode(NULL, 0, &cipher_len,
                          (const unsigned char *)c_item->valuestring, b64_in_len);
    uint8_t *cipher = malloc(cipher_len);
    if (!cipher) { cJSON_Delete(j); return NULL; }
    size_t actual_cipher_len = 0;
    int rc = mbedtls_base64_decode(cipher, cipher_len, &actual_cipher_len,
                                   (const unsigned char *)c_item->valuestring, b64_in_len);
    cJSON_Delete(j);
    if (rc != 0 || actual_cipher_len < ENC_TAG_LEN) { free(cipher); return NULL; }

    uint8_t key[ENC_KEY_LEN];
    config_derive_key(pass, salt, key);

    size_t plain_len = actual_cipher_len - ENC_TAG_LEN;
    uint8_t *plain = malloc(plain_len + 1);
    if (!plain) { free(cipher); return NULL; }

    bool ok = xchacha20poly1305_decrypt(plain, cipher, actual_cipher_len,
                                        NULL, 0, nonce, key);
    free(cipher);
    if (!ok) { free(plain); return NULL; }  /* wrong passphrase / tampered data */

    plain[plain_len] = '\0';
    return (char *)plain;
}

/* include_secrets: if false, WireGuard private key and PSK are omitted (plain-text export).
 *                  if true,  all keys are included (encrypted export only). */
static char *nvs_export_to_json_robust(bool include_secrets)
{
    nvs_handle_t nvs;
    esp_err_t err = nvs_open(PARAM_NAMESPACE, NVS_READONLY, &nvs);
    if (err != ESP_OK) return NULL;

    cJSON *arr = cJSON_CreateArray();
    if (!arr) { nvs_close(nvs); return NULL; }

    nvs_iterator_t it = NULL;
    err = nvs_entry_find_in_handle(nvs, NVS_TYPE_ANY, &it);
    while (err == ESP_OK) {
        nvs_entry_info_t info;
        nvs_entry_info(it, &info);

        /* Skip secrets for plain (unencrypted) exports:
         *   passwd       — STA WiFi password (also used as WPA-Enterprise EAP password)
         *   ap_passwd    — AP WiFi password
         *   vpn_privkey  — WireGuard private key
         *   vpn_psk      — WireGuard pre-shared key
         *   web_password — salt:hash of the web UI password. Exporting it put
         *                  the hash in a plaintext file anyone could take away
         *                  and grind offline.
         *   mqtt_pass    — MQTT broker credential
         *   rc_hostkey   — SSH host private key of the remote console */
        if (!include_secrets &&
            (strcmp(info.key, "passwd")       == 0 ||
             strcmp(info.key, "ap_passwd")    == 0 ||
             strcmp(info.key, "vpn_privkey")  == 0 ||
             strcmp(info.key, "vpn_psk")      == 0 ||
             strcmp(info.key, "web_password") == 0 ||
             strcmp(info.key, "mqtt_pass")    == 0 ||
             strcmp(info.key, "rc_hostkey")   == 0)) {
            err = nvs_entry_next(&it);
            continue;
        }

        cJSON *item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "key", info.key);
        cJSON_AddNumberToObject(item, "type", info.type);

        switch (info.type) {
            case NVS_TYPE_U8: {
                uint8_t v; nvs_get_u8(nvs, info.key, &v);
                cJSON_AddNumberToObject(item, "val", v);
                break;
            }
            case NVS_TYPE_U16: {
                uint16_t v; nvs_get_u16(nvs, info.key, &v);
                cJSON_AddNumberToObject(item, "val", v);
                break;
            }
            case NVS_TYPE_U32: {
                uint32_t v; nvs_get_u32(nvs, info.key, &v);
                cJSON_AddNumberToObject(item, "val", v);
                break;
            }
            case NVS_TYPE_I32: {
                int32_t v; nvs_get_i32(nvs, info.key, &v);
                cJSON_AddNumberToObject(item, "val", v);
                break;
            }
            case NVS_TYPE_STR: {
                size_t len = 0;
                nvs_get_str(nvs, info.key, NULL, &len);
                char *buf = malloc(len);
                if (buf) {
                    nvs_get_str(nvs, info.key, buf, &len);
                    cJSON_AddStringToObject(item, "val", buf);
                    free(buf);
                }
                break;
            }
            case NVS_TYPE_BLOB: {
                size_t len = 0;
                nvs_get_blob(nvs, info.key, NULL, &len);
                uint8_t *buf = malloc(len);
                if (buf) {
                    nvs_get_blob(nvs, info.key, buf, &len);
                    char *hex = bytes_to_hex(buf, len);
                    free(buf);
                    if (hex) {
                        cJSON_AddStringToObject(item, "val", hex);
                        free(hex);
                    }
                }
                break;
            }
            default:
                break;
        }
        cJSON_AddItemToArray(arr, item);
        err = nvs_entry_next(&it);
    }
    nvs_release_iterator(it);
    nvs_close(nvs);

    char *json = cJSON_PrintUnformatted(arr);
    cJSON_Delete(arr);
    return json;
}

static esp_err_t nvs_import_from_json_robust(const char *json_str)
{
    cJSON *arr = cJSON_Parse(json_str);
    if (!arr || !cJSON_IsArray(arr)) {
        cJSON_Delete(arr);
        return ESP_ERR_INVALID_ARG;
    }

    /* Validate all entries before touching NVS */
    int valid_count = 0;
    cJSON *item;
    cJSON_ArrayForEach(item, arr) {
        cJSON *jkey = cJSON_GetObjectItem(item, "key");
        cJSON *jtype = cJSON_GetObjectItem(item, "type");
        cJSON *jval = cJSON_GetObjectItem(item, "val");
        if (!jkey || !cJSON_IsString(jkey) || !jtype || !cJSON_IsNumber(jtype) || !jval) continue;
        valid_count++;
    }
    if (valid_count == 0) {
        cJSON_Delete(arr);
        return ESP_ERR_INVALID_ARG;
    }

    nvs_handle_t nvs;
    esp_err_t err = nvs_open(PARAM_NAMESPACE, NVS_READWRITE, &nvs);
    if (err != ESP_OK) { cJSON_Delete(arr); return err; }

    /* Erase all existing keys — safe now that JSON is validated */
    nvs_erase_all(nvs);

    cJSON_ArrayForEach(item, arr) {
        cJSON *jkey = cJSON_GetObjectItem(item, "key");
        cJSON *jtype = cJSON_GetObjectItem(item, "type");
        cJSON *jval = cJSON_GetObjectItem(item, "val");
        if (!jkey || !cJSON_IsString(jkey) || !jtype || !cJSON_IsNumber(jtype) || !jval) continue;

        const char *key = jkey->valuestring;
        int type = (int)jtype->valuedouble;

        switch (type) {
            case NVS_TYPE_U8:
                if (cJSON_IsNumber(jval)) nvs_set_u8(nvs, key, (uint8_t)jval->valuedouble);
                break;
            case NVS_TYPE_U16:
                if (cJSON_IsNumber(jval)) nvs_set_u16(nvs, key, (uint16_t)jval->valuedouble);
                break;
            case NVS_TYPE_U32:
                if (cJSON_IsNumber(jval)) nvs_set_u32(nvs, key, (uint32_t)jval->valuedouble);
                break;
            case NVS_TYPE_I32:
                if (cJSON_IsNumber(jval)) nvs_set_i32(nvs, key, (int32_t)jval->valuedouble);
                break;
            case NVS_TYPE_STR:
                if (cJSON_IsString(jval)) nvs_set_str(nvs, key, jval->valuestring);
                break;
            case NVS_TYPE_BLOB: {
                if (!cJSON_IsString(jval)) break;
                size_t hex_len = strlen(jval->valuestring);
                if (hex_len % 2 != 0) break;
                size_t blob_len = hex_len / 2;
                uint8_t *blob = malloc(blob_len);
                if (blob) {
                    if (hex_to_bytes(jval->valuestring, blob, blob_len) == 0) {
                        nvs_set_blob(nvs, key, blob, blob_len);
                    }
                    free(blob);
                }
                break;
            }
            default:
                break;
        }
    }

    nvs_commit(nvs);
    nvs_close(nvs);
    cJSON_Delete(arr);
    return ESP_OK;
}

/* Resume STA connection attempts if a WiFi scan had suppressed them.
 * Called from non-scan page handlers so that navigating away from /scan
 * (or any other page load) restarts the connection process. */
static inline void resume_sta_if_scan_idle(void)
{
    if (wifi_scan_active) {
        wifi_scan_active = false;
        if (!ap_connect) {
            esp_wifi_connect();
        }
    }
}

/* --- Config Export/Import HTTP handlers --- */

static esp_err_t config_export_handler(httpd_req_t *req)
{
    if (!check_csrf(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "CSRF rejected /api/config-export from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "CSRF check failed");
        return ESP_FAIL;
    }
    bool password_protection_enabled = is_web_password_set();
    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /api/config-export from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "Not authenticated");
        return ESP_FAIL;
    }

    /* Read optional passphrase from POST JSON body: {"pass":"..."} */
    char pass[128] = {0};
    if (req->content_len > 0 && req->content_len < 256) {
        char body[256];
        int recv_len = httpd_req_recv(req, body, req->content_len);
        if (recv_len > 0) {
            body[recv_len] = '\0';
            cJSON *j = cJSON_Parse(body);
            if (j) {
                cJSON *p = cJSON_GetObjectItem(j, "pass");
                if (cJSON_IsString(p) && p->valuestring[0] != '\0') {
                    strlcpy(pass, p->valuestring, sizeof(pass));
                }
                cJSON_Delete(j);
            }
        }
    }

    /* Include WireGuard secrets only in encrypted exports */
    char *plain = nvs_export_to_json_robust(pass[0] != '\0');
    if (!plain) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Export failed");
        return ESP_FAIL;
    }

    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Content-Disposition", "attachment; filename=\"esp32_nat_config.json\"");

    if (pass[0] == '\0') {
        /* No passphrase — send plain JSON (WireGuard secrets already omitted) */
        httpd_resp_send(req, plain, HTTPD_RESP_USE_STRLEN);
        free(plain);
    } else {
        /* Encrypt with PBKDF2-derived XChaCha20-Poly1305 key
         * config_encrypt_json() takes ownership of plain and frees it. */
        char *enc = config_encrypt_json(plain, strlen(plain), pass);
        if (!enc) {
            httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Encryption failed");
            return ESP_FAIL;
        }
        ESP_LOGI(TAG, "Config exported (encrypted)");
        httpd_resp_send(req, enc, HTTPD_RESP_USE_STRLEN);
        free(enc);
    }
    return ESP_OK;
}

static esp_err_t config_import_handler(httpd_req_t *req)
{
    if (!check_csrf(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "CSRF rejected /api/config-import from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "CSRF check failed");
        return ESP_FAIL;
    }
    bool password_protection_enabled = is_web_password_set();
    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /api/config-import from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "Not authenticated");
        return ESP_FAIL;
    }

    if (req->content_len > CONFIG_IMPORT_MAX_SIZE || req->content_len == 0) {
        httpd_resp_set_type(req, "application/json");
        httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Invalid body size\"}", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char *body = malloc(req->content_len + 1);
    if (!body) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
        return ESP_FAIL;
    }

    int total = 0;
    while (total < req->content_len) {
        int ret = httpd_req_recv(req, body + total, req->content_len - total);
        if (ret <= 0) {
            free(body);
            if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
                httpd_resp_send_408(req);
            }
            return ESP_FAIL;
        }
        total += ret;
    }
    body[total] = '\0';

    /* Detect encrypted envelope with a cheap string search instead of
     * parsing the entire JSON — saves a full cJSON tree allocation. */
    char *json_to_import = body;
    char *decrypted = NULL;
    bool is_encrypted = (strstr(body, "\"enc\"") != NULL &&
                         strstr(body, "\"c\"")   != NULL);

    if (is_encrypted) {
        /* Read passphrase from X-Config-Pass header */
        char pass[128] = {0};
        httpd_req_get_hdr_value_str(req, "X-Config-Pass", pass, sizeof(pass));

        if (pass[0] == '\0') {
            free(body);
            httpd_resp_set_type(req, "application/json");
            httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Encrypted config requires passphrase\"}", HTTPD_RESP_USE_STRLEN);
            return ESP_OK;
        }

        decrypted = config_decrypt_json(body, pass);
        if (!decrypted) {
            free(body);
            httpd_resp_set_type(req, "application/json");
            httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Decryption failed: wrong passphrase or corrupt file\"}", HTTPD_RESP_USE_STRLEN);
            return ESP_OK;
        }
        ESP_LOGI(TAG, "Config import: decryption OK");
        free(body);          /* Release early — no longer needed after decryption */
        body = NULL;
        json_to_import = decrypted;
    }

    esp_err_t err = nvs_import_from_json_robust(json_to_import);
    free(body);              /* NULL-safe: no-op if already freed above */
    if (decrypted) free(decrypted);

    httpd_resp_set_type(req, "application/json");
    if (err == ESP_OK) {
        httpd_resp_send(req, "{\"ok\":true,\"msg\":\"Config imported. Rebooting...\"}", HTTPD_RESP_USE_STRLEN);
        esp_timer_start_once(restart_timer, 3000000);
    } else {
        httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Import failed: invalid JSON\"}", HTTPD_RESP_USE_STRLEN);
    }
    return ESP_OK;
}

static httpd_uri_t config_exportp = {
    .uri       = "/api/config-export",
    .method    = HTTP_POST,
    .handler   = config_export_handler,
};

static httpd_uri_t config_importp = {
    .uri       = "/api/config-import",
    .method    = HTTP_POST,
    .handler   = config_import_handler,
};

/* --- WireGuard .conf import handler --- */

static esp_err_t vpn_import_handler(httpd_req_t *req)
{
    if (!check_csrf(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "CSRF rejected /api/vpn-import from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "CSRF check failed");
        return ESP_FAIL;
    }
    if (is_web_password_set() && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /api/vpn-import from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "Not authenticated");
        return ESP_FAIL;
    }

    if (req->content_len == 0 || req->content_len > 4096) {
        httpd_resp_set_type(req, "application/json");
        httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Invalid body size\"}", HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char *body = malloc(req->content_len + 1);
    if (!body) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
        return ESP_FAIL;
    }

    int total = 0;
    while (total < req->content_len) {
        int ret = httpd_req_recv(req, body + total, req->content_len - total);
        if (ret <= 0) {
            free(body);
            if (ret == HTTPD_SOCK_ERR_TIMEOUT) httpd_resp_send_408(req);
            return ESP_FAIL;
        }
        total += ret;
    }
    body[total] = '\0';

    esp_err_t err = vpn_import_conf(body);
    free(body);

    httpd_resp_set_type(req, "application/json");
    if (err == ESP_OK) {
        httpd_resp_send(req, "{\"ok\":true,\"msg\":\"WireGuard config imported. Rebooting...\"}", HTTPD_RESP_USE_STRLEN);
        esp_timer_start_once(restart_timer, 3000000);
    } else {
        httpd_resp_send(req, "{\"ok\":false,\"msg\":\"Import failed: need PrivateKey, PublicKey, Endpoint and Address\"}", HTTPD_RESP_USE_STRLEN);
    }
    return ESP_OK;
}

static httpd_uri_t vpn_importp = {
    .uri       = "/api/vpn-import",
    .method    = HTTP_POST,
    .handler   = vpn_import_handler,
};

/* @@API_BEGIN@@ (host tests in tests/host extract the code between these markers) */
/* --- OTA firmware update: upload, status, confirm, rollback; TTL API --- */

/* Common guard for the JSON API endpoints: CSRF check + login if a web
 * password is set. Sends the error response itself and returns false. */
static bool api_guard(httpd_req_t *req, const char *what)
{
    if (!check_csrf(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "CSRF rejected %s from %s", what, get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "CSRF check failed");
        return false;
    }
    if (is_web_password_set() && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to %s from %s", what, get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "Not authenticated");
        return false;
    }
    return true;
}

static esp_err_t json_reply(httpd_req_t *req, const char *json)
{
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    return httpd_resp_send(req, json, HTTPD_RESP_USE_STRLEN);
}

/* {"ok":..,"code":"..","msg":".."} - msg/code must not contain quotes. */
static esp_err_t ota_reply(httpd_req_t *req, bool ok, const char *code, const char *msg)
{
    char out[256];
    snprintf(out, sizeof(out), "{\"ok\":%s,\"code\":\"%s\",\"msg\":\"%s\"}",
             ok ? "true" : "false", code, msg);
    return json_reply(req, out);
}

/* Copy src into dst escaping quotes, backslashes and control characters. */
static void json_escape_to(char *dst, size_t dst_len, const char *src)
{
    size_t o = 0;
    for (; *src && o + 7 < dst_len; src++) {
        unsigned char c = (unsigned char)*src;
        if (c == '"' || c == '\\') {
            dst[o++] = '\\';
            dst[o++] = (char)c;
        } else if (c < 0x20) {
            o += snprintf(dst + o, dst_len - o, "\\u%04x", c);
        } else {
            dst[o++] = (char)c;
        }
    }
    dst[o] = '\0';
}

#define OTA_CHUNK        4096
/* httpd_req_recv() times out after recv_wait_timeout (2 s). A phone on weak
 * Wi-Fi easily stalls that long; tolerate a few consecutive stalls instead of
 * aborting a half-written update. */
#define OTA_RECV_STALLS  8

static bool s_ota_busy = false;

static bool ota_recv_full(httpd_req_t *req, char *buf, size_t len)
{
    size_t got = 0;
    int stalls = 0;
    while (got < len) {
        int r = httpd_req_recv(req, buf + got, len - got);
        if (r == HTTPD_SOCK_ERR_TIMEOUT) {
            if (++stalls > OTA_RECV_STALLS) return false;
            continue;
        }
        if (r <= 0) return false;
        stalls = 0;
        got += (size_t)r;
    }
    return true;
}

/* Read and discard the rest of a rejected upload so the client receives our
 * error message instead of a connection reset. */
static void ota_drain(httpd_req_t *req, char *buf, size_t remaining)
{
    while (remaining > 0) {
        size_t n = MIN(remaining, (size_t)OTA_CHUNK);
        if (!ota_recv_full(req, buf, n)) return;
        remaining -= n;
    }
}

static esp_err_t ota_upload_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ota-upload")) {
        return ESP_FAIL;
    }
    if (s_ota_busy) {
        httpd_resp_set_status(req, "409 Conflict");
        return ota_reply(req, false, "busy", "Another update is already in progress");
    }

    const esp_partition_t *part = esp_ota_get_next_update_partition(NULL);
    if (part == NULL) {
        return ota_reply(req, false, "no_partition", "No OTA partition found");
    }

    /* ?force=1 skips ONLY the project-name check */
    bool force = false;
    {
        char q[32], v[4];
        if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK &&
            httpd_query_key_value(q, "force", v, sizeof(v)) == ESP_OK && v[0] == '1') {
            force = true;
        }
    }

    char *buf = malloc(OTA_CHUNK);
    if (buf == NULL) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
        return ESP_FAIL;
    }
    s_ota_busy = true;

    size_t remaining = req->content_len;
    const char *code = "ok";
    char msg[160] = "";
    bool conn_dead = false;     /* socket unusable: no reply possible */
    bool close_conn = false;    /* reply, but do not drain/keep the connection */
    bool begun = false, installed = false;
    esp_ota_handle_t handle = 0;
    esp_err_t err;
    size_t first;

    if (remaining == 0) {
        code = "empty"; snprintf(msg, sizeof(msg), "Empty upload");
        goto done;
    }
    if (remaining > part->size) {
        code = "too_large";
        snprintf(msg, sizeof(msg), "Firmware (%u bytes) is larger than the update slot (%u bytes)",
                 (unsigned)remaining, (unsigned)part->size);
        close_conn = true;
        goto done;
    }

    ESP_LOGI(TAG, "OTA upload: %u bytes -> partition '%s' at 0x%lx%s",
             (unsigned)remaining, part->label, (unsigned long)part->address, force ? " (force)" : "");

    /* Validate the image header BEFORE touching the spare slot. */
    first = MIN(remaining, (size_t)OTA_CHUNK);
    if (first < ota_validate_min_bytes()) {
        ota_hdr_result_t r = OTA_HDR_TOO_SHORT;
        code = ota_hdr_result_code(r); snprintf(msg, sizeof(msg), "%s", ota_hdr_result_msg(r));
        goto done;
    }
    if (!ota_recv_full(req, buf, first)) {
        conn_dead = true; code = "recv"; goto done;
    }
    remaining -= first;
    {
        const esp_app_desc_t *run = esp_app_get_description();
        ota_hdr_result_t r = ota_validate_header((const uint8_t *)buf, first,
                                                 (uint16_t)CONFIG_IDF_FIRMWARE_CHIP_ID,
                                                 run ? run->project_name : NULL, force);
        if (r != OTA_HDR_OK) {
            code = ota_hdr_result_code(r);
            if (r == OTA_HDR_WRONG_CHIP) {
                snprintf(msg, sizeof(msg), "Firmware is for chip id 0x%04X, this device is 0x%04X",
                         (unsigned)((const esp_image_header_t *)buf)->chip_id, (unsigned)CONFIG_IDF_FIRMWARE_CHIP_ID);
            } else {
                snprintf(msg, sizeof(msg), "%s", ota_hdr_result_msg(r));
            }
            ESP_LOGW(TAG, "OTA rejected: %s", code);
            goto done;
        }
    }

    err = esp_ota_begin(part, OTA_WITH_SEQUENTIAL_WRITES, &handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_begin failed: %s", esp_err_to_name(err));
        code = "begin"; snprintf(msg, sizeof(msg), "Could not start update (%s)", esp_err_to_name(err));
        goto done;
    }
    begun = true;

    err = esp_ota_write(handle, buf, first);
    while (err == ESP_OK && remaining > 0) {
        size_t n = MIN(remaining, (size_t)OTA_CHUNK);
        if (!ota_recv_full(req, buf, n)) {
            conn_dead = true; code = "recv";
            ESP_LOGE(TAG, "OTA upload interrupted, %u bytes missing", (unsigned)remaining);
            goto done;
        }
        remaining -= n;
        err = esp_ota_write(handle, buf, n);
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_write failed: %s", esp_err_to_name(err));
        code = "write"; snprintf(msg, sizeof(msg), "Flash write failed (%s)", esp_err_to_name(err));
        goto done;
    }

    /* Full image verification (checksum + SHA-256 + chip revision). */
    err = esp_ota_end(handle);
    begun = false;      /* esp_ota_end() releases the handle even on failure */
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_end failed: %s", esp_err_to_name(err));
        code = "verify"; snprintf(msg, sizeof(msg), "Firmware verification failed (%s)", esp_err_to_name(err));
        goto done;
    }

    err = esp_ota_set_boot_partition(part);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_set_boot_partition failed: %s", esp_err_to_name(err));
        code = "boot"; snprintf(msg, sizeof(msg), "Could not select new firmware (%s)", esp_err_to_name(err));
        goto done;
    }
    installed = true;
    snprintf(msg, sizeof(msg), "Firmware installed. Rebooting...");

done:
    if (begun) {
        esp_ota_abort(handle);
    }
    if (!installed && !conn_dead && !close_conn && remaining > 0) {
        ota_drain(req, buf, remaining);
    }
    free(buf);
    s_ota_busy = false;

    if (conn_dead) {
        return ESP_FAIL;
    }
    esp_err_t rr = ota_reply(req, installed, code, msg);
    if (installed) {
        ESP_LOGI(TAG, "OTA update successful, rebooting in 3 seconds...");
        esp_timer_start_once(restart_timer, 3000000);
    }
    return close_conn ? ESP_FAIL : rr;
}

static httpd_uri_t ota_uploadp = {
    .uri       = "/api/ota-upload",
    .method    = HTTP_POST,
    .handler   = ota_upload_handler,
};

static esp_err_t ota_status_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ota-status")) {
        return ESP_FAIL;
    }
    ota_info_t i;
    ota_manager_get_info(&i);

    char ver[70], proj[70], prev[70];
    json_escape_to(ver, sizeof(ver), i.version);
    json_escape_to(proj, sizeof(proj), i.project);
    json_escape_to(prev, sizeof(prev), i.prev_version);

    char out[512];
    snprintf(out, sizeof(out),
        "{\"version\":\"%s\",\"project\":\"%s\",\"chip\":\"%s\",\"slot\":\"%s\",\"other\":\"%s\","
        "\"state\":\"%s\",\"prev\":\"%s\",\"slot_size\":%u,\"uptime_s\":%u,"
        "\"pending\":%s,\"pending_left\":%d,\"validate_s\":%d,\"rollback\":%s}",
        ver, proj, CONFIG_IDF_TARGET, i.running_label, i.other_label,
        i.state, prev, (unsigned)i.slot_size, (unsigned)i.uptime_s,
        i.pending ? "true" : "false", i.pending_left_s, OTA_VALIDATE_STABLE_S,
        i.rollback_possible ? "true" : "false");
    return json_reply(req, out);
}

static httpd_uri_t ota_statusp = {
    .uri       = "/api/ota-status",
    .method    = HTTP_GET,
    .handler   = ota_status_handler,
};

static esp_err_t ota_confirm_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ota-confirm")) {
        return ESP_FAIL;
    }
    esp_err_t err = ota_manager_confirm();
    if (err == ESP_OK) {
        return ota_reply(req, true, "ok", "Firmware confirmed");
    }
    return ota_reply(req, false, "not_pending", "Running firmware is not waiting for confirmation");
}

static httpd_uri_t ota_confirmp = {
    .uri       = "/api/ota-confirm",
    .method    = HTTP_POST,
    .handler   = ota_confirm_handler,
};

static esp_err_t ota_rollback_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ota-rollback")) {
        return ESP_FAIL;
    }
    esp_err_t err = ota_manager_rollback_previous();
    if (err != ESP_OK) {
        return ota_reply(req, false, "no_previous", "No previous firmware available to roll back to");
    }
    esp_err_t rr = ota_reply(req, true, "ok", "Rolling back. Rebooting...");
    esp_timer_start_once(restart_timer, 2000000);
    return rr;
}

static httpd_uri_t ota_rollbackp = {
    .uri       = "/api/ota-rollback",
    .method    = HTTP_POST,
    .handler   = ota_rollback_handler,
};

/* Firmware Update page GET handler. All dynamic data comes from /api/ota-status. */
static esp_err_t update_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    if (is_web_password_set() && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /update from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }
    SEND_CHUNK(req, UPDATE_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);
    SEND_CHUNK(req, UPDATE_CHUNK_BODY, HTTPD_RESP_USE_STRLEN);
    SEND_CHUNK(req, UPDATE_CHUNK_SCRIPT, HTTPD_RESP_USE_STRLEN);
    SEND_CHUNK(req, NULL, 0);
    return ESP_OK;
}

static httpd_uri_t updatep = {
    .uri       = "/update",
    .method    = HTTP_GET,
    .handler   = update_get_handler,
};

/* --- TTL rewrite API (shares NVS key "sta_ttl" with the CLI 'set_ttl') --- */

static esp_err_t ttl_reply_state(httpd_req_t *req, bool ok, const char *msg)
{
    int saved = 0, last = 0;
    get_config_param_int("sta_ttl", &saved);
    get_config_param_int("sta_ttl_last", &last);
    char out[192];
    snprintf(out, sizeof(out),
        "{\"ok\":%s,\"msg\":\"%s\",\"active\":%d,\"saved\":%d,\"last\":%d,\"display\":%d}",
        ok ? "true" : "false", msg, (int)sta_ttl_override, saved, last,
        ttl_display_value(saved, last));
    return json_reply(req, out);
}

static esp_err_t ttl_get_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ttl")) {
        return ESP_FAIL;
    }
    return ttl_reply_state(req, true, "ok");
}

static esp_err_t ttl_post_handler(httpd_req_t *req)
{
    if (!api_guard(req, "/api/ttl")) {
        return ESP_FAIL;
    }
    char body[96];
    size_t len = req->content_len;
    if (len == 0 || len >= sizeof(body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Bad request size");
        return ESP_FAIL;
    }
    if (!ota_recv_full(req, body, len)) {
        return ESP_FAIL;
    }
    body[len] = '\0';

    ttl_req_t r;
    ttl_err_t e = ttl_parse_request(body, &r);
    if (e != TTL_OK) {
        httpd_resp_set_status(req, "400 Bad Request");
        return ttl_reply_state(req, false, ttl_err_msg(e));
    }

    int eff = ttl_effective_value(&r);
    if (set_config_param_int("sta_ttl", eff) != ESP_OK) {
        httpd_resp_set_status(req, "500 Internal Server Error");
        return ttl_reply_state(req, false, "Failed to write setting to flash");
    }
    if (r.has_value) {
        set_config_param_int("sta_ttl_last", r.value);  /* remembered for the next enable; best effort */
    }
    if (r.action == TTL_ACT_APPLY) {
        sta_ttl_override = (uint8_t)eff;
        ESP_LOGI(TAG, "TTL override %s via web UI (%d)", eff ? "applied" : "disabled", eff);
    } else {
        ESP_LOGI(TAG, "TTL override saved via web UI (%d), not yet active", eff);
    }
    return ttl_reply_state(req, true, r.action == TTL_ACT_APPLY ? "Applied" : "Saved");
}

static httpd_uri_t ttl_getp = {
    .uri       = "/api/ttl",
    .method    = HTTP_GET,
    .handler   = ttl_get_handler,
};

static httpd_uri_t ttl_postp = {
    .uri       = "/api/ttl",
    .method    = HTTP_POST,
    .handler   = ttl_post_handler,
};
/* @@API_END@@ */

esp_err_t http_404_error_handler(httpd_req_t *req, httpd_err_code_t err)
{
    httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Page not found");
    return ESP_FAIL;
}

char* html_escape(const char* src) {
    //HTML escape for both attribute and element-content contexts.
    //Encodes < > & " ' \ # ; as numeric entities (&#NN;), so attacker-controlled
    //strings (e.g. scanned SSIDs) cannot inject markup or break out of attributes.
    int len = strlen(src);
    //Every char in the string + a null
    int esc_len = len + 1;

    for (int i = 0; i < len; i++) {
        if (src[i] == '\\' || src[i] == '\'' || src[i] == '\"' || src[i] == '&' || src[i] == '#' || src[i] == ';' || src[i] == '<' || src[i] == '>') {
            //Will be replaced with a 5 char sequence
            esc_len += 4;
        }
    }

    char* res = malloc(sizeof(char) * esc_len);
    if (res == NULL) {
        ESP_LOGE(TAG, "Failed to allocate memory for HTML escaping");
        return NULL;
    }

    int j = 0;
    for (int i = 0; i < len; i++) {
        if (src[i] == '\\' || src[i] == '\'' || src[i] == '\"' || src[i] == '&' || src[i] == '#' || src[i] == ';' || src[i] == '<' || src[i] == '>') {
            res[j++] = '&';
            res[j++] = '#';
            res[j++] = '0' + (src[i] / 10);
            res[j++] = '0' + (src[i] % 10);
            res[j++] = ';';
        }
        else {
            res[j++] = src[i];
        }
    }
    res[j] = '\0';

    return res;
}

static esp_err_t favicon_get_handler(httpd_req_t *req) {
    httpd_resp_set_type(req, "image/png");
    httpd_resp_send(req, (const char*)favicon_png, favicon_png_len);
    return ESP_OK;
}

static const httpd_uri_t favicon_uri = {
    .uri       = "/favicon.png",
    .method    = HTTP_GET,
    .handler   = favicon_get_handler,
    .user_ctx  = NULL
};

/* Index page GET handler - System Status with navigation */
static esp_err_t index_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    char* buf = NULL;
    size_t buf_len = 0;
    char param[128];
    char param2[128];
    char login_message[256] = "";
    bool authenticated = false;
    bool password_protection_enabled = is_web_password_set();

    /* The login/password forms POST their fields (keeps the password out of the
     * URL); nav links and logout use GET query params. Both arrive as
     * key=value&key=value, so httpd_query_key_value() parses either. */
    if (req->method == HTTP_POST) {
        if (req->content_len > 0 && req->content_len < 1024) {
            buf = malloc(req->content_len + 1);
            if (buf != NULL) {
                int recv_len = httpd_req_recv(req, buf, req->content_len);
                if (recv_len > 0) {
                    buf[recv_len] = '\0';
                } else {
                    free(buf);
                    buf = NULL;
                }
            }
        }
    } else {
        buf_len = httpd_req_get_url_query_len(req) + 1;
        if (buf_len > 1) {
            buf = malloc(buf_len);
            if (buf != NULL && httpd_req_get_url_query_str(req, buf, buf_len) != ESP_OK) {
                free(buf);
                buf = NULL;
            }
        }
    }

    if (buf != NULL) {

            /* Handle logout */
            if (httpd_query_key_value(buf, "logout", param, sizeof(param)) == ESP_OK) {
                clear_session();
                strcpy(login_message, "Logged out successfully.");
            }

            /* Handle login */
            else if (httpd_query_key_value(buf, "login_password", param, sizeof(param)) == ESP_OK) {
                preprocess_string(param);
                /* Shared backoff with SSH: while it runs, no password is
                 * checked. Refusing instead of sleeping keeps the (single)
                 * httpd task responsive for everyone else. */
                uint32_t wait_ms = password_protection_enabled ? router_login_wait_ms() : 0;
                if (wait_ms > 0) {
                    char ip[16];
                    ESP_LOGW(TAG, "Web UI login from %s refused: backoff %lu ms",
                             get_client_ip(req, ip, sizeof(ip)), (unsigned long)wait_ms);
                    snprintf(login_message, sizeof(login_message),
                             "ERROR: Too many failed logins. Try again in %lu s.",
                             (unsigned long)((wait_ms + 999) / 1000));
                } else if (password_protection_enabled && verify_web_password(param)) {
                    router_login_result(true);
                    create_session(req);
                    { char _ip[16]; ESP_LOGI(TAG, "Web UI login successful from %s", get_client_ip(req, _ip, sizeof(_ip))); }
                    free(buf);
                    /* Redirect to reload page with session cookie */
                    httpd_resp_set_status(req, "303 See Other");
                    httpd_resp_set_hdr(req, "Location", "/");
                    httpd_resp_send(req, NULL, 0);
                    return ESP_OK;
                } else {
                    char ip[16];
                    uint32_t next_ms = password_protection_enabled ? router_login_result(false) : 0;
                    ESP_LOGW(TAG, "Web UI login failed: incorrect password from %s (next check in %lu ms)",
                             get_client_ip(req, ip, sizeof(ip)), (unsigned long)next_ms);
                    strcpy(login_message, "ERROR: Incorrect password.");
                }
            }

            /* Handle password change */
            else if (httpd_query_key_value(buf, "new_password", param, sizeof(param)) == ESP_OK &&
                     httpd_query_key_value(buf, "confirm_password", param2, sizeof(param2)) == ESP_OK) {
                preprocess_string(param);
                preprocess_string(param2);

                if (!check_csrf(req)) {
                    { char _ip[16]; ESP_LOGW(TAG, "CSRF rejected password set from %s", get_client_ip(req, _ip, sizeof(_ip))); }
                    strcpy(login_message, "ERROR: CSRF check failed.");
                }
                // Check if user is authenticated or no password is currently set
                else if (is_authenticated(req) || !password_protection_enabled) {
                    if (strcmp(param, param2) == 0) {
                        esp_err_t err = set_web_password_hashed(param);
                        if (err == ESP_OK) {
                            clear_session();  // Force re-login with new password
                            free(buf);
                            /* Redirect to reload page */
                            httpd_resp_set_status(req, "303 See Other");
                            httpd_resp_set_hdr(req, "Location", "/");
                            httpd_resp_send(req, NULL, 0);
                            return ESP_OK;
                        } else {
                            strcpy(login_message, "ERROR: Failed to save password.");
                        }
                    } else {
                        strcpy(login_message, "ERROR: Passwords do not match.");
                    }
                } else {
                    char ip2[16];
                    ESP_LOGW(TAG, "Unauthorized attempt to change web password from %s", get_client_ip(req, ip2, sizeof(ip2)));
                    strcpy(login_message, "ERROR: Not authorized to change password.");
                }
            }

            /* Check for auth_required flag */
            else if (httpd_query_key_value(buf, "auth_required", param, sizeof(param)) == ESP_OK) {
                strcpy(login_message, "Please log in to access that page.");
            }
    }
    if (buf) free(buf);

    /* Check current authentication status */
    authenticated = is_authenticated(req);

    /* Reusable buffer for building dynamic content */
    char row[512];

    /* --- Begin chunked response --- */
    SEND_CHUNK(req, INDEX_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Stream logout button if authenticated */
    if (authenticated) {
        SEND_CHUNK(req,
            "<div style='text-align: right; margin-bottom: 0.5rem;'>"
            "<a href='/?logout=1' style='padding: 0.4rem 1rem; background: rgba(255,82,82,0.15); color: #ff5252; border: 1px solid #ff5252; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500;'>Logout</a>"
            "</div>", HTTPD_RESP_USE_STRLEN);
    }

    /* Open status table */
    SEND_CHUNK(req, INDEX_CHUNK_STATUS_OPEN, HTTPD_RESP_USE_STRLEN);

    /* Stream AP status rows */
    if (ap_disabled) {
        SEND_CHUNK(req,
            "<tr><td>AP Interface:</td><td><strong style='color:#ff5252;'>Disabled</strong></td></tr>",
            HTTPD_RESP_USE_STRLEN);
    } else {
        char* safe_ap_ssid = html_escape(ap_ssid);
        if (safe_ap_ssid == NULL) safe_ap_ssid = strdup("(unknown)");
        snprintf(row, sizeof(row), "<tr><td>SSID:</td><td><strong>%s</strong></td></tr>", safe_ap_ssid);
        /* Free before SEND_CHUNK: a bail-out on a dead client returns immediately. */
        free(safe_ap_ssid);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

        esp_ip4_addr_t ap_addr;
        ap_addr.addr = my_ap_ip;
        snprintf(row, sizeof(row), "<tr><td>AP IP:</td><td>" IPSTR "</td></tr>", IP2STR(&ap_addr));
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

        resync_connect_count();
        snprintf(row, sizeof(row), "<tr><td>AP Clients:</td><td>%d</td></tr>", connect_count);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* Stream Uplink row */
#if CONFIG_ETH_UPLINK
    if (ap_connect) {
        SEND_CHUNK(req, "<tr><td>Uplink:</td><td><strong>Ethernet Connected</strong></td></tr>", HTTPD_RESP_USE_STRLEN);
    } else {
        SEND_CHUNK(req, "<tr><td>Uplink:</td><td><strong>Ethernet Disconnected</strong></td></tr>", HTTPD_RESP_USE_STRLEN);
    }
#else
    if (ap_connect) {
        wifi_ap_record_t ap_info;
        if (esp_wifi_sta_get_ap_info(&ap_info) == ESP_OK) {
            snprintf(row, sizeof(row), "<tr><td>Uplink:</td><td><strong>Connected (%d dBm)</strong></td></tr>", ap_info.rssi);
            SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
        } else {
            SEND_CHUNK(req, "<tr><td>Uplink:</td><td><strong>Connected</strong></td></tr>", HTTPD_RESP_USE_STRLEN);
        }
    } else {
        SEND_CHUNK(req, "<tr><td>Uplink:</td><td><strong>Disconnected</strong></td></tr>", HTTPD_RESP_USE_STRLEN);
    }
#endif

    /* Stream uplink IP row */
    if (ap_connect) {
        esp_ip4_addr_t addr;
        addr.addr = my_ip;
#if CONFIG_ETH_UPLINK
        snprintf(row, sizeof(row), "<tr><td>ETH IP:</td><td>" IPSTR "</td></tr>", IP2STR(&addr));
#else
        snprintf(row, sizeof(row), "<tr><td>STA IP:</td><td>" IPSTR "</td></tr>", IP2STR(&addr));
#endif
    } else {
#if CONFIG_ETH_UPLINK
        snprintf(row, sizeof(row), "<tr><td>ETH IP:</td><td>N/A</td></tr>");
#else
        snprintf(row, sizeof(row), "<tr><td>STA IP:</td><td>N/A</td></tr>");
#endif
    }
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    /* Stream VPN status row */
    if (vpn_enabled) {
        if (vpn_is_connected()) {
            snprintf(row, sizeof(row), "<tr><td>VPN:</td><td><span style='color: #4caf50;'>Connected</span></td></tr>");
        } else if (vpn_connected) {
            snprintf(row, sizeof(row), "<tr><td>VPN:</td><td><span style='color: #ffc107;'>Handshake Pending</span></td></tr>");
        } else {
            snprintf(row, sizeof(row), "<tr><td>VPN:</td><td><span style='color: #f44336;'>Disconnected</span></td></tr>");
        }
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* Stream Bytes row (sent/received combined) */
    uint64_t bytes_sent = get_sta_bytes_sent();
    uint64_t bytes_received = get_sta_bytes_received();
    char sent_buf[16], recv_buf[16];
    format_bytes_human(bytes_sent, sent_buf, sizeof(sent_buf));
    format_bytes_human(bytes_received, recv_buf, sizeof(recv_buf));
    snprintf(row, sizeof(row), "<tr><td>Bytes:</td><td>%s sent / %s received</td></tr>", sent_buf, recv_buf);
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    /* Stream Monitoring row */
    pcap_capture_mode_t mode = pcap_get_mode();
    if (mode != PCAP_MODE_OFF) {
        const char* mode_name = (mode == PCAP_MODE_ACL_MONITOR) ? "ACL Monitor" : "Promiscuous";
        snprintf(row, sizeof(row),
                 "<tr><td>Monitoring:</td><td><span style='color: #4caf50;'>%s</span> (%lu captured, %lu dropped)</td></tr>",
                 mode_name,
                 (unsigned long)pcap_get_captured_count(),
                 (unsigned long)pcap_get_dropped_count());
    } else {
        snprintf(row, sizeof(row), "<tr><td>Monitoring:</td><td><span style='color: #888;'>Off</span></td></tr>");
    }
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    /* Stream Uptime row */
    char uptime_str[32];
    format_uptime(get_uptime_seconds(), uptime_str, sizeof(uptime_str));
    char boot_time_str[32];
    format_boot_time(boot_time_str, sizeof(boot_time_str));
    snprintf(row, sizeof(row), "<tr><td>Uptime:</td><td>%s (since %s)</td></tr>", uptime_str, boot_time_str);
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    /* Close status table */
    SEND_CHUNK(req, INDEX_CHUNK_STATUS_CLOSE, HTTPD_RESP_USE_STRLEN);

    /* Navigation buttons */
    SEND_CHUNK(req, INDEX_CHUNK_BUTTONS, HTTPD_RESP_USE_STRLEN);

    /* --- Auth UI Section (streamed directly) --- */

    /* Show message if any */
    if (login_message[0] != '\0') {
        const char* msg_style;
        if (strstr(login_message, "ERROR") != NULL) {
            msg_style = "background: #ffebee; color: #c62828; border: 2px solid #ef5350";
        } else {
            msg_style = "background: #e8f5e9; color: #2e7d32; border: 2px solid #66bb6a";
        }
        snprintf(row, sizeof(row),
                 "<div style='margin-top: 1.5rem; padding: 1rem; %s; border-radius: 8px; font-size: 0.95rem;'>%s</div>",
                 msg_style, login_message);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* Show warning if no password protection */
    if (!password_protection_enabled) {
        SEND_CHUNK(req,
            "<div style='margin-top: 1.5rem; padding: 1rem; background: #fff3cd; border: 2px solid #ffa726; border-radius: 8px;'>"
            "<strong style='color: #f57c00;'>⚠ No Password Protection</strong>"
            "<p style='margin-top: 0.5rem; color: #666; font-size: 0.9rem;'>Anyone on this network can access router settings. Set a password below.</p>"
            "</div>", HTTPD_RESP_USE_STRLEN);
    }

    /* Show login form if password is set and not authenticated */
    if (password_protection_enabled && !authenticated) {
        SEND_CHUNK(req,
            "<div style='margin-top: 1.5rem; padding: 1.5rem; background: rgba(22, 33, 62, 0.6); border: 1px solid rgba(0, 217, 255, 0.2); border-radius: 12px;'>"
            "<h2 style='margin-top: 0; margin-bottom: 1rem; color: #00d9ff; font-size: 1.1rem;'>🔒 Login Required</h2>"
            "<form action='/' method='POST'>"
            /* Hidden username field gives iOS/Safari and password managers an account
             * to associate the saved password with, so AutoFill works on this
             * password-only login instead of demanding a username. */
            "<input type='text' name='username' value='admin' autocomplete='username' style='display:none' aria-hidden='true' tabindex='-1'/>"
            "<input type='password' name='login_password' placeholder='Enter password' autocomplete='current-password' style='width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; background: rgba(255,255,255,0.1); border: 1px solid rgba(0,217,255,0.3); border-radius: 8px; color: #e0e0e0; font-size: 1rem;'/>"
            "<input type='submit' value='Login' style='width: 100%; padding: 0.75rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;'/>"
            "</form>"
            "</div>", HTTPD_RESP_USE_STRLEN);
    }

    /* Show password management form if authenticated or no password set */
    if (authenticated || !password_protection_enabled) {
        const char* form_title = password_protection_enabled ? "Change Password" : "Set Password";
        SEND_CHUNK(req,
            "<div style='margin-top: 1.5rem; padding: 1.5rem; background: rgba(22, 33, 62, 0.6); border: 1px solid rgba(0, 217, 255, 0.2); border-radius: 12px;'>"
            "<h2 style='margin-top: 0; margin-bottom: 1rem; color: #00d9ff; font-size: 1.1rem;'>🔑 ", HTTPD_RESP_USE_STRLEN);
        SEND_CHUNK(req, form_title, HTTPD_RESP_USE_STRLEN);
        SEND_CHUNK(req,
            "</h2>"
            /* POST keeps the new password out of the URL and makes the Origin-header
             * CSRF check effective (browsers send Origin on POST but not GET). */
            "<form action='/' method='POST'>"
            "<input type='password' name='new_password' placeholder='New password (empty to disable)' autocomplete='new-password' style='width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; background: rgba(255,255,255,0.1); border: 1px solid rgba(0,217,255,0.3); border-radius: 8px; color: #e0e0e0; font-size: 1rem;'/>"
            "<input type='password' name='confirm_password' placeholder='Confirm password' autocomplete='new-password' style='width: 100%; padding: 0.75rem; margin-bottom: 0.75rem; background: rgba(255,255,255,0.1); border: 1px solid rgba(0,217,255,0.3); border-radius: 8px; color: #e0e0e0; font-size: 1rem;'/>"
            "<input type='submit' value='", HTTPD_RESP_USE_STRLEN);
        SEND_CHUNK(req, form_title, HTTPD_RESP_USE_STRLEN);
        SEND_CHUNK(req,
            "' style='width: 100%; padding: 0.75rem; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: #fff; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;'/>"
            "<p style='margin-top: 0.75rem; color: #888; font-size: 0.85rem;'>Leave empty to disable password protection.</p>"
            "</form>"
            "</div>", HTTPD_RESP_USE_STRLEN);
    }

    /* Footer */
    {
        const esp_app_desc_t *app_desc = esp_app_get_description();
        char footer[512];
        snprintf(footer, sizeof(footer), INDEX_CHUNK_TAIL,
                 app_desc ? app_desc->version : "unknown",
                 app_desc ? app_desc->date : "",
                 app_desc ? app_desc->time : "");
        SEND_CHUNK(req, footer, HTTPD_RESP_USE_STRLEN);
    }

    /* End chunked response */
    SEND_CHUNK(req, NULL, 0);

    return ESP_OK;
}

static httpd_uri_t indexp = {
    .uri       = "/",
    .method    = HTTP_GET,
    .handler   = index_get_handler,
};

/* Same handler also serves POST so the login form can submit its password in the
 * request body instead of the URL query string. */
static httpd_uri_t indexp_post = {
    .uri       = "/",
    .method    = HTTP_POST,
    .handler   = index_get_handler,
};

uint8_t web_ui_get_bind(void)
{
    return s_web_bind;
}

void web_ui_set_bind(uint8_t bind)
{
    if (bind == 0) bind = RC_BIND_AP;  /* must keep at least one */
    s_web_bind = bind & (RC_BIND_AP | RC_BIND_STA | RC_BIND_VPN);
    set_config_param_int("web_bind", (int32_t)s_web_bind);
    char buf[20] = "";
    if (s_web_bind & RC_BIND_AP)  strcat(buf, "AP ");
#if CONFIG_ETH_UPLINK
    if (s_web_bind & RC_BIND_STA) strcat(buf, "ETH ");
#else
    if (s_web_bind & RC_BIND_STA) strcat(buf, "STA ");
#endif
    if (s_web_bind & RC_BIND_VPN) strcat(buf, "VPN ");
    ESP_LOGI(TAG, "Web UI bind set to: %s", buf);
}

/* Parse a GPIO number from a form field. An empty field means "none" (-1);
 * anything that is not a plain number leaves *out untouched so a malformed
 * field never silently reprograms a pin. */
static void parse_gpio_field(const char *value, int *out)
{
    if (value[0] == '\0') {
        *out = -1;
        return;
    }
    char *end;
    long v = strtol(value, &end, 10);
    if (end != value && *end == '\0' && v >= -1 && v < GPIO_NUM_MAX) {
        *out = (int)v;
    }
}

/* Router Config page GET handler */
static esp_err_t config_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    /* Check authentication if password protection is enabled */
    bool password_protection_enabled = is_web_password_set();

    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /config from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        /* Redirect to index page with auth_required flag */
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    char*  buf;
    size_t buf_len;

    /* Read URL query string length and allocate memory for length + 1 */
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (buf == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for query string");
            httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
            return ESP_ERR_NO_MEM;
        }
        if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found URL query => %s", buf);
            char reset_param[16];
            if (httpd_query_key_value(buf, "reset", reset_param, sizeof(reset_param)) == ESP_OK) {
                esp_timer_start_once(restart_timer, 500000);
            }

            /* Handle Web UI bind interface settings */
            char param1[64];
            if (httpd_query_key_value(buf, "web_bind_save", param1, sizeof(param1)) == ESP_OK) {
                uint8_t bind = 0;
                if (httpd_query_key_value(buf, "web_bind_ap",  param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_AP;
                if (httpd_query_key_value(buf, "web_bind_sta", param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_STA;
                if (httpd_query_key_value(buf, "web_bind_vpn", param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_VPN;
                if (bind == 0) bind = RC_BIND_AP;
                web_ui_set_bind(bind);
                ESP_LOGI(TAG, "Web UI bind interfaces updated via web");
                free(buf);
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/config");
                httpd_resp_send(req, NULL, 0);
                return ESP_OK;
            }

            /* Handle disable interface button */
            if (strstr(buf, "disable_interface=") != NULL) {
                ESP_LOGI(TAG, "Disabling web interface");
                if (set_config_param_str("web_disabled", "1") == ESP_OK) {
                    ESP_LOGI(TAG, "Web interface disabled. Use 'enable' command via serial to re-enable.");
                }
                esp_timer_start_once(restart_timer, 500000);
            }

            char param2[64];
            char param3[64];
            char param4[64];
            char param5[64];

            /* Handle AP settings with optional MAC and IP */
            if (httpd_query_key_value(buf, "ap_ssid", param1, sizeof(param1)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => ap_ssid=%s", param1);
                preprocess_string(param1);
                if (httpd_query_key_value(buf, "ap_password", param2, sizeof(param2)) == ESP_OK) {
                    preprocess_string(param2);

                    // "Open network" checkbox overrides password to empty
                    {
                        char open_val[4] = "";
                        if (httpd_query_key_value(buf, "ap_open", open_val, sizeof(open_val)) == ESP_OK) {
                            param2[0] = '\0';
                        } else if (strlen(param2) == 0) {
                            // Keep existing password if field was left empty
                            strlcpy(param2, ap_passwd, sizeof(param2));
                        }
                    }

                    // Set SSID and password
                    int argc = 3;
                    char* argv[3];
                    argv[0] = "set_ap";
                    argv[1] = param1;
                    argv[2] = param2;
                    set_ap(argc, argv);

                    // Check for optional AP IP address
                    if (httpd_query_key_value(buf, "ap_ip_addr", param3, sizeof(param3)) == ESP_OK && strlen(param3) > 0) {
                        ESP_LOGI(TAG, "Found URL query parameter => ap_ip_addr=%s", param3);
                        preprocess_string(param3);
                        char* ip_argv[2];
                        ip_argv[0] = "set_ap_ip";
                        ip_argv[1] = param3;
                        set_ap_ip(2, ip_argv);
                    }

                    // Check for optional hostname (mDNS / DHCP name).
                    // set_hostname validates (RFC 952) and updates the global.
                    if (httpd_query_key_value(buf, "ap_hostname", param4, sizeof(param4)) == ESP_OK) {
                        ESP_LOGI(TAG, "Found URL query parameter => ap_hostname=%s", param4);
                        char* host_argv[2];
                        host_argv[0] = "set_hostname";
                        host_argv[1] = param4;
                        set_hostname(2, host_argv);
                    }

                    // Check for optional AP DNS server
                    {
                        char dns_param[64];
                        if (httpd_query_key_value(buf, "ap_dns", dns_param, sizeof(dns_param)) == ESP_OK) {
                            preprocess_string(dns_param);
                            ESP_LOGI(TAG, "Found URL query parameter => ap_dns=%s", dns_param);
                            set_config_param_str("ap_dns", dns_param);
                            free(ap_dns);
                            ap_dns = strdup(dns_param);
                        }
                    }

                    // Check for optional AP MAC address
                    if (httpd_query_key_value(buf, "ap_mac", param4, sizeof(param4)) == ESP_OK && strlen(param4) > 0) {
                        ESP_LOGI(TAG, "Found URL query parameter => ap_mac=%s", param4);
                        preprocess_string(param4);
                        // Parse MAC address string (format: AA:BB:CC:DD:EE:FF)
                        unsigned int mac[6];
                        if (sscanf(param4, "%02x:%02x:%02x:%02x:%02x:%02x",
                                   &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) == 6) {
                            char mac_str[6][4];
                            for (int i = 0; i < 6; i++) {
                                sprintf(mac_str[i], "%d", mac[i]);
                            }
                            char* mac_argv[7];
                            mac_argv[0] = "set_ap_mac";
                            for (int i = 0; i < 6; i++) {
                                mac_argv[i+1] = mac_str[i];
                            }
                            set_ap_mac(7, mac_argv);
                        }
                    }

                    // Handle AP enabled/disabled setting
                    // Checkbox sends value only when checked, so absence means "disabled"
                    {
                        bool ap_en = (httpd_query_key_value(buf, "ap_enabled", param5, sizeof(param5)) == ESP_OK);
                        set_config_param_int("ap_disabled", ap_en ? 0 : 1);
                        ap_disabled = !ap_en;
                        ESP_LOGI(TAG, "AP interface %s", ap_en ? "enabled" : "disabled");
                    }

                    // Handle AP NAT setting (checkbox: present = on, absent = off)
                    {
                        int nat_val = (httpd_query_key_value(buf, "ap_nat", param5, sizeof(param5)) == ESP_OK) ? 1 : 0;
                        set_config_param_int("ap_nat", nat_val);
                        ap_nat_enabled = (uint8_t)nat_val;
                        ESP_LOGI(TAG, "AP NAT %s", nat_val ? "enabled" : "disabled");
                    }

                    // Handle AP hidden SSID setting
                    // Checkbox sends value only when checked, so absence means "off"
                    {
                        int hidden_val = 0;
                        if (httpd_query_key_value(buf, "ap_hidden", param5, sizeof(param5)) == ESP_OK) {
                            hidden_val = 1;
                            ESP_LOGI(TAG, "Found URL query parameter => ap_hidden=%s", param5);
                        }
                        set_config_param_int("ap_hidden", hidden_val);
                        ap_ssid_hidden = (uint8_t)hidden_val;
                        ESP_LOGI(TAG, "AP hidden SSID set to: %d", hidden_val);
                    }

                    // Handle AP auth mode setting
                    if (httpd_query_key_value(buf, "ap_auth", param5, sizeof(param5)) == ESP_OK) {
                        int auth_val = atoi(param5);
                        if (auth_val >= 0 && auth_val <= 2) {
                            set_config_param_int("ap_authmode", auth_val);
                            ap_authmode = (uint8_t)auth_val;
                            ESP_LOGI(TAG, "AP auth mode set to: %d", auth_val);
                        }
                    }

#if CONFIG_ETH_UPLINK
                    // Handle AP channel setting (ETH_UPLINK only)
                    if (httpd_query_key_value(buf, "ap_channel", param5, sizeof(param5)) == ESP_OK) {
                        int channel_val = atoi(param5);
                        if (channel_val >= 0 && channel_val <= 13) {
                            set_config_param_int("ap_channel", channel_val);
                            ap_channel = (uint8_t)channel_val;
                            ESP_LOGI(TAG, "AP channel set to: %d", channel_val);
                        }
                    }
#endif

                    esp_timer_start_once(restart_timer, 500000);
                }
            }

#if !CONFIG_ETH_UPLINK
            /* Handle STA settings with optional MAC */
            if (httpd_query_key_value(buf, "ssid", param1, sizeof(param1)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => ssid=%s", param1);
                preprocess_string(param1);
                if (httpd_query_key_value(buf, "password", param2, sizeof(param2)) == ESP_OK) {
                    preprocess_string(param2);

                    // "Open network" checkbox overrides password to empty
                    {
                        char open_val[4] = "";
                        if (httpd_query_key_value(buf, "sta_open", open_val, sizeof(open_val)) == ESP_OK) {
                            param2[0] = '\0';
                        } else if (strlen(param2) == 0) {
                            // Keep existing password if field was left empty
                            strlcpy(param2, passwd, sizeof(param2));
                        }
                    }
                    if (httpd_query_key_value(buf, "ent_username", param3, sizeof(param3)) == ESP_OK) {
                        ESP_LOGI(TAG, "Found URL query parameter => ent_username=%s", param3);
                        preprocess_string(param3);
                        if (httpd_query_key_value(buf, "ent_identity", param4, sizeof(param4)) == ESP_OK) {
                            ESP_LOGI(TAG, "Found URL query parameter => ent_identity=%s", param4);
                            preprocess_string(param4);

                            int argc = 0;
                            char* argv[7];
                            argv[argc++] = "set_sta";
                            //SSID
                            argv[argc++] = param1;
                            //Password
                            argv[argc++] = param2;
                            //Username
                            if(strlen(param3)) {
                                argv[argc++] = "-u";
                                argv[argc++] = param3;
                            }
                            //Identity
                            if(strlen(param4)) {
                                argv[argc++] = "-a";
                                argv[argc++] = param4;
                            }

                            set_sta(argc, argv);

                            // Save WPA2-Enterprise settings to NVS
                            {
                                char eap_param[4] = "";
                                int eap_val = 0;
                                if (httpd_query_key_value(buf, "eap_method", eap_param, sizeof(eap_param)) == ESP_OK) {
                                    eap_val = atoi(eap_param);
                                }
                                set_config_param_int("eap_method", eap_val);
                                eap_method = eap_val;

                                char phase2_param[4] = "";
                                int phase2_val = 0;
                                if (httpd_query_key_value(buf, "ttls_phase2", phase2_param, sizeof(phase2_param)) == ESP_OK) {
                                    phase2_val = atoi(phase2_param);
                                }
                                set_config_param_int("ttls_phase2", phase2_val);
                                ttls_phase2 = phase2_val;

                                // Checkboxes: present = 1, absent = 0
                                char cb_param[4] = "";
                                int cb_val = 0;
                                if (httpd_query_key_value(buf, "cert_bundle", cb_param, sizeof(cb_param)) == ESP_OK) {
                                    cb_val = 1;
                                }
                                set_config_param_int("cert_bundle", cb_val);
                                use_cert_bundle = cb_val;

                                int tc_val = 0;
                                if (httpd_query_key_value(buf, "no_time_chk", cb_param, sizeof(cb_param)) == ESP_OK) {
                                    tc_val = 1;
                                }
                                set_config_param_int("no_time_chk", tc_val);
                                disable_time_check = tc_val;
                            }

#if WIFI_HAS_5GHZ
                            // Save STA band preference
                            {
                                char band_param[4] = "";
                                int band_val = STA_BAND_AUTO;
                                if (httpd_query_key_value(buf, "sta_band", band_param, sizeof(band_param)) == ESP_OK) {
                                    band_val = atoi(band_param);
                                    if (band_val < STA_BAND_AUTO || band_val > STA_BAND_5G)
                                        band_val = STA_BAND_AUTO;
                                }
                                set_config_param_int("sta_band", band_val);
                                sta_band = (uint8_t)band_val;
                            }
#endif

                            // Check for optional STA MAC address
                            if (httpd_query_key_value(buf, "sta_mac", param5, sizeof(param5)) == ESP_OK && strlen(param5) > 0) {
                                ESP_LOGI(TAG, "Found URL query parameter => sta_mac=%s", param5);
                                preprocess_string(param5);
                                // Parse MAC address string (format: AA:BB:CC:DD:EE:FF)
                                unsigned int mac[6];
                                if (sscanf(param5, "%02x:%02x:%02x:%02x:%02x:%02x",
                                           &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) == 6) {
                                    char mac_str[6][4];
                                    for (int i = 0; i < 6; i++) {
                                        sprintf(mac_str[i], "%d", mac[i]);
                                    }
                                    char* mac_argv[7];
                                    mac_argv[0] = "set_sta_mac";
                                    for (int i = 0; i < 6; i++) {
                                        mac_argv[i+1] = mac_str[i];
                                    }
                                    set_sta_mac(7, mac_argv);
                                }
                            }

                            esp_timer_start_once(restart_timer, 500000);
                        }
                    }
                }
            }
#endif

            /* Handle static IP settings */
            if (httpd_query_key_value(buf, "staticip", param1, sizeof(param1)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => staticip=%s", param1);
                preprocess_string(param1);
                if (httpd_query_key_value(buf, "subnetmask", param2, sizeof(param2)) == ESP_OK) {
                    ESP_LOGI(TAG, "Found URL query parameter => subnetmask=%s", param2);
                    preprocess_string(param2);
                    if (httpd_query_key_value(buf, "gateway", param3, sizeof(param3)) == ESP_OK) {
                        ESP_LOGI(TAG, "Found URL query parameter => gateway=%s", param3);
                        preprocess_string(param3);
                        int argc = 4;
                        char* argv[4];
                        argv[0] = "set_sta_static";
                        argv[1] = param1;
                        argv[2] = param2;
                        argv[3] = param3;
                        set_sta_static(argc, argv);
                        esp_timer_start_once(restart_timer, 500000);
                    }
                }
            }

            /* Handle Remote Console settings (single form) */
            if (httpd_query_key_value(buf, "rc_save", param1, sizeof(param1)) == ESP_OK) {
                /* Enable/disable */
                if (httpd_query_key_value(buf, "rc_enabled", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    if (strcmp(param1, "1") == 0) {
                        remote_console_enable();
                    } else {
                        remote_console_disable();
                    }
                }
                /* Port */
                if (httpd_query_key_value(buf, "rc_port", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    int port = atoi(param1);
                    if (port >= 1 && port <= 65535) {
                        remote_console_set_port((uint16_t)port);
                    }
                }
                /* Bind interfaces (checkboxes: absent = unchecked) */
                uint8_t bind = 0;
                if (httpd_query_key_value(buf, "rc_bind_ap", param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_AP;
                if (httpd_query_key_value(buf, "rc_bind_sta", param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_STA;
                if (httpd_query_key_value(buf, "rc_bind_vpn", param1, sizeof(param1)) == ESP_OK) bind |= RC_BIND_VPN;
                if (bind == 0) bind = RC_BIND_AP;
                remote_console_set_bind(bind);
                /* Timeout */
                if (httpd_query_key_value(buf, "rc_timeout", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    int timeout = atoi(param1);
                    if (timeout >= 0) {
                        remote_console_set_timeout((uint32_t)timeout);
                    }
                }
                ESP_LOGI(TAG, "Remote console settings saved via web");
                free(buf);
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/config");
                httpd_resp_send(req, NULL, 0);
                return ESP_OK;
            }

            /* Handle Remote Console kick */
            if (httpd_query_key_value(buf, "rc_kick", param1, sizeof(param1)) == ESP_OK) {
                remote_console_kick();
                ESP_LOGI(TAG, "Remote console session kicked via web");
                free(buf);
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/config");
                httpd_resp_send(req, NULL, 0);
                return ESP_OK;
            }

            /* Handle PCAP settings (single form) */
            if (httpd_query_key_value(buf, "pcap_save", param1, sizeof(param1)) == ESP_OK) {
                if (httpd_query_key_value(buf, "pcap_mode", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    if (strcmp(param1, "off") == 0) {
                        pcap_set_mode(PCAP_MODE_OFF);
                    } else if (strcmp(param1, "acl") == 0) {
                        pcap_set_mode(PCAP_MODE_ACL_MONITOR);
                    } else if (strcmp(param1, "promisc") == 0) {
                        pcap_set_mode(PCAP_MODE_PROMISCUOUS);
                    }
                }
                if (httpd_query_key_value(buf, "pcap_snaplen", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    int snaplen = atoi(param1);
                    if (snaplen >= 64 && snaplen <= 1600) {
                        pcap_set_snaplen((uint16_t)snaplen);
                    }
                }
                ESP_LOGI(TAG, "PCAP settings saved via web");
                free(buf);
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/config");
                httpd_resp_send(req, NULL, 0);
                return ESP_OK;
            }

            /* Handle antenna switch settings (single form) */
            if (httpd_query_key_value(buf, "ant_save", param1, sizeof(param1)) == ESP_OK) {
                int new_gpio = antenna_gpio;
                int new_en = antenna_en_gpio;
                int new_sel = antenna_state;
                if (httpd_query_key_value(buf, "ant_gpio", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    parse_gpio_field(param1, &new_gpio);
                }
                if (httpd_query_key_value(buf, "ant_en", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    parse_gpio_field(param1, &new_en);
                }
                if (httpd_query_key_value(buf, "ant_sel", param1, sizeof(param1)) == ESP_OK) {
                    preprocess_string(param1);
                    new_sel = (strcmp(param1, "1") == 0) ? 1 : 0;
                }
                if (antenna_switch_set(new_gpio, new_sel, new_en) == ESP_OK) {
                    ESP_LOGI(TAG, "Antenna switch settings saved via web");
                } else {
                    ESP_LOGW(TAG, "Antenna switch settings rejected (GPIO %d / enable %d)",
                             new_gpio, new_en);
                }
                free(buf);
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/config");
                httpd_resp_send(req, NULL, 0);
                return ESP_OK;
            }
        }
        free(buf);
    }

#if !CONFIG_ETH_UPLINK
    /* Check for SSID pre-fill from scan page */
    char prefill_ssid[64] = "";
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (buf != NULL && httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            if (httpd_query_key_value(buf, "ssid", prefill_ssid, sizeof(prefill_ssid)) == ESP_OK) {
                preprocess_string(prefill_ssid);
                ESP_LOGI(TAG, "Pre-filling SSID from scan: %s", prefill_ssid);
            }
        }
        if (buf) free(buf);
    }

    /* Escape values into stack buffers and release the heap copies immediately.
     * Holding html_escape() allocations across the chunked render below would
     * leak them whenever a SEND_CHUNK bails out on a dead client. */
    char safe_ssid[200], safe_ent_username[256], safe_ent_identity[256];
    html_escape_to(safe_ssid, sizeof(safe_ssid), prefill_ssid[0] ? prefill_ssid : ssid);
    html_escape_to(safe_ent_username, sizeof(safe_ent_username), ent_username);
    html_escape_to(safe_ent_identity, sizeof(safe_ent_identity), ent_identity);
#endif
    char safe_ap_ssid[200];
    html_escape_to(safe_ap_ssid, sizeof(safe_ap_ssid), ap_ssid);

    // Get current AP IP address.  Copy into a stack buffer and free the heap
    // copy now, for the same reason as the escaped strings above.
    char ap_ip_str[16] = "";
    {
        char *ap_ip_param = NULL;
        get_config_param_str("ap_ip", &ap_ip_param);
        if (ap_ip_param != NULL) {
            strlcpy(ap_ip_str, ap_ip_param, sizeof(ap_ip_str));
            free(ap_ip_param);
        } else {
            snprintf(ap_ip_str, sizeof(ap_ip_str), IPSTR, IP2STR((esp_ip4_addr_t *)&my_ap_ip));
        }
    }

    // Get MAC addresses as strings
    char ap_mac_str[18] = "";
    uint8_t mac[6];
    if (esp_wifi_get_mac(ESP_IF_WIFI_AP, mac) == ESP_OK) {
        sprintf(ap_mac_str, "%02X:%02X:%02X:%02X:%02X:%02X",
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    }
#if !CONFIG_ETH_UPLINK
    char sta_mac_str[18] = "";
    if (esp_wifi_get_mac(ESP_IF_WIFI_STA, mac) == ESP_OK) {
        sprintf(sta_mac_str, "%02X:%02X:%02X:%02X:%02X:%02X",
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    }
#endif

    // Remote Console state
    remote_console_config_t rc_config;
    remote_console_status_t rc_status;
    remote_console_get_config(&rc_config);
    remote_console_get_status(&rc_status);

    const char* ap_en_checked = ap_disabled ? "" : "checked";
    const char* ap_open_checked = (strlen(ap_passwd) == 0) ? "checked" : "";
    const char* ap_hidden_checked = ap_ssid_hidden ? "checked" : "";
    const char* rc_enabled_checked = rc_config.enabled ? "checked" : "";
    const char* rc_disabled_checked = rc_config.enabled ? "" : "checked";

    const char* rc_status_color;
    const char* rc_status_text;
    const char* rc_kick_section = "";
    char rc_kick_buf[200] = "";

    switch (rc_status.state) {
        case RC_STATE_DISABLED:
            rc_status_color = "#888";
            rc_status_text = "Disabled";
            break;
        case RC_STATE_LISTENING:
            rc_status_color = "#4caf50";
            rc_status_text = "Listening";
            break;
        case RC_STATE_AUTH_WAIT:
            rc_status_color = "#ffc107";
            rc_status_text = "Authenticating...";
            break;
        case RC_STATE_ACTIVE:
            rc_status_color = "#00d9ff";
            rc_status_text = rc_status.client_ip;
            snprintf(rc_kick_buf, sizeof(rc_kick_buf),
                " <a href='/config?rc_kick=1' style='margin-left: 0.5rem; padding: 0.2rem 0.6rem; background: #f44336; color: #fff; border-radius: 4px; text-decoration: none; font-size: 0.8rem;'>Kick</a>");
            rc_kick_section = rc_kick_buf;
            break;
        default:
            rc_status_color = "#888";
            rc_status_text = "Unknown";
            break;
    }

    const char* rc_ap_chk = (rc_config.bind & RC_BIND_AP) ? "checked" : "";
    const char* rc_sta_chk = (rc_config.bind & RC_BIND_STA) ? "checked" : "";
    const char* rc_vpn_chk = (rc_config.bind & RC_BIND_VPN) ? "checked" : "";

    // PCAP state
    pcap_capture_mode_t pcap_mode = pcap_get_mode();
    const char* pcap_mode_off_sel = (pcap_mode == PCAP_MODE_OFF) ? "selected" : "";
    const char* pcap_mode_acl_sel = (pcap_mode == PCAP_MODE_ACL_MONITOR) ? "selected" : "";
    const char* pcap_mode_promisc_sel = (pcap_mode == PCAP_MODE_PROMISCUOUS) ? "selected" : "";
    bool pcap_client = pcap_client_connected();
    const char* pcap_client_color = pcap_client ? "#4caf50" : "#888";
    const char* pcap_client_text = pcap_client ? "Connected" : "Not connected";
    uint32_t pcap_captured = pcap_get_captured_count();
    uint32_t pcap_dropped = pcap_get_dropped_count();
    int current_snaplen = pcap_get_snaplen();

    /* Reusable buffer for building sections.  Sized for the largest chunk
     * (STA settings): its worst case is ~2890 bytes once the escaped SSID /
     * enterprise identity fields are accounted for as fixed-size stack buffers. */
    char section[3072];

    /* --- Begin chunked response --- */

    /* Chunk 1: Page header (styles) */
    SEND_CHUNK(req, CONFIG_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Chunk 2: Logout button (if authenticated) */
    if (session_active && password_protection_enabled) {
        SEND_CHUNK(req,
            "<a href='/?logout=1' style='padding: 0.4rem 1rem; background: rgba(255,82,82,0.15); color: #ff5252; border: 1px solid #ff5252; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500;'>Logout</a>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 3: JavaScript */
    SEND_CHUNK(req, CONFIG_CHUNK_SCRIPT, HTTPD_RESP_USE_STRLEN);

    /* Chunk 4: AP Settings */
    const char* auth_sel0 = (ap_authmode == 0) ? "selected" : "";
    const char* auth_sel1 = (ap_authmode == 1) ? "selected" : "";
    const char* auth_sel2 = (ap_authmode == 2) ? "selected" : "";
    snprintf(section, sizeof(section), CONFIG_CHUNK_AP,
        safe_ap_ssid, ap_ip_str, hostname ? hostname : "", ap_dns ? ap_dns : "", ap_mac_str,
#if CONFIG_ETH_UPLINK
        (int)ap_channel,
#endif
        auth_sel0, auth_sel1, auth_sel2,
        ap_nat_enabled ? "checked" : "",
        ap_en_checked, ap_open_checked, ap_hidden_checked);
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);

#if CONFIG_ETH_UPLINK
    /* Chunk 5: ETH info */
    SEND_CHUNK(req,
        "<h2>Uplink Settings</h2><table><tr><td>Mode:</td><td>Ethernet (LAN8720)</td></tr></table>",
        HTTPD_RESP_USE_STRLEN);
#else
    /* Chunk 5: STA Settings */
    snprintf(section, sizeof(section), CONFIG_CHUNK_STA,
        safe_ssid, (strlen(passwd) == 0) ? "checked" : "",
#if WIFI_HAS_5GHZ
        sta_band == STA_BAND_AUTO ? "selected" : "",
        sta_band == STA_BAND_2G ? "selected" : "",
        sta_band == STA_BAND_5G ? "selected" : "",
#endif
        safe_ent_username, safe_ent_identity,
        eap_method == 0 ? "selected" : "", eap_method == 1 ? "selected" : "",
        eap_method == 2 ? "selected" : "", eap_method == 3 ? "selected" : "",
        ttls_phase2 == 0 ? "selected" : "", ttls_phase2 == 1 ? "selected" : "",
        ttls_phase2 == 2 ? "selected" : "", ttls_phase2 == 3 ? "selected" : "",
        use_cert_bundle ? "checked" : "", disable_time_check ? "checked" : "",
        sta_mac_str);
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);
#endif

    /* Chunk 6: Static IP Settings */
    snprintf(section, sizeof(section), CONFIG_CHUNK_STATIC,
        static_ip, subnet_mask, gateway_addr);
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);

    /* Chunk 7: Remote Console */
    char rc_fp[64];
    remote_console_get_hostkey_fingerprint(rc_fp, sizeof(rc_fp));
    snprintf(section, sizeof(section), CONFIG_CHUNK_RC,
        rc_enabled_checked, rc_disabled_checked,
        rc_status_color, rc_status_text, rc_kick_section,
        rc_config.port,
        rc_ap_chk, rc_sta_chk, rc_vpn_chk,
        (unsigned long)rc_config.idle_timeout_sec, rc_fp);
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);

    /* Chunk 8: PCAP */
    char sta_ip_str[16];
    {
        ip4_addr_t sta_addr;
        sta_addr.addr = my_ip;
        snprintf(sta_ip_str, sizeof(sta_ip_str), IPSTR, IP2STR(&sta_addr));
    }
    snprintf(section, sizeof(section), CONFIG_CHUNK_PCAP,
        pcap_mode_off_sel, pcap_mode_acl_sel, pcap_mode_promisc_sel,
        pcap_client_color, pcap_client_text,
        (unsigned long)pcap_captured, (unsigned long)pcap_dropped,
        current_snaplen, sta_ip_str);
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);

    /* Chunk 8a: Antenna switch */
    {
        const char* ant_color = (antenna_gpio < 0) ? "#888" : "#4caf50";
        const char* ant_text;
        if (antenna_gpio < 0) {
            ant_text = "Disabled";
        } else {
            ant_text = antenna_state ? "Active - external antenna"
                                     : "Active - on-board antenna";
        }
        snprintf(section, sizeof(section), CONFIG_CHUNK_ANT,
            antenna_gpio, antenna_en_gpio,
            antenna_state ? "" : "selected",
            antenna_state ? "selected" : "",
            ant_color, ant_text);
        SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 8b: TTL rewrite (static HTML, data loaded via /api/ttl) */
    SEND_CHUNK(req, CONFIG_CHUNK_TTL, HTTPD_RESP_USE_STRLEN);

    /* Chunk 9: Device management heading */
    SEND_CHUNK(req, CONFIG_CHUNK_TAIL, HTTPD_RESP_USE_STRLEN);

    /* Chunk 9a: Dynamic OTA info (running partition, version, chip) */
    {
        esp_chip_info_t chip_info;
        esp_chip_info(&chip_info);
        const char *chip_model;
        switch (chip_info.model) {
            case CHIP_ESP32:   chip_model = "ESP32"; break;
            case CHIP_ESP32S2: chip_model = "ESP32-S2"; break;
            case CHIP_ESP32S3: chip_model = "ESP32-S3"; break;
            case CHIP_ESP32C3: chip_model = "ESP32-C3"; break;
            case CHIP_ESP32C2: chip_model = "ESP32-C2"; break;
            case CHIP_ESP32C5: chip_model = "ESP32-C5"; break;
            case CHIP_ESP32C6: chip_model = "ESP32-C6"; break;
            case CHIP_ESP32H2: chip_model = "ESP32-H2"; break;
            default:           chip_model = "Unknown"; break;
        }
        const esp_partition_t *running = esp_ota_get_running_partition();
        const esp_app_desc_t *app_desc = esp_app_get_description();
        snprintf(section, sizeof(section),
            "<table>"
            "<tr><td>Running</td><td>%s</td></tr>"
            "<tr><td>Chip</td><td>%s</td></tr>"
            "<tr><td>Version</td><td>%s</td></tr>"
            "<tr><td>Built</td><td>%s %s</td></tr>"
            "</table>",
            running ? running->label : "unknown",
            chip_model,
            app_desc ? app_desc->version : "unknown",
            app_desc ? app_desc->date : "", app_desc ? app_desc->time : "");
        SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 9b: OTA upload form, config backup/restore, reboot */
    SEND_CHUNK(req, CONFIG_CHUNK_TAIL2, HTTPD_RESP_USE_STRLEN);

    /* Chunk 9c: Danger Zone (web bind + disable interface).
     * Uses its own buffer — CONFIG_CHUNK_DANGER exceeds the shared section[2048]. */
    {
        char danger[2560];
        snprintf(danger, sizeof(danger), CONFIG_CHUNK_DANGER,
            (s_web_bind & RC_BIND_AP)  ? "checked" : "",
            (s_web_bind & RC_BIND_STA) ? "checked" : "",
            (s_web_bind & RC_BIND_VPN) ? "checked" : "");
        SEND_CHUNK(req, danger, HTTPD_RESP_USE_STRLEN);
    }

    /* End chunked response */
    SEND_CHUNK(req, NULL, 0);

    /* No cleanup needed: all escaped values live in stack buffers (the heap
     * copies were freed before streaming began). */
    return ESP_OK;
}

static httpd_uri_t configp = {
    .uri       = "/config",
    .method    = HTTP_GET,
    .handler   = config_get_handler,
};

/* Mappings page GET handler (DHCP Reservations + Port Forwarding) - Chunked transfer */
static esp_err_t mappings_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    /* Check authentication if password protection is enabled */
    bool password_protection_enabled = is_web_password_set();

    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /mappings from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        /* Redirect to index page with auth_required flag */
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    char* buf;
    size_t buf_len;
    char error_msg[128] = "";

    /* Read URL query string length and allocate memory for length + 1 */
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (buf == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for query string");
            httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
            return ESP_ERR_NO_MEM;
        }

        if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found URL query => %s", buf);

            char param1[64];
            char param2[64];
            char param3[64];
            char param4[64];

            /* Check for error parameter first */
            if (httpd_query_key_value(buf, "error", param1, sizeof(param1)) == ESP_OK) {
                /* Decode + back to spaces */
                for (char *p = param1; *p; p++) {
                    if (*p == '+') *p = ' ';
                }
                /* Reflected straight back into the page below, so it has to be
                 * escaped here — the value comes from the URL, which anyone can
                 * craft and hand to an admin. */
                html_escape_to(error_msg, sizeof(error_msg), param1);
            }

            /* "Allow only known clients" switch (checkbox absent = off) */
            if (httpd_query_key_value(buf, "set_known", param1, sizeof(param1)) == ESP_OK) {
                int known_val = (httpd_query_key_value(buf, "known_only", param1, sizeof(param1)) == ESP_OK) ? 1 : 0;
                set_config_param_int("ap_known_only", known_val);
                ap_known_only = (uint8_t)known_val;
                ESP_LOGI(TAG, "AP known clients only set to: %d", known_val);

                /* Redirect so a reload does not resubmit the switch */
                httpd_resp_set_status(req, "303 See Other");
                httpd_resp_set_hdr(req, "Location", "/mappings");
                httpd_resp_send(req, NULL, 0);
                free(buf);
                return ESP_OK;
            }

            /* Check for add DHCP reservation */
            if (httpd_query_key_value(buf, "dhcp_action", param1, sizeof(param1)) == ESP_OK) {
                bool is_block = (strcmp(param1, "Block") == 0);
                if (strcmp(param1, "Add+Reservation") == 0 || strcmp(param1, "Add Reservation") == 0 || is_block) {
                    if (httpd_query_key_value(buf, "dhcp_mac", param1, sizeof(param1)) == ESP_OK &&
                        httpd_query_key_value(buf, "dhcp_ip", param2, sizeof(param2)) == ESP_OK) {

                        preprocess_string(param1);
                        preprocess_string(param2);

                        const char *err_msg = NULL;

                        // Parse MAC address
                        unsigned int mac[6];
                        uint8_t mac_bytes[6];
                        if (sscanf(param1, "%02x:%02x:%02x:%02x:%02x:%02x",
                                   &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) != 6 &&
                            sscanf(param1, "%02x-%02x-%02x-%02x-%02x-%02x",
                                   &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) != 6) {
                            err_msg = "Invalid MAC address format";
                        } else {
                            for (int i = 0; i < 6; i++) {
                                mac_bytes[i] = (uint8_t)mac[i];
                            }

                            uint32_t ip = is_block ? 0 : esp_ip4addr_aton(param2);
                            if (!is_block && ip == IPADDR_NONE) {
                                err_msg = "Invalid IP address";
                            } else if (!is_block && (ip & 0x00FFFFFF) != (my_ap_ip & 0x00FFFFFF)) {
                                err_msg = "IP must be in the same network as the AP";
                            } else {
                                const char *name = NULL;
                                if (httpd_query_key_value(buf, "dhcp_name", param3, sizeof(param3)) == ESP_OK && strlen(param3) > 0) {
                                    preprocess_string(param3);
                                    name = param3;
                                }
                                add_dhcp_reservation(mac_bytes, ip, name);
                                ESP_LOGI(TAG, "Added DHCP reservation: %s -> %s", param1, param2);
                            }
                        }

                        if (err_msg != NULL) {
                            /* Redirect back with error parameter */
                            char redirect_url[128];
                            snprintf(redirect_url, sizeof(redirect_url), "/mappings?error=%s", err_msg);
                            for (char *p = redirect_url; *p; p++) {
                                if (*p == ' ') *p = '+';
                            }
                            httpd_resp_set_status(req, "303 See Other");
                            httpd_resp_set_hdr(req, "Location", redirect_url);
                            httpd_resp_send(req, NULL, 0);
                            free(buf);
                            return ESP_OK;
                        }
                    }
                }
            }

            /* Check for delete DHCP reservation */
            if (httpd_query_key_value(buf, "del_dhcp_mac", param1, sizeof(param1)) == ESP_OK) {
                preprocess_string(param1);
                unsigned int mac[6];
                if (sscanf(param1, "%02X:%02X:%02X:%02X:%02X:%02X",
                           &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) == 6 ||
                    sscanf(param1, "%02x:%02x:%02x:%02x:%02x:%02x",
                           &mac[0], &mac[1], &mac[2], &mac[3], &mac[4], &mac[5]) == 6) {
                    uint8_t mac_bytes[6];
                    for (int i = 0; i < 6; i++) {
                        mac_bytes[i] = (uint8_t)mac[i];
                    }
                    del_dhcp_reservation(mac_bytes);
                    ESP_LOGI(TAG, "Deleted DHCP reservation: %s", param1);
                }
            }

            /* Check for add port mapping */
            if (httpd_query_key_value(buf, "port_action", param1, sizeof(param1)) == ESP_OK) {
                if (strcmp(param1, "Add+Forward") == 0 || strcmp(param1, "Add Forward") == 0) {
                    if (httpd_query_key_value(buf, "proto", param1, sizeof(param1)) == ESP_OK &&
                        httpd_query_key_value(buf, "ext_port", param2, sizeof(param2)) == ESP_OK &&
                        httpd_query_key_value(buf, "int_ip", param3, sizeof(param3)) == ESP_OK &&
                        httpd_query_key_value(buf, "int_port", param4, sizeof(param4)) == ESP_OK) {

                        preprocess_string(param3);
                        uint8_t proto = (strcmp(param1, "TCP") == 0) ? PROTO_TCP : PROTO_UDP;
                        uint16_t ext_port = atoi(param2);
                        uint32_t int_ip = esp_ip4addr_aton(param3);

                        /* If IP parsing failed, try resolving as device name */
                        if (int_ip == IPADDR_NONE) {
                            if (!resolve_device_name_to_ip(param3, &int_ip)) {
                                ESP_LOGW(TAG, "Invalid IP or device name: %s", param3);
                            }
                        }
                        uint16_t int_port = atoi(param4);

                        /* Validate internal IP is in same /24 network as AP interface */
                        const char *err_msg = NULL;
                        if (int_ip == IPADDR_NONE) {
                            err_msg = "Invalid IP address or device name";
                        } else if ((int_ip & 0x00FFFFFF) != (my_ap_ip & 0x00FFFFFF)) {
                            esp_ip4_addr_t ap_addr;
                            ap_addr.addr = my_ap_ip;
                            ESP_LOGW(TAG, "Internal IP not in AP network (" IPSTR "/24)", IP2STR(&ap_addr));
                            err_msg = "Internal IP must be in the same network as the AP";
                        } else {
                            /* Check if external port is already in use for this protocol */
                            for (int i = 0; i < IP_PORTMAP_MAX; i++) {
                                if (portmap_tab[i].valid &&
                                    portmap_tab[i].proto == proto &&
                                    portmap_tab[i].mport == ext_port) {
                                    ESP_LOGW(TAG, "External port %d already mapped", ext_port);
                                    err_msg = "External port is already in use";
                                    break;
                                }
                            }
                        }

                        if (err_msg == NULL) {
                            uint8_t iface = 0;  // Default: STA
                            char iface_param[8];
                            if (httpd_query_key_value(buf, "iface", iface_param, sizeof(iface_param)) == ESP_OK) {
                                if (strcmp(iface_param, "VPN") == 0) iface = 1;
                            }
                            add_portmap(proto, ext_port, int_ip, int_port, iface);
#if CONFIG_ETH_UPLINK
                            ESP_LOGI(TAG, "Added port mapping: %s %s %d -> %s:%d",
                                     iface ? "VPN" : "ETH", param1, ext_port, param3, int_port);
#else
                            ESP_LOGI(TAG, "Added port mapping: %s %s %d -> %s:%d",
                                     iface ? "VPN" : "STA", param1, ext_port, param3, int_port);
#endif
                        } else {
                            /* Redirect back with error parameter */
                            char redirect_url[128];
                            snprintf(redirect_url, sizeof(redirect_url), "/mappings?error=%s", err_msg);
                            /* URL encode spaces */
                            for (char *p = redirect_url; *p; p++) {
                                if (*p == ' ') *p = '+';
                            }
                            httpd_resp_set_status(req, "303 See Other");
                            httpd_resp_set_hdr(req, "Location", redirect_url);
                            httpd_resp_send(req, NULL, 0);
                            free(buf);
                            return ESP_OK;
                        }
                    }
                }
            }

            /* Check for delete port mapping */
            if (httpd_query_key_value(buf, "del_proto", param1, sizeof(param1)) == ESP_OK &&
                httpd_query_key_value(buf, "del_port", param2, sizeof(param2)) == ESP_OK) {
                uint8_t proto = (strcmp(param1, "TCP") == 0) ? PROTO_TCP : PROTO_UDP;
                uint16_t port = atoi(param2);
                del_portmap(proto, port);
                ESP_LOGI(TAG, "Deleted port mapping: %s %d", param1, port);
            }
        }
        free(buf);
    }

    /* Reusable buffer for building individual rows */
    char row[384];

    /* --- Begin chunked response --- */

    /* Chunk 1: Page header (styles, scripts) */
    SEND_CHUNK(req, MAPPINGS_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Chunk 2: Error modal (if any) */
    if (error_msg[0] != '\0') {
        snprintf(row, sizeof(row),
            "<div class='modal-overlay show' id='errorModal'>"
            "<div class='modal-box'>"
            "<h3>Error</h3>"
            "<p>%s</p>"
            "<button onclick=\"document.getElementById('errorModal').classList.remove('show'); history.replaceState(null, '', '/mappings');\">OK</button>"
            "</div>"
            "</div>",
            error_msg);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 3: Container start and header */
    SEND_CHUNK(req, MAPPINGS_CHUNK_MID1, HTTPD_RESP_USE_STRLEN);

    /* Chunk 4: Logout button (if authenticated) */
    if (session_active && password_protection_enabled) {
        SEND_CHUNK(req,
            "<a href='/?logout=1' style='padding: 0.4rem 1rem; background: rgba(255,82,82,0.15); color: #ff5252; border: 1px solid #ff5252; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500;'>Logout</a>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 5: Connected clients table header */
    SEND_CHUNK(req,
        client_stats_enabled ? MAPPINGS_CHUNK_MID2 : MAPPINGS_CHUNK_MID2_NOSTATS,
        HTTPD_RESP_USE_STRLEN);

    /* Chunk 6: Stream connected clients rows */
    #define MAX_DISPLAYED_CLIENTS 8
    connected_client_t clients[MAX_DISPLAYED_CLIENTS];
    int client_count = get_connected_clients(clients, MAX_DISPLAYED_CLIENTS);
    connect_count = client_count;

    /* Fetch per-client traffic stats only when enabled */
    client_stats_entry_t stats[CLIENT_STATS_MAX];
    int stats_count = client_stats_enabled ? client_stats_get_all(stats, CLIENT_STATS_MAX) : 0;

    if (client_count > 0) {
        for (int i = 0; i < client_count; i++) {
            char ip_str[16] = "-";
            if (clients[i].has_ip) {
                esp_ip4_addr_t addr;
                addr.addr = clients[i].ip;
                snprintf(ip_str, sizeof(ip_str), IPSTR, IP2STR(&addr));
            }

            char mac_str[18];
            snprintf(mac_str, sizeof(mac_str), "%02X:%02X:%02X:%02X:%02X:%02X",
                clients[i].mac[0], clients[i].mac[1],
                clients[i].mac[2], clients[i].mac[3],
                clients[i].mac[4], clients[i].mac[5]);

            /* This lands inside onclick="fillDhcpForm('...')" — an HTML
             * attribute wrapping a JavaScript string literal, which needs two
             * layers of escaping to get right. Restricting the value to a safe
             * alphabet sidesteps both; device names are hostnames, so nothing
             * legitimate is lost. Escaping only the apostrophe, as this did
             * before, left <, ", and backslash to break out. */
            char js_name[DHCP_RESERVATION_NAME_LEN];
            const char *src_name = clients[i].name[0] ? clients[i].name : "";
            int j = 0;
            for (int k = 0; src_name[k] && j < (int)sizeof(js_name) - 1; k++) {
                char c = src_name[k];
                bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                          (c >= '0' && c <= '9') || c == '-' || c == '.' ||
                          c == '_' || c == ' ';
                js_name[j++] = ok ? c : '_';
            }
            js_name[j] = '\0';

            if (client_stats_enabled) {
                /* Find matching traffic stats by MAC */
                char traffic_str[32] = "-";
                for (int s = 0; s < stats_count; s++) {
                    if (memcmp(stats[s].mac, clients[i].mac, 6) == 0) {
                        char tx_buf[12], rx_buf[12];
                        format_bytes_human(stats[s].bytes_sent, tx_buf, sizeof(tx_buf));
                        format_bytes_human(stats[s].bytes_received, rx_buf, sizeof(rx_buf));
                        snprintf(traffic_str, sizeof(traffic_str), "%s / %s", tx_buf, rx_buf);
                        break;
                    }
                }
                snprintf(row, sizeof(row),
                    "<tr>"
                    "<td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                    "<td><button type='button' class='select-button' onclick=\"fillDhcpForm('%s','%s','%s')\">Select</button></td>"
                    "</tr>",
                    mac_str, ip_str, js_name[0] ? js_name : "-", traffic_str,
                    mac_str, clients[i].has_ip ? ip_str : "", js_name);
            } else {
                snprintf(row, sizeof(row),
                    "<tr>"
                    "<td>%s</td><td>%s</td><td>%s</td>"
                    "<td><button type='button' class='select-button' onclick=\"fillDhcpForm('%s','%s','%s')\">Select</button></td>"
                    "</tr>",
                    mac_str, ip_str, js_name[0] ? js_name : "-",
                    mac_str, clients[i].has_ip ? ip_str : "", js_name);
            }
            SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
        }
    } else {
        SEND_CHUNK(req,
            client_stats_enabled
                ? "<tr><td colspan='5' style='text-align:center; color:#888;'>No clients connected</td></tr>"
                : "<tr><td colspan='4' style='text-align:center; color:#888;'>No clients connected</td></tr>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 7: DHCP reservations heading */
    SEND_CHUNK(req, MAPPINGS_CHUNK_MID3, HTTPD_RESP_USE_STRLEN);

    /* DHCP Pool info */
    {
        uint32_t start_ip, end_ip;
        get_dhcp_pool_range(my_ap_ip, &start_ip, &end_ip);
        esp_ip4_addr_t start_addr, end_addr;
        start_addr.addr = start_ip;
        end_addr.addr = end_ip;
        snprintf(row, sizeof(row),
                 "<small style='color:#888;'>Pool: " IPSTR " - " IPSTR "</small>",
                 IP2STR(&start_addr), IP2STR(&end_addr));
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* "Allow only known clients" switch */
    SEND_CHUNK(req, MAPPINGS_CHUNK_KNOWN_PRE, HTTPD_RESP_USE_STRLEN);
    /* Never send an empty chunk: length 0 terminates the chunked response */
    if (ap_known_only) {
        SEND_CHUNK(req, "checked", HTTPD_RESP_USE_STRLEN);
    }
    SEND_CHUNK(req, MAPPINGS_CHUNK_KNOWN_POST, HTTPD_RESP_USE_STRLEN);

    /* DHCP reservations table header */
    SEND_CHUNK(req, MAPPINGS_CHUNK_MID3B, HTTPD_RESP_USE_STRLEN);

    /* Chunk 8: Stream DHCP reservation rows */
    bool has_reservations = false;
    for (int i = 0; i < MAX_DHCP_RESERVATIONS; i++) {
        if (dhcp_reservations[i].valid) {
            has_reservations = true;
            char ip_col[64];
            if (dhcp_reservations[i].ip == 0) {
                snprintf(ip_col, sizeof(ip_col), "<span style='color:#ff5252;font-weight:bold;'>BLOCKED</span>");
            } else {
                esp_ip4_addr_t addr;
                addr.addr = dhcp_reservations[i].ip;
                snprintf(ip_col, sizeof(ip_col), IPSTR, IP2STR(&addr));
            }

            snprintf(row, sizeof(row),
                "<tr>"
                "<td>%02X:%02X:%02X:%02X:%02X:%02X</td>"
                "<td>%s</td>"
                "<td>%s</td>"
                "<td><a href='/mappings?del_dhcp_mac=%02X:%02X:%02X:%02X:%02X:%02X' class='red-button'>Delete</a></td>"
                "</tr>",
                dhcp_reservations[i].mac[0], dhcp_reservations[i].mac[1],
                dhcp_reservations[i].mac[2], dhcp_reservations[i].mac[3],
                dhcp_reservations[i].mac[4], dhcp_reservations[i].mac[5],
                ip_col,
                dhcp_reservations[i].name[0] ? dhcp_reservations[i].name : "-",
                dhcp_reservations[i].mac[0], dhcp_reservations[i].mac[1],
                dhcp_reservations[i].mac[2], dhcp_reservations[i].mac[3],
                dhcp_reservations[i].mac[4], dhcp_reservations[i].mac[5]
            );
            SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
        }
    }

    if (!has_reservations) {
        SEND_CHUNK(req,
            "<tr><td colspan='4' style='text-align:center; color:#888;'>No DHCP reservations configured</td></tr>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 9: DHCP reservation form */
    SEND_CHUNK(req, MAPPINGS_CHUNK_MID4, HTTPD_RESP_USE_STRLEN);

    /* Chunk 10: Port forwarding section (hidden when NAT is disabled) */
    if (ap_nat_enabled) {
        SEND_CHUNK(req, MAPPINGS_CHUNK_PORTFWD_HEAD, HTTPD_RESP_USE_STRLEN);

        bool has_mappings = false;
        for (int i = 0; i < IP_PORTMAP_MAX; i++) {
            if (portmap_tab[i].valid) {
                has_mappings = true;

                const char *name = lookup_device_name_by_ip(portmap_tab[i].daddr);
                char ip_or_name[DHCP_RESERVATION_NAME_LEN];
                if (name) {
                    snprintf(ip_or_name, sizeof(ip_or_name), "%s", name);
                } else {
                    esp_ip4_addr_t addr;
                    addr.addr = portmap_tab[i].daddr;
                    snprintf(ip_or_name, sizeof(ip_or_name), IPSTR, IP2STR(&addr));
                }

                snprintf(row, sizeof(row),
                    "<tr>"
                    "<td>%s</td>"
                    "<td>%s</td>"
                    "<td>%d</td>"
                    "<td>%s</td>"
                    "<td>%d</td>"
                    "<td><a href='/mappings?del_proto=%s&del_port=%d' class='red-button'>Delete</a></td>"
                    "</tr>",
#if CONFIG_ETH_UPLINK
                    portmap_tab[i].iface == 1 ? "VPN" : "ETH",
#else
                    portmap_tab[i].iface == 1 ? "VPN" : "STA",
#endif
                    portmap_tab[i].proto == PROTO_TCP ? "TCP" : "UDP",
                    portmap_tab[i].mport,
                    ip_or_name,
                    portmap_tab[i].dport,
                    portmap_tab[i].proto == PROTO_TCP ? "TCP" : "UDP",
                    portmap_tab[i].mport
                );
                SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
            }
        }

        if (!has_mappings) {
            SEND_CHUNK(req,
                "<tr><td colspan='6' style='text-align:center; color:#888;'>No port mappings configured</td></tr>",
                HTTPD_RESP_USE_STRLEN);
        }

        SEND_CHUNK(req, MAPPINGS_CHUNK_PORTFWD_TAIL, HTTPD_RESP_USE_STRLEN);
    } else {
        SEND_CHUNK(req,
            "<div class='section'><p style='color:#888; padding: 0.5rem 0;'>Port forwarding is not available in routed mode (NAT disabled).</p></div>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 11: Page footer */
    SEND_CHUNK(req, MAPPINGS_CHUNK_PAGE_FOOTER, HTTPD_RESP_USE_STRLEN);

    /* End chunked response */
    SEND_CHUNK(req, NULL, 0);

    return ESP_OK;
}

static httpd_uri_t mappingsp = {
    .uri       = "/mappings",
    .method    = HTTP_GET,
    .handler   = mappings_get_handler,
};

/* Firewall (ACL) page GET handler */
static esp_err_t firewall_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    /* Check authentication if password protection is enabled */
    bool password_protection_enabled = is_web_password_set();

    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /firewall from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        /* Redirect to index page with auth_required flag */
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    char* buf;
    size_t buf_len;
    bool action_performed = false;
    char error_msg[128] = "";

    /* Read URL query string length and allocate memory for length + 1 */
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (buf == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for query string");
            httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
            return ESP_ERR_NO_MEM;
        }

        if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Firewall query => %s", buf);

            char param[64];

            /* Check for error parameter first */
            char error_param[128];
            if (httpd_query_key_value(buf, "error", error_param, sizeof(error_param)) == ESP_OK) {
                /* Decode + back to spaces */
                for (char *p = error_param; *p; p++) {
                    if (*p == '+') *p = ' ';
                }
                /* Reflected straight back into the page below — escape it. */
                html_escape_to(error_msg, sizeof(error_msg), error_param);
            }

            /* Handle Add Rule */
            if (httpd_query_key_value(buf, "acl_action", param, sizeof(param)) == ESP_OK) {
                if (strcmp(param, "Add+Rule") == 0 || strcmp(param, "Add Rule") == 0) {
                    char list_str[8], proto_str[8], src_ip_str[32], src_port_str[8];
                    char dst_ip_str[32], dst_port_str[8], action_str[8];

                    if (httpd_query_key_value(buf, "acl_list", list_str, sizeof(list_str)) == ESP_OK &&
                        httpd_query_key_value(buf, "proto", proto_str, sizeof(proto_str)) == ESP_OK &&
                        httpd_query_key_value(buf, "src_ip", src_ip_str, sizeof(src_ip_str)) == ESP_OK &&
                        httpd_query_key_value(buf, "dst_ip", dst_ip_str, sizeof(dst_ip_str)) == ESP_OK &&
                        httpd_query_key_value(buf, "action", action_str, sizeof(action_str)) == ESP_OK) {

                        preprocess_string(src_ip_str);
                        preprocess_string(dst_ip_str);

                        uint8_t list_no = atoi(list_str);
                        uint8_t proto = atoi(proto_str);
                        uint8_t action = atoi(action_str);

                        const char *validation_error = NULL;

                        /* Parse source IP (try IP/CIDR first, then device name) */
                        uint32_t src_ip, src_mask;
                        if (strlen(src_ip_str) == 0) {
                            src_ip = 0;
                            src_mask = 0;  /* any */
                        } else if (!acl_parse_ip(src_ip_str, &src_ip, &src_mask)) {
                            /* Try resolving as device name */
                            if (resolve_device_name_to_ip(src_ip_str, &src_ip)) {
                                src_mask = 0xFFFFFFFF;  /* /32 for device names */
                            } else {
                                validation_error = "Invalid source IP address or device name";
                            }
                        }

                        /* Parse destination IP (try IP/CIDR first, then device name) */
                        uint32_t dst_ip, dst_mask;
                        if (validation_error == NULL) {
                            if (strlen(dst_ip_str) == 0) {
                                dst_ip = 0;
                                dst_mask = 0;  /* any */
                            } else if (!acl_parse_ip(dst_ip_str, &dst_ip, &dst_mask)) {
                                /* Try resolving as device name */
                                if (resolve_device_name_to_ip(dst_ip_str, &dst_ip)) {
                                    dst_mask = 0xFFFFFFFF;  /* /32 for device names */
                                } else {
                                    validation_error = "Invalid destination IP address or device name";
                                }
                            }
                        }

                        /* Parse ports */
                        uint16_t s_port = 0, d_port = 0;
                        if (httpd_query_key_value(buf, "src_port", src_port_str, sizeof(src_port_str)) == ESP_OK) {
                            preprocess_string(src_port_str);
                            if (strcmp(src_port_str, "*") != 0 && strlen(src_port_str) > 0) {
                                s_port = atoi(src_port_str);
                            }
                        }
                        if (httpd_query_key_value(buf, "dst_port", dst_port_str, sizeof(dst_port_str)) == ESP_OK) {
                            preprocess_string(dst_port_str);
                            if (strcmp(dst_port_str, "*") != 0 && strlen(dst_port_str) > 0) {
                                d_port = atoi(dst_port_str);
                            }
                        }

                        if (validation_error != NULL) {
                            /* Redirect back with error parameter */
                            char redirect_url[192];
                            snprintf(redirect_url, sizeof(redirect_url), "/firewall?error=%s", validation_error);
                            /* URL encode spaces */
                            for (char *p = redirect_url; *p; p++) {
                                if (*p == ' ') *p = '+';
                            }
                            httpd_resp_set_status(req, "303 See Other");
                            httpd_resp_set_hdr(req, "Location", redirect_url);
                            httpd_resp_send(req, NULL, 0);
                            free(buf);
                            return ESP_OK;
                        }

                        if (list_no < MAX_ACL_LISTS) {
                            if (acl_add(list_no, src_ip, src_mask, dst_ip, dst_mask, proto, s_port, d_port, action)) {
                                save_acl_rules();
                                ESP_LOGI(TAG, "Added ACL rule to list %d", list_no);
                                action_performed = true;
                            }
                        }
                    }
                }
            }

            /* Handle Delete Rule */
            if (httpd_query_key_value(buf, "del_acl", param, sizeof(param)) == ESP_OK) {
                uint8_t list_no = atoi(param);
                char idx_str[8];
                if (httpd_query_key_value(buf, "del_idx", idx_str, sizeof(idx_str)) == ESP_OK) {
                    uint8_t rule_idx = atoi(idx_str);
                    if (list_no < MAX_ACL_LISTS && acl_delete(list_no, rule_idx)) {
                        save_acl_rules();
                        ESP_LOGI(TAG, "Deleted ACL rule %d from list %d", rule_idx, list_no);
                        action_performed = true;
                    }
                }
            }

            /* Handle Clear List */
            if (httpd_query_key_value(buf, "clear_acl", param, sizeof(param)) == ESP_OK) {
                uint8_t list_no = atoi(param);
                if (list_no < MAX_ACL_LISTS) {
                    acl_clear(list_no);
                    save_acl_rules();
                    ESP_LOGI(TAG, "Cleared ACL list %d", list_no);
                    action_performed = true;
                }
            }
        }
        free(buf);
    }

    /* Redirect after action to prevent duplicate submissions on refresh */
    if (action_performed) {
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/firewall");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    /* Reusable buffer for building individual elements */
    char row[384];

    /* --- Begin chunked response --- */

    /* Chunk 1: Page header (styles) */
    SEND_CHUNK(req, FIREWALL_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Chunk 2: Error modal (if any) */
    if (error_msg[0] != '\0') {
        snprintf(row, sizeof(row),
            "<div class='modal-overlay show' id='errorModal'>"
            "<div class='modal-box'>"
            "<h3>Error</h3>"
            "<p>%s</p>"
            "<button onclick=\"document.getElementById('errorModal').classList.remove('show'); history.replaceState(null, '', '/firewall');\">OK</button>"
            "</div>"
            "</div>",
            error_msg);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 3: Container start and header */
    SEND_CHUNK(req, FIREWALL_CHUNK_MID1, HTTPD_RESP_USE_STRLEN);

    /* Chunk 4: Logout button (if authenticated) */
    if (session_active && password_protection_enabled) {
        SEND_CHUNK(req,
            "<a href='/?logout=1' style='padding: 0.4rem 1rem; background: rgba(255,82,82,0.15); color: #ff5252; border: 1px solid #ff5252; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500;'>Logout</a>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 5: Description text */
    SEND_CHUNK(req, FIREWALL_CHUNK_MID2, HTTPD_RESP_USE_STRLEN);

    /* Chunk 6: Stream ACL sections.
     * Copy data under lock then release before sending HTTP chunks,
     * because httpd_resp_send_chunk can block on TCP and would deadlock
     * with acl_check_packet holding the same lock in the netif hooks. */
    for (int list_no = 0; list_no < MAX_ACL_LISTS; list_no++) {
        /* Snapshot ACL data under the lock */
        acl_entry_t rules_copy[MAX_ACL_ENTRIES];
        acl_stats_t stats_copy;
        const char* list_desc;

        acl_lock();
        acl_entry_t* rules = acl_get_rules(list_no);
        acl_stats_t* stats = acl_get_stats(list_no);
        list_desc = acl_get_desc(list_no);
        memcpy(rules_copy, rules, sizeof(rules_copy));
        memcpy(&stats_copy, stats, sizeof(stats_copy));
        acl_unlock();

        /* Section header with stats (no lock held) */
        snprintf(row, sizeof(row),
            "<div class='acl-section'>"
            "<h3>%s</h3>"
            "<div class='stats'>"
            "<span class='allowed'>Allowed: %lu</span>"
            "<span class='denied'>Denied: %lu</span>"
            "<span>No match: %lu</span>"
            "<a href='/firewall?clear_acl=%d' class='orange-button' style='float:right;'>Clear</a>"
            "</div>",
            list_desc,
            (unsigned long)stats_copy.packets_allowed,
            (unsigned long)stats_copy.packets_denied,
            (unsigned long)stats_copy.packets_nomatch,
            list_no);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

        /* Rules table header */
        SEND_CHUNK(req,
            "<table class='data-table'>"
            "<thead><tr>"
            "<th>#</th><th>Proto</th><th>Source</th><th>SPort</th>"
            "<th>Dest</th><th>DPort</th><th>Action</th><th>Hits</th><th></th>"
            "</tr></thead><tbody>",
            HTTPD_RESP_USE_STRLEN);

        /* Stream rule rows from snapshot */
        int rule_count = 0;
        for (int i = 0; i < MAX_ACL_ENTRIES; i++) {
            if (!rules_copy[i].valid) continue;
            rule_count++;

            /* Format protocol */
            const char *proto_str;
            switch (rules_copy[i].proto) {
                case 0:  proto_str = "IP"; break;
                case 1:  proto_str = "ICMP"; break;
                case 6:  proto_str = "TCP"; break;
                case 17: proto_str = "UDP"; break;
                default: proto_str = "?"; break;
            }

            /* Format IP addresses with device names for /32 */
            char src_str[DHCP_RESERVATION_NAME_LEN], dst_str[DHCP_RESERVATION_NAME_LEN];
            if (rules_copy[i].s_mask == 0xFFFFFFFF) {
                const char* name = lookup_device_name_by_ip(rules_copy[i].src);
                if (name) {
                    snprintf(src_str, sizeof(src_str), "%s", name);
                } else {
                    acl_format_ip(rules_copy[i].src, rules_copy[i].s_mask, src_str, sizeof(src_str));
                }
            } else {
                acl_format_ip(rules_copy[i].src, rules_copy[i].s_mask, src_str, sizeof(src_str));
            }
            if (rules_copy[i].d_mask == 0xFFFFFFFF) {
                const char* name = lookup_device_name_by_ip(rules_copy[i].dest);
                if (name) {
                    snprintf(dst_str, sizeof(dst_str), "%s", name);
                } else {
                    acl_format_ip(rules_copy[i].dest, rules_copy[i].d_mask, dst_str, sizeof(dst_str));
                }
            } else {
                acl_format_ip(rules_copy[i].dest, rules_copy[i].d_mask, dst_str, sizeof(dst_str));
            }

            /* Format ports */
            char s_port_str[8], d_port_str[8];
            if (rules_copy[i].s_port == 0) strcpy(s_port_str, "*");
            else snprintf(s_port_str, sizeof(s_port_str), "%d", rules_copy[i].s_port);
            if (rules_copy[i].d_port == 0) strcpy(d_port_str, "*");
            else snprintf(d_port_str, sizeof(d_port_str), "%d", rules_copy[i].d_port);

            /* Format action */
            const char *action_str;
            uint8_t action = rules_copy[i].allow & 0x01;
            uint8_t monitor = rules_copy[i].allow & ACL_MONITOR;
            if (action == ACL_ALLOW) {
                action_str = monitor ? "Allow+M" : "Allow";
            } else {
                action_str = monitor ? "Deny+M" : "Deny";
            }

            snprintf(row, sizeof(row),
                "<tr>"
                "<td>%d</td><td>%s</td><td>%s</td><td>%s</td>"
                "<td>%s</td><td>%s</td><td>%s</td><td>%lu</td>"
                "<td><a href='/firewall?del_acl=%d&del_idx=%d' class='red-button'>Del</a></td>"
                "</tr>",
                i, proto_str, src_str, s_port_str,
                dst_str, d_port_str, action_str, (unsigned long)rules_copy[i].hit_count,
                list_no, i);
            SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
        }

        if (rule_count == 0) {
            SEND_CHUNK(req,
                "<tr><td colspan='9' style='text-align:center; color:#888;'>No rules (all packets allowed)</td></tr>",
                HTTPD_RESP_USE_STRLEN);
        }

        /* Close table and section */
        SEND_CHUNK(req, "</tbody></table></div>", HTTPD_RESP_USE_STRLEN);
    }

    /* Chunk 7: Add form and footer */
    SEND_CHUNK(req, FIREWALL_CHUNK_TAIL, HTTPD_RESP_USE_STRLEN);

    /* End chunked response */
    SEND_CHUNK(req, NULL, 0);

    return ESP_OK;
}

static httpd_uri_t firewallp = {
    .uri       = "/firewall",
    .method    = HTTP_GET,
    .handler   = firewall_get_handler,
};

/* Helper function to convert auth mode to string for web UI */
static const char* web_auth_mode_to_str(wifi_auth_mode_t authmode)
{
    switch (authmode) {
        case WIFI_AUTH_OPEN:            return "Open";
        case WIFI_AUTH_WEP:             return "WEP";
        case WIFI_AUTH_WPA_PSK:         return "WPA";
        case WIFI_AUTH_WPA2_PSK:        return "WPA2";
        case WIFI_AUTH_WPA_WPA2_PSK:    return "WPA/WPA2";
        case WIFI_AUTH_WPA3_PSK:        return "WPA3";
        case WIFI_AUTH_WPA2_WPA3_PSK:   return "WPA2/WPA3";
        case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-Ent";
        default:                        return "Unknown";
    }
}

/* URL encode a string for use in query parameters */
static void url_encode(const char *src, char *dst, size_t dst_len)
{
    const char *hex = "0123456789ABCDEF";
    size_t i = 0;

    while (*src && i < dst_len - 1) {
        if ((*src >= 'A' && *src <= 'Z') ||
            (*src >= 'a' && *src <= 'z') ||
            (*src >= '0' && *src <= '9') ||
            *src == '-' || *src == '_' || *src == '.' || *src == '~') {
            dst[i++] = *src;
        } else if (i + 3 < dst_len) {
            dst[i++] = '%';
            dst[i++] = hex[(*src >> 4) & 0x0F];
            dst[i++] = hex[*src & 0x0F];
        } else {
            break;
        }
        src++;
    }
    dst[i] = '\0';
}

#if !CONFIG_ETH_UPLINK
/* WiFi Scan page GET handler - NOT password protected */
static esp_err_t scan_get_handler(httpd_req_t *req)
{
    /* Check if user can connect (authenticated or no password set) */
    bool password_protection_enabled = is_web_password_set();
    bool can_connect = !password_protection_enabled || is_authenticated(req);

    uint16_t ap_count = 0;
    wifi_ap_record_t *ap_list = NULL;
    bool scan_in_progress = false;
    int refresh_time = 15;  /* Default refresh interval */

    /* Suppress STA reconnect attempts while on the scan page */
    if (!ap_connect) {
        wifi_scan_active = true;
    }

    /* Try to get existing scan results first */
    esp_err_t err = esp_wifi_scan_get_ap_num(&ap_count);

    if (err == ESP_OK && ap_count > 0) {
        /* We have results from a previous scan — read them */
        if (ap_count > 20) ap_count = 20;
        ap_list = malloc(sizeof(wifi_ap_record_t) * ap_count);
        if (ap_list != NULL) {
            esp_wifi_scan_get_ap_records(&ap_count, ap_list);
        } else {
            ap_count = 0;
        }
    }

    /* Start a (new) background scan for the next refresh */
    wifi_scan_config_t scan_config = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
    };
    if (!ap_connect) wifi_scan_active = true;
    err = esp_wifi_scan_start(&scan_config, false);  /* Non-blocking */

    if (ap_count == 0) {
        if (err == ESP_OK || err == ESP_ERR_WIFI_STATE) {
            /* No previous results, scan just started */
            scan_in_progress = true;
            refresh_time = 2;  /* Quick refresh to get results */
        }
    }

    /* Build the table header with optional Connect column */
    char header_extra[64] = "";
    if (can_connect) {
        strcpy(header_extra, "<th>Action</th>");
    }

    /* Build scan results HTML */
    char scan_html[4096] = "";
    int html_offset = 0;

    if (ap_count == 0) {
        if (scan_in_progress) {
            snprintf(scan_html, sizeof(scan_html),
                "<tr><td colspan='%d' style='text-align:center; color:#00d9ff;'>"
                "<span style='display:inline-block; animation: pulse 1s infinite;'>📡 Scanning...</span>"
                "</td></tr>",
                can_connect ? 5 : 4);
        } else {
            snprintf(scan_html, sizeof(scan_html),
                "<tr><td colspan='%d' style='text-align:center; color:#888;'>No networks found</td></tr>",
                can_connect ? 5 : 4);
        }
    } else {
        for (int i = 0; i < ap_count && html_offset < (int)(sizeof(scan_html) - 512); i++) {
            /* Determine signal strength and build visual bars */
            const char *signal_class;
            int rssi = ap_list[i].rssi;
            int bars;  /* Number of active bars (1-4) */

            if (rssi >= -50) {
                signal_class = "signal-excellent";
                bars = 4;
            } else if (rssi >= -60) {
                signal_class = "signal-good";
                bars = 3;
            } else if (rssi >= -70) {
                signal_class = "signal-fair";
                bars = 2;
            } else if (rssi >= -80) {
                signal_class = "signal-weak";
                bars = 1;
            } else {
                signal_class = "signal-poor";
                bars = 1;
            }

            /* HTML-escape SSID for display */
            char *safe_ssid = html_escape((const char *)ap_list[i].ssid);
            if (safe_ssid == NULL) {
                safe_ssid = strdup("(unknown)");
            }

            /* Build connect button if allowed */
            char connect_cell[256] = "";
            if (can_connect) {
                char encoded_ssid[128];
                url_encode((const char *)ap_list[i].ssid, encoded_ssid, sizeof(encoded_ssid));
                snprintf(connect_cell, sizeof(connect_cell),
                    "<td><a href='/setup?ssid=%s' class='connect-button'>Connect</a></td>",
                    encoded_ssid);
            }

            /* Build signal bars HTML with CSS divs */
            char signal_bars_html[384];
            const int bar_heights[] = {4, 8, 12, 16};  /* px */
            int sb_offset = 0;
            sb_offset += snprintf(signal_bars_html, sizeof(signal_bars_html),
                "<span class='signal-bars'>");
            for (int b = 0; b < 4; b++) {
                if (b < bars) {
                    sb_offset += snprintf(signal_bars_html + sb_offset, sizeof(signal_bars_html) - sb_offset,
                        "<span class='bar active %s' style='height:%dpx;'></span>",
                        signal_class, bar_heights[b]);
                } else {
                    sb_offset += snprintf(signal_bars_html + sb_offset, sizeof(signal_bars_html) - sb_offset,
                        "<span class='bar' style='height:%dpx;'></span>", bar_heights[b]);
                }
            }
            sb_offset += snprintf(signal_bars_html + sb_offset, sizeof(signal_bars_html) - sb_offset,
                "</span>");

            /* Channel / band info */
            char ch_info[80];
#if WIFI_HAS_5GHZ
            snprintf(ch_info, sizeof(ch_info), "%d <span style='color:#888;font-size:0.75rem;'>%s</span>",
                     ap_list[i].primary, ap_list[i].primary > 14 ? "5G" : "2.4G");
#else
            snprintf(ch_info, sizeof(ch_info), "%d", ap_list[i].primary);
#endif

            html_offset += snprintf(scan_html + html_offset, sizeof(scan_html) - html_offset,
                "<tr>"
                "<td>%s</td>"
                "<td style='white-space:nowrap;'>%s<span style='color:#888;font-size:0.8rem;margin-left:0.5em;'>%d dBm</span></td>"
                "<td>%s</td>"
                "<td>%s</td>"
                "%s"
                "</tr>",
                safe_ssid,
                signal_bars_html, rssi,
                ch_info,
                web_auth_mode_to_str(ap_list[i].authmode),
                connect_cell
            );

            free(safe_ssid);
        }
    }

    if (ap_list != NULL) {
        free(ap_list);
    }

    /* Build the page */
    const char* scan_page_template = SCAN_PAGE;
    int page_len = strlen(scan_page_template) + strlen(header_extra) + strlen(scan_html) + 128;
    char* scan_page = malloc(page_len);

    if (scan_page == NULL) {
        ESP_LOGE(TAG, "Failed to allocate memory for scan page");
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
        return ESP_ERR_NO_MEM;
    }

    snprintf(scan_page, page_len, scan_page_template, refresh_time, ap_count, header_extra, scan_html);

    httpd_resp_send(req, scan_page, strlen(scan_page));
    free(scan_page);

    return ESP_OK;
}

static httpd_uri_t scanp = {
    .uri       = "/scan",
    .method    = HTTP_GET,
    .handler   = scan_get_handler,
};
#endif

#if !CONFIG_ETH_UPLINK
/* Getting Started page GET handler */
static esp_err_t setup_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    /* Check authentication if password protection is enabled */
    if (is_web_password_set() && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /setup from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    char param1[64], param2[64];

    /* Handle form submission */
    size_t buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        char *buf = malloc(buf_len);
        if (buf != NULL && httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {

            /* Handle AP settings */
            if (httpd_query_key_value(buf, "ap_ssid", param1, sizeof(param1)) == ESP_OK) {
                preprocess_string(param1);
                if (httpd_query_key_value(buf, "ap_password", param2, sizeof(param2)) == ESP_OK) {
                    preprocess_string(param2);
                    if (strlen(param2) == 0) {
                        strlcpy(param2, ap_passwd, sizeof(param2));
                    }

                    /* Reset AP parameters to defaults (keep SSID/password from form) */
                    set_config_param_str("ap_ip",      DEFAULT_AP_IP);
                    set_config_param_str("ap_dns",     "");
                    free(ap_dns); ap_dns = strdup("");
                    set_config_param_int("ap_hidden",   0); ap_ssid_hidden = 0;
                    set_config_param_int("ap_known_only", 0); ap_known_only = 0;
                    set_config_param_int("ap_authmode", 0); ap_authmode    = 0;
                    set_config_param_int("ap_disabled", 0); ap_disabled    = false;
                    set_config_param_int("ap_nat",      1); ap_nat_enabled = 1;

                    int argc = 3;
                    char* argv[3];
                    argv[0] = "set_ap";
                    argv[1] = param1;
                    argv[2] = param2;
                    set_ap(argc, argv);
                }
            }

#if !CONFIG_ETH_UPLINK
            /* Handle STA settings */
            if (httpd_query_key_value(buf, "ssid", param1, sizeof(param1)) == ESP_OK) {
                preprocess_string(param1);
                if (httpd_query_key_value(buf, "password", param2, sizeof(param2)) == ESP_OK) {
                    preprocess_string(param2);
                    {
                        char open_val[4] = "";
                        if (httpd_query_key_value(buf, "sta_open", open_val, sizeof(open_val)) == ESP_OK) {
                            param2[0] = '\0';
                        } else if (strlen(param2) == 0) {
                            strlcpy(param2, passwd, sizeof(param2));
                        }
                    }

                    /* Reset STA parameters to defaults (keep SSID/password from form) */
                    set_config_param_str("static_ip",    ""); free(static_ip);   static_ip   = strdup("");
                    set_config_param_str("subnet_mask",  ""); free(subnet_mask); subnet_mask = strdup("");
                    set_config_param_str("gateway_addr", ""); free(gateway_addr); gateway_addr = strdup("");
                    set_config_param_str("ent_username", ""); free(ent_username); ent_username = strdup("");
                    set_config_param_str("ent_identity", ""); free(ent_identity); ent_identity = strdup("");
                    set_config_param_int("eap_method",  0); eap_method        = 0;
                    set_config_param_int("ttls_phase2", 0); ttls_phase2       = 0;
                    set_config_param_int("cert_bundle", 0); use_cert_bundle   = 0;
                    set_config_param_int("no_time_chk", 0); disable_time_check = 0;

                    int argc = 3;
                    char* argv[3];
                    argv[0] = "set_sta";
                    argv[1] = param1;
                    argv[2] = param2;
                    set_sta(argc, argv);
                    esp_timer_start_once(restart_timer, 500000);
                }
            }
#endif
        }
        free(buf);
    }

#if !CONFIG_ETH_UPLINK
    /* Check for SSID pre-fill from scan page */
    char prefill_ssid[64] = "";
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        char *buf = malloc(buf_len);
        if (buf != NULL && httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            if (httpd_query_key_value(buf, "ssid", prefill_ssid, sizeof(prefill_ssid)) == ESP_OK) {
                preprocess_string(prefill_ssid);
            }
        }
        if (buf) free(buf);
    }
#endif

    /* Render page */
    httpd_resp_set_type(req, "text/html");

    SEND_CHUNK(req, SETUP_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Escape into stack buffers so nothing heap-allocated is held across the
     * SEND_CHUNK calls below (a bail-out on a dead client returns immediately). */
    char safe_ap_ssid[200];
    html_escape_to(safe_ap_ssid, sizeof(safe_ap_ssid), ap_ssid);

    /* Sized for the worst case once the two escaped SSID fields are fixed-size
     * stack buffers (~1500 bytes); the default 1024 would risk truncation. */
    char section[1536];
#if CONFIG_ETH_UPLINK
    snprintf(section, sizeof(section), SETUP_CHUNK_FORM,
        safe_ap_ssid, "", "");
#else
    char safe_ssid[200];
    html_escape_to(safe_ssid, sizeof(safe_ssid), prefill_ssid[0] ? prefill_ssid : ssid);
    snprintf(section, sizeof(section), SETUP_CHUNK_FORM,
        safe_ap_ssid, safe_ssid, (strlen(passwd) == 0) ? "checked" : "");
#endif
    SEND_CHUNK(req, section, HTTPD_RESP_USE_STRLEN);

    SEND_CHUNK(req, NULL, 0);
    return ESP_OK;
}

static httpd_uri_t setupp = {
    .uri       = "/setup",
    .method    = HTTP_GET,
    .handler   = setup_get_handler,
};
#endif /* !CONFIG_ETH_UPLINK */

/* VPN page GET handler */
static esp_err_t vpn_get_handler(httpd_req_t *req)
{
    resume_sta_if_scan_idle();
    /* Check authentication if password protection is enabled */
    bool password_protection_enabled = is_web_password_set();

    if (password_protection_enabled && !is_authenticated(req)) {
        { char _ip[16]; ESP_LOGW(TAG, "Unauthenticated access to /vpn from %s", get_client_ip(req, _ip, sizeof(_ip))); }
        httpd_resp_set_status(req, "303 See Other");
        httpd_resp_set_hdr(req, "Location", "/?auth_required=1");
        httpd_resp_send(req, NULL, 0);
        return ESP_OK;
    }

    char* buf = NULL;
    size_t buf_len;

    /* Read URL query string */
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (buf != NULL && httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "VPN query => %s", buf);

            char param[128];
            bool has_config = false;

            /* Check if this is a form submission */
            if (httpd_query_key_value(buf, "vpn_enabled", param, sizeof(param)) == ESP_OK) {
                has_config = true;
                nvs_handle_t nvs;
                if (nvs_open(PARAM_NAMESPACE, NVS_READWRITE, &nvs) == ESP_OK) {
                    nvs_set_i32(nvs, "vpn_enabled", atoi(param));

                    if (httpd_query_key_value(buf, "vpn_privkey", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        if (param[0] != '\0')
                            nvs_set_str(nvs, "vpn_privkey", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_pubkey", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        nvs_set_str(nvs, "vpn_pubkey", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_psk", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        if (param[0] != '\0')
                            nvs_set_str(nvs, "vpn_psk", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_endpoint", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        nvs_set_str(nvs, "vpn_endpoint", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_port", param, sizeof(param)) == ESP_OK) {
                        nvs_set_i32(nvs, "vpn_port", atoi(param));
                    }
                    if (httpd_query_key_value(buf, "vpn_ip", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        nvs_set_str(nvs, "vpn_ip", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_mask", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        nvs_set_str(nvs, "vpn_mask", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_dns", param, sizeof(param)) == ESP_OK) {
                        preprocess_string(param);
                        nvs_set_str(nvs, "vpn_dns", param);
                    }
                    if (httpd_query_key_value(buf, "vpn_ka", param, sizeof(param)) == ESP_OK) {
                        nvs_set_i32(nvs, "vpn_ka", atoi(param));
                    }
                    if (httpd_query_key_value(buf, "vpn_mtu", param, sizeof(param)) == ESP_OK) {
                        int mtu = atoi(param);
                        if (mtu >= VPN_MTU_MIN && mtu <= VPN_MTU_MAX) {
                            nvs_set_i32(nvs, "vpn_mtu", mtu);
                        }
                    }
                    if (httpd_query_key_value(buf, "vpn_ks", param, sizeof(param)) == ESP_OK) {
                        nvs_set_i32(nvs, "vpn_ks", atoi(param));
                    }
                    if (httpd_query_key_value(buf, "vpn_rall", param, sizeof(param)) == ESP_OK) {
                        nvs_set_i32(nvs, "vpn_rall", atoi(param));
                    }

                    nvs_commit(nvs);
                    nvs_close(nvs);
                    ESP_LOGI(TAG, "VPN settings saved, scheduling restart");
                    esp_timer_start_once(restart_timer, 500000);
                }
            }

            /* If config was submitted, let the JS handle the "rebooting" message */
            if (has_config) {
                /* Fall through to render the page (JS will detect query params and show reboot msg) */
            }
        }
        if (buf) free(buf);
    }

    /* Reusable buffer for VPN page rows.
     * Stack buffer (not heap): a SEND_CHUNK bail-out on a dead client returns
     * immediately, and a heap buffer here would leak on every such bail. */
    #define VPN_BUF_SIZE 768
    char row[VPN_BUF_SIZE];

    /* Head */
    SEND_CHUNK(req, VPN_CHUNK_HEAD, HTTPD_RESP_USE_STRLEN);

    /* Logout button if authenticated */
    if (session_active && password_protection_enabled) {
        SEND_CHUNK(req,
            "<a href='/?logout=1' style='padding: 0.4rem 1rem; background: rgba(255,82,82,0.15); color: #ff5252; border: 1px solid #ff5252; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500;'>Logout</a>",
            HTTPD_RESP_USE_STRLEN);
    }

    /* Mid (script) */
    SEND_CHUNK(req, VPN_CHUNK_MID, HTTPD_RESP_USE_STRLEN);

    /* Status section */
    SEND_CHUNK(req, "<h2>Status</h2><div class='status-table'><table>", HTTPD_RESP_USE_STRLEN);

    if (vpn_enabled) {
        const char *state, *color;
        if (vpn_is_connected()) {
            state = "Connected"; color = "#4caf50";
        } else if (vpn_connected) {
            state = "Handshake Pending"; color = "#ffc107";
        } else {
            state = "Disconnected"; color = "#f44336";
        }
        snprintf(row, VPN_BUF_SIZE, "<tr><td>VPN:</td><td><strong style='color:%s;'>%s</strong></td></tr>", color, state);
    } else {
        snprintf(row, VPN_BUF_SIZE, "<tr><td>VPN:</td><td><strong style='color:#888;'>Disabled</strong></td></tr>");
    }
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    if (vpn_address && vpn_address[0]) {
        snprintf(row, VPN_BUF_SIZE, "<tr><td>Tunnel IP:</td><td>%s</td></tr>", vpn_address);
        SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);
    }
    snprintf(row, VPN_BUF_SIZE, "<tr><td>MSS Clamp:</td><td>%u</td></tr><tr><td>Path MTU:</td><td>%u</td></tr>",
             ap_mss_clamp, ap_pmtu);
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE, "<tr><td>Kill Switch:</td><td><strong style='color:%s;'>%s</strong></td></tr>",
             vpn_killswitch ? "#4caf50" : "#888", vpn_killswitch ? "On" : "Off");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE, "<tr><td>Route All:</td><td><strong style='color:%s;'>%s</strong></td></tr>",
             vpn_route_all ? "#4caf50" : "#2196f3", vpn_route_all ? "Yes" : "No (split tunnel)");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    SEND_CHUNK(req, "</table></div>", HTTPD_RESP_USE_STRLEN);

    /* Form - streamed field by field to avoid large snprintf */
    SEND_CHUNK(req, VPN_CHUNK_FORM_OPEN, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Enabled</td><td><select name='vpn_enabled'>"
        "<option value='1' %s>On</option><option value='0' %s>Off</option>"
        "</select></td></tr>",
        vpn_enabled ? "selected" : "", vpn_enabled ? "" : "selected");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Private Key</td><td><input type='password' name='vpn_privkey' placeholder='%s'/></td></tr>",
        (vpn_private_key && vpn_private_key[0]) ? "unchanged" : "Base64 private key");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Public Key</td><td><input type='text' name='vpn_pubkey' value='%s' placeholder='Peer base64 public key'/></td></tr>",
        vpn_public_key ? vpn_public_key : "");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Preshared Key</td><td><input type='password' name='vpn_psk' placeholder='%s'/></td></tr>",
        (vpn_preshared_key && vpn_preshared_key[0]) ? "unchanged" : "Optional");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Endpoint</td><td><input type='text' name='vpn_endpoint' value='%s' placeholder='Host or IP'/></td></tr>"
        "<tr><td>Port</td><td><input type='number' name='vpn_port' value='%d' min='1' max='65535'/></td></tr>"
        "<tr><td>Tunnel IP</td><td><input type='text' name='vpn_ip' value='%s' placeholder='e.g. 10.0.0.2'/></td></tr>"
        "<tr><td>Netmask</td><td><input type='text' name='vpn_mask' value='%s' placeholder='255.255.255.0'/></td></tr>",
        vpn_endpoint ? vpn_endpoint : "",
        (int)vpn_port,
        vpn_address ? vpn_address : "",
        vpn_netmask ? vpn_netmask : "255.255.255.0");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>DNS</td><td><input type='text' name='vpn_dns' value='%s' placeholder='Optional, e.g. 10.2.0.1'/></td></tr>",
        vpn_dns ? vpn_dns : "");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Keepalive (sec)</td><td><input type='number' name='vpn_ka' value='%d' min='0' max='65535'/></td></tr>",
        (int)vpn_keepalive);
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>MTU</td><td><input type='number' name='vpn_mtu' value='%d' min='%d' max='%d'/>"
        "<br><small>Lower (e.g. 1280-1320) if the tunnel is up but traffic stalls (CGNAT, PPPoE, LTE)</small></td></tr>",
        (int)vpn_mtu, VPN_MTU_MIN, VPN_MTU_MAX);
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Kill Switch</td><td><select name='vpn_ks'>"
        "<option value='1' %s>On</option><option value='0' %s>Off</option>"
        "</select></td></tr>",
        vpn_killswitch ? "selected" : "", vpn_killswitch ? "" : "selected");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    snprintf(row, VPN_BUF_SIZE,
        "<tr><td>Route All</td><td><select name='vpn_rall'>"
        "<option value='1' %s>Yes (all traffic)</option><option value='0' %s>No (split tunnel)</option>"
        "</select></td></tr>",
        vpn_route_all ? "selected" : "", vpn_route_all ? "" : "selected");
    SEND_CHUNK(req, row, HTTPD_RESP_USE_STRLEN);

    SEND_CHUNK(req, VPN_CHUNK_FORM_CLOSE, HTTPD_RESP_USE_STRLEN);

    /* Import section (paste a standard WireGuard .conf) - after the config fields */
    SEND_CHUNK(req, VPN_CHUNK_IMPORT, HTTPD_RESP_USE_STRLEN);

    /* Page footer (Home button + close tags) */
    SEND_CHUNK(req, VPN_CHUNK_PAGE_END, HTTPD_RESP_USE_STRLEN);

    /* End chunked response */
    SEND_CHUNK(req, NULL, 0);

    return ESP_OK;
}

static httpd_uri_t vpnp = {
    .uri       = "/vpn",
    .method    = HTTP_GET,
    .handler   = vpn_get_handler,
};

static esp_err_t captive_redirect_handler(httpd_req_t *req, httpd_err_code_t err);

httpd_handle_t start_webserver(uint16_t port)
{
    httpd_handle_t server = NULL;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = port;
    config.stack_size = 16384;  // Large stack needed for mappings page with 3x 2KB HTML buffers
    config.max_uri_handlers = 20;
    config.max_uri_len = 1024;
    config.open_fn = http_open_fn;
    /* Fail a stalled send/recv fast (default 5s) so an abandoned connection
     * frees its socket and buffers quickly instead of pinning them; paired
     * with the SEND_CHUNK bail-out, a dead client costs ~one timeout total. */
    config.send_wait_timeout = 2;
    config.recv_wait_timeout = 2;
    /* A WiFi client that just walks out of range never sends a TCP FIN, so its
     * connections sit in httpd's socket table forever, each pinning a netconn +
     * PCB + pbufs (the few-KB-per-disconnect leak).  After a few rounds the table
     * fills and accept() fails with ENFILE (errno 23).  lru_purge_enable lets
     * httpd close the least-recently-used connection to admit a new one, so the
     * server always recovers; the keepalive probes set in http_open_fn reap the
     * dead sockets proactively before it ever comes to that. */
    config.lru_purge_enable = true;

    /* Load web UI interface bind mask from NVS */
    {
        int bind_val = (int)(RC_BIND_AP | RC_BIND_STA | RC_BIND_VPN);
        get_config_param_int("web_bind", &bind_val);
        s_web_bind = (uint8_t)(bind_val & (RC_BIND_AP | RC_BIND_STA | RC_BIND_VPN));
        if (s_web_bind == 0) s_web_bind = RC_BIND_AP;
    }

    esp_timer_create(&restart_timer_args, &restart_timer);

    // Start the httpd server
    ESP_LOGI(TAG, "Starting server on port: '%d'", config.server_port);
    if (httpd_start(&server, &config) == ESP_OK) {
        // Set URI handlers
        ESP_LOGI(TAG, "Registering URI handlers");
        httpd_register_uri_handler(server, &indexp);
        httpd_register_uri_handler(server, &indexp_post);
        httpd_register_uri_handler(server, &configp);
        httpd_register_uri_handler(server, &mappingsp);
        httpd_register_uri_handler(server, &firewallp);
#if !CONFIG_ETH_UPLINK
        httpd_register_uri_handler(server, &scanp);
#endif
        httpd_register_uri_handler(server, &vpnp);
#if !CONFIG_ETH_UPLINK
        httpd_register_uri_handler(server, &setupp);
#endif
        httpd_register_uri_handler(server, &favicon_uri);
        httpd_register_uri_handler(server, &config_exportp);
        httpd_register_uri_handler(server, &config_importp);
        httpd_register_uri_handler(server, &vpn_importp);
        httpd_register_uri_handler(server, &ota_uploadp);
        httpd_register_uri_handler(server, &ota_statusp);
        httpd_register_uri_handler(server, &ota_confirmp);
        httpd_register_uri_handler(server, &ota_rollbackp);
        httpd_register_uri_handler(server, &updatep);
        httpd_register_uri_handler(server, &ttl_getp);
        httpd_register_uri_handler(server, &ttl_postp);
        ota_manager_report_ready(OTA_READY_HTTP);

#if CONFIG_ETH_UPLINK
        // In ETH mode, start captive portal if router appears unconfigured
        if (strlen(ap_passwd) == 0 && !is_web_password_set()) {
            ESP_LOGI(TAG, "No AP/web password set, starting captive portal DNS");
            httpd_register_err_handler(server, HTTPD_404_NOT_FOUND, captive_redirect_handler);
            web_server_start_captive_dns();
        }
#else
        // Start captive portal DNS only when no upstream WiFi is configured
        if (ssid == NULL || strlen(ssid) == 0) {
            ESP_LOGI(TAG, "No STA configured, starting captive portal DNS");
            httpd_register_err_handler(server, HTTPD_404_NOT_FOUND, captive_redirect_handler);
            web_server_start_captive_dns();
        }
#endif

        return server;
    }

    ESP_LOGI(TAG, "Error starting server!");
    return NULL;
}

static void stop_webserver(httpd_handle_t server)
{
    // Stop the httpd server
    httpd_stop(server);
}


// ---------- Captive portal ----------

// DNS server: resolve every query to the AP IP so captive-portal checks succeed
static void dns_server_task(void *pvParameters)
{
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        ESP_LOGE(TAG, "DNS server: socket failed");
        vTaskDelete(NULL);
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(53),
        .sin_addr.s_addr = htonl(INADDR_ANY),
    };
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        ESP_LOGE(TAG, "DNS server: bind failed");
        close(sock);
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "Captive portal DNS server started");
    uint8_t buf[512];

    /* Bytes appended after the received query to form the A-record answer:
     * name pointer (2) + type (2) + class (2) + TTL (4) + RDLENGTH (2) + IPv4 (4) */
    #define DNS_ANSWER_LEN 16

    while (1) {
        struct sockaddr_in client;
        socklen_t client_len = sizeof(client);
        int len = recvfrom(sock, buf, sizeof(buf), 0,
                           (struct sockaddr *)&client, &client_len);
        if (len < 12) continue;

        /* Drop oversized queries: the appended answer must fit in buf.
         * Without this, a >=496-byte packet overflows the stack buffer. */
        if (len > (int)sizeof(buf) - DNS_ANSWER_LEN) continue;

        /* Only respond to standard queries: QR=0 (query) and exactly one question. */
        if (buf[2] & 0x80) continue;                  // QR bit set => not a query
        if (buf[4] != 0x00 || buf[5] != 0x01) continue; // QDCOUNT != 1

        // Turn query into response
        buf[2] = 0x81;  // QR=1, AA=1, RD=1
        buf[3] = 0x80;  // RA=1
        buf[6] = 0x00;  buf[7] = 0x01;  // 1 answer

        // Append A record: name-pointer, type A, class IN, TTL 60, AP IP
        uint8_t *ip_bytes = (uint8_t *)&my_ap_ip;
        int pos = len;
        buf[pos++] = 0xC0; buf[pos++] = 0x0C;
        buf[pos++] = 0x00; buf[pos++] = 0x01;
        buf[pos++] = 0x00; buf[pos++] = 0x01;
        buf[pos++] = 0x00; buf[pos++] = 0x00;
        buf[pos++] = 0x00; buf[pos++] = 0x3C;
        buf[pos++] = 0x00; buf[pos++] = 0x04;
        buf[pos++] = ip_bytes[0]; buf[pos++] = ip_bytes[1];
        buf[pos++] = ip_bytes[2]; buf[pos++] = ip_bytes[3];

        sendto(sock, buf, pos, 0,
               (struct sockaddr *)&client, client_len);
    }
}

void web_server_start_captive_dns(void)
{
    xTaskCreate(dns_server_task, "dns_srv", 4096, NULL, 5, NULL);
}

// 404 handler: redirect unknown URIs to the main page (captive portal trigger)
static char captive_redirect_url[32];

static esp_err_t captive_redirect_handler(httpd_req_t *req, httpd_err_code_t err)
{
    if (captive_redirect_url[0] == '\0') {
        snprintf(captive_redirect_url, sizeof(captive_redirect_url),
                 "http://" IPSTR "/", IP2STR((esp_ip4_addr_t *)&my_ap_ip));
    }
    httpd_resp_set_status(req, "302 Found");
    httpd_resp_set_hdr(req, "Location", captive_redirect_url);
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}
