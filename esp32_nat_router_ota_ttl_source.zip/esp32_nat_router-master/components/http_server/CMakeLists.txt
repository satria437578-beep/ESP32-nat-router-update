idf_component_register(
    SRCS "http_server.c" "ttl_logic.c"
    INCLUDE_DIRS "include"
    PRIV_REQUIRES esp_http_server esp_wifi esp_netif esp_event nvs_flash driver
                  esp_timer json cmd_router acl pcap_capture
                  remote_console dhcpserver wpa_supplicant
                  app_update esp_app_format mbedtls ota_manager
)
target_compile_options(${COMPONENT_LIB} PRIVATE -Wno-unused-function -Os)
