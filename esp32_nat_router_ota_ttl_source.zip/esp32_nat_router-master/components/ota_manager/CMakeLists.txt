idf_component_register(SRCS "ota_manager.c" "ota_validate.c"
                    INCLUDE_DIRS "include"
                    REQUIRES esp_common
                    PRIV_REQUIRES app_update esp_app_format esp_netif esp_timer log)
target_compile_options(${COMPONENT_LIB} PRIVATE -Os)
