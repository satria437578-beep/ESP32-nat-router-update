/* OTA state, deferred validation and rollback.
 *
 * With CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE a freshly flashed image boots in
 * state PENDING_VERIFY.  If the device resets (crash, watchdog, power loss)
 * before the image is marked valid, the bootloader automatically returns to
 * the previous slot.  The original firmware marked the image valid at the very
 * top of app_main(), before Wi-Fi or the web server had started, which defeats
 * that protection.  ota_manager_init() instead waits until the router has
 * proven itself healthy for a while.
 *
 * SPDX-License-Identifier: MIT
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Seconds the new firmware must stay healthy before it is confirmed. */
#define OTA_VALIDATE_STABLE_S   20
/* If it has not become healthy within this many seconds, roll back. */
#define OTA_VALIDATE_TIMEOUT_S  120

/* Health bits reported by subsystems (AP netif state is polled directly). */
#define OTA_READY_HTTP   (1u << 0)

typedef struct {
    char running_label[17];     /* "ota_0" / "ota_1" */
    char other_label[17];       /* inactive slot, "" if none */
    char state[12];             /* valid | pending | new | invalid | aborted | undefined */
    char version[32];
    char project[32];
    char prev_version[32];      /* version found in the inactive slot, "" if none */
    uint32_t slot_size;         /* max firmware size in bytes */
    uint32_t uptime_s;
    int  pending_left_s;        /* seconds until auto-rollback decision, -1 if not pending */
    bool pending;               /* running image still awaits validation */
    bool rollback_possible;     /* inactive slot holds a bootable, non-failed image */
} ota_info_t;

/* Call early in app_main(), after NVS init. Starts the validation task only
 * when the running image is PENDING_VERIFY (allocates nothing otherwise). */
void ota_manager_init(void);

/* Subsystems call this when they are up (e.g. the HTTP server). */
void ota_manager_report_ready(uint32_t bit);

void ota_manager_get_info(ota_info_t *out);

/* Mark the running image valid right now (user pressed "Confirm"). */
esp_err_t ota_manager_confirm(void);

/* Select the previous firmware slot for the next boot. Caller restarts. */
esp_err_t ota_manager_rollback_previous(void);

#ifdef __cplusplus
}
#endif
