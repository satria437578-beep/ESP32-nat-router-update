/* Firmware image pre-checks for OTA uploads.
 *
 * Runs on the first bytes of the uploaded file, BEFORE the inactive OTA
 * partition is erased, so an obviously wrong file never destroys the spare
 * slot.  The full SHA-256 / checksum verification is still done by
 * esp_ota_end() after the last byte.
 *
 * SPDX-License-Identifier: MIT
 */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    OTA_HDR_OK = 0,
    OTA_HDR_TOO_SHORT,     /* fewer bytes than image header + first segment header + app descriptor */
    OTA_HDR_BAD_MAGIC,     /* not an ESP image (first byte != 0xE9) */
    OTA_HDR_WRONG_CHIP,    /* image built for another chip */
    OTA_HDR_NO_APP_DESC,   /* no application descriptor: bootloader, partition table, data blob... */
    OTA_HDR_WRONG_PROJECT, /* app descriptor project name differs from the running firmware */
} ota_hdr_result_t;

/* Number of leading bytes ota_validate_header() needs. */
size_t ota_validate_min_bytes(void);

/* Check the leading bytes of a firmware image.
 *   expected_chip_id      - e.g. CONFIG_IDF_FIRMWARE_CHIP_ID
 *   expected_project      - project name of the running app (NULL = skip)
 *   allow_other_project   - skip ONLY the project-name check (user override) */
ota_hdr_result_t ota_validate_header(const uint8_t *data, size_t len,
                                     uint16_t expected_chip_id,
                                     const char *expected_project,
                                     bool allow_other_project);

/* Short machine-readable code ("wrong_chip", ...) for the JSON API. */
const char *ota_hdr_result_code(ota_hdr_result_t r);

/* Human-readable message for the Web UI. */
const char *ota_hdr_result_msg(ota_hdr_result_t r);

#ifdef __cplusplus
}
#endif
