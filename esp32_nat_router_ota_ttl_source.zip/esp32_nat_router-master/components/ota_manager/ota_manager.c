/* SPDX-License-Identifier: MIT */
#include "ota_manager.h"

#include <string.h>

#include "esp_app_desc.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_ota_ops.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "ota_mgr";

static volatile uint32_t s_ready_bits;
static volatile int s_pending_left_s = -1;
static volatile bool s_confirmed;

static bool running_is_pending(void)
{
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_ota_img_states_t st;
    return running != NULL &&
           esp_ota_get_state_partition(running, &st) == ESP_OK &&
           st == ESP_OTA_IMG_PENDING_VERIFY;
}

/* The router is "healthy" when the HTTP server is up and the AP interface is
 * up, i.e. the user can still reach the Web UI to fix or roll back. */
static bool health_ok(void)
{
    if ((s_ready_bits & OTA_READY_HTTP) == 0) {
        return false;
    }
    esp_netif_t *ap = esp_netif_get_handle_from_ifkey("WIFI_AP_DEF");
    return ap != NULL && esp_netif_is_netif_up(ap);
}

static void validate_task(void *arg)
{
    (void)arg;
    uint32_t elapsed = 0, stable = 0;
    s_pending_left_s = OTA_VALIDATE_TIMEOUT_S;

    while (elapsed < OTA_VALIDATE_TIMEOUT_S) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        elapsed++;
        s_pending_left_s = (int)(OTA_VALIDATE_TIMEOUT_S - elapsed);

        if (s_confirmed || !running_is_pending()) {
            break;                      /* confirmed by the user meanwhile */
        }
        if (health_ok()) {
            if (++stable >= OTA_VALIDATE_STABLE_S) {
                if (esp_ota_mark_app_valid_cancel_rollback() == ESP_OK) {
                    ESP_LOGI(TAG, "New firmware healthy for %us, marked valid", (unsigned)stable);
                }
                s_confirmed = true;
                break;
            }
        } else {
            stable = 0;
        }
    }

    if (!s_confirmed && running_is_pending()) {
        ESP_LOGE(TAG, "New firmware never became healthy, rolling back");
        esp_ota_mark_app_invalid_rollback_and_reboot();
        /* Only reached if no previous image exists: keep the device usable. */
        ESP_LOGE(TAG, "Rollback impossible, keeping current image");
        esp_ota_mark_app_valid_cancel_rollback();
    }
    s_pending_left_s = -1;
    vTaskDelete(NULL);
}

void ota_manager_init(void)
{
    if (!running_is_pending()) {
        return;
    }
    const esp_partition_t *running = esp_ota_get_running_partition();
    ESP_LOGW(TAG, "Running image on '%s' is PENDING_VERIFY: validating for up to %ds",
             running ? running->label : "?", OTA_VALIDATE_TIMEOUT_S);
    if (xTaskCreate(validate_task, "ota_validate", 3584, NULL, 3, NULL) != pdPASS) {
        ESP_LOGE(TAG, "Cannot start validation task, confirming image immediately");
        esp_ota_mark_app_valid_cancel_rollback();
    }
}

void ota_manager_report_ready(uint32_t bit)
{
    s_ready_bits |= bit;
}

static const char *state_name(esp_ota_img_states_t st, bool known)
{
    if (!known) return "undefined";
    switch (st) {
    case ESP_OTA_IMG_VALID:          return "valid";
    case ESP_OTA_IMG_PENDING_VERIFY: return "pending";
    case ESP_OTA_IMG_NEW:            return "new";
    case ESP_OTA_IMG_INVALID:        return "invalid";
    case ESP_OTA_IMG_ABORTED:        return "aborted";
    default:                         return "undefined";
    }
}

/* Inactive slot is usable for rollback if it holds a readable app image that
 * has not been marked invalid/aborted by an earlier failed boot. */
static bool slot_bootable(const esp_partition_t *p, esp_app_desc_t *desc)
{
    if (p == NULL || esp_ota_get_partition_description(p, desc) != ESP_OK) {
        return false;
    }
    esp_ota_img_states_t st;
    if (esp_ota_get_state_partition(p, &st) == ESP_OK &&
        (st == ESP_OTA_IMG_INVALID || st == ESP_OTA_IMG_ABORTED)) {
        return false;
    }
    return true;
}

void ota_manager_get_info(ota_info_t *out)
{
    memset(out, 0, sizeof(*out));
    out->pending_left_s = -1;
    out->uptime_s = (uint32_t)(esp_timer_get_time() / 1000000);

    const esp_partition_t *running = esp_ota_get_running_partition();
    const esp_partition_t *other = esp_ota_get_next_update_partition(NULL);
    const esp_app_desc_t *app = esp_app_get_description();

    if (running) {
        strlcpy(out->running_label, running->label, sizeof(out->running_label));
        out->slot_size = running->size;
        esp_ota_img_states_t st = ESP_OTA_IMG_UNDEFINED;
        bool known = esp_ota_get_state_partition(running, &st) == ESP_OK;
        strlcpy(out->state, state_name(st, known), sizeof(out->state));
        out->pending = known && st == ESP_OTA_IMG_PENDING_VERIFY;
    }
    if (out->pending) {
        out->pending_left_s = s_pending_left_s;
    }
    if (app) {
        strlcpy(out->version, app->version, sizeof(out->version));
        strlcpy(out->project, app->project_name, sizeof(out->project));
    }
    if (other) {
        strlcpy(out->other_label, other->label, sizeof(out->other_label));
        esp_app_desc_t d;
        if (slot_bootable(other, &d)) {
            out->rollback_possible = true;
            strlcpy(out->prev_version, d.version, sizeof(out->prev_version));
        }
    }
}

esp_err_t ota_manager_confirm(void)
{
    if (!running_is_pending()) {
        return ESP_ERR_INVALID_STATE;
    }
    esp_err_t err = esp_ota_mark_app_valid_cancel_rollback();
    if (err == ESP_OK) {
        s_confirmed = true;
        ESP_LOGI(TAG, "Running firmware confirmed by user");
    }
    return err;
}

esp_err_t ota_manager_rollback_previous(void)
{
    const esp_partition_t *other = esp_ota_get_next_update_partition(NULL);
    esp_app_desc_t d;
    if (!slot_bootable(other, &d)) {
        return ESP_ERR_NOT_FOUND;
    }
    /* esp_ota_set_boot_partition() re-verifies the image before switching. */
    esp_err_t err = esp_ota_set_boot_partition(other);
    if (err == ESP_OK) {
        ESP_LOGW(TAG, "Next boot: previous firmware %s on '%s'", d.version, other->label);
    }
    return err;
}
