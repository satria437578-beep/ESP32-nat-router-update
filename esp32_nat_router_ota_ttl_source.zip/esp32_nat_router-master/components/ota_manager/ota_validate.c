/* SPDX-License-Identifier: MIT */
#include "ota_validate.h"

#include <string.h>

#include "esp_app_desc.h"
#include "esp_app_format.h"

#define APP_DESC_OFFSET (sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t))

size_t ota_validate_min_bytes(void)
{
    return APP_DESC_OFFSET + sizeof(esp_app_desc_t);
}

ota_hdr_result_t ota_validate_header(const uint8_t *data, size_t len,
                                     uint16_t expected_chip_id,
                                     const char *expected_project,
                                     bool allow_other_project)
{
    if (data == NULL || len < ota_validate_min_bytes()) {
        return OTA_HDR_TOO_SHORT;
    }

    esp_image_header_t hdr;
    memcpy(&hdr, data, sizeof(hdr));
    if (hdr.magic != ESP_IMAGE_HEADER_MAGIC) {
        return OTA_HDR_BAD_MAGIC;
    }
    if ((uint16_t)hdr.chip_id != expected_chip_id) {
        return OTA_HDR_WRONG_CHIP;
    }

    esp_app_desc_t desc;
    memcpy(&desc, data + APP_DESC_OFFSET, sizeof(desc));
    if (desc.magic_word != ESP_APP_DESC_MAGIC_WORD) {
        return OTA_HDR_NO_APP_DESC;
    }

    if (expected_project != NULL && !allow_other_project) {
        char project[sizeof(desc.project_name) + 1];
        memcpy(project, desc.project_name, sizeof(desc.project_name));
        project[sizeof(desc.project_name)] = '\0';
        if (strcmp(project, expected_project) != 0) {
            return OTA_HDR_WRONG_PROJECT;
        }
    }
    return OTA_HDR_OK;
}

const char *ota_hdr_result_code(ota_hdr_result_t r)
{
    switch (r) {
    case OTA_HDR_OK:            return "ok";
    case OTA_HDR_TOO_SHORT:     return "too_short";
    case OTA_HDR_BAD_MAGIC:     return "bad_magic";
    case OTA_HDR_WRONG_CHIP:    return "wrong_chip";
    case OTA_HDR_NO_APP_DESC:   return "no_app_desc";
    case OTA_HDR_WRONG_PROJECT: return "wrong_project";
    }
    return "unknown";
}

const char *ota_hdr_result_msg(ota_hdr_result_t r)
{
    switch (r) {
    case OTA_HDR_OK:            return "OK";
    case OTA_HDR_TOO_SHORT:     return "File too small to be a firmware image";
    case OTA_HDR_BAD_MAGIC:     return "Not an ESP32 firmware image (bad magic byte)";
    case OTA_HDR_WRONG_CHIP:    return "Firmware was built for a different chip";
    case OTA_HDR_NO_APP_DESC:   return "Not an application image. Use the app .bin, not the bootloader, partition table or merged/factory image";
    case OTA_HDR_WRONG_PROJECT: return "Firmware is from a different project than the running one";
    }
    return "Invalid firmware";
}
