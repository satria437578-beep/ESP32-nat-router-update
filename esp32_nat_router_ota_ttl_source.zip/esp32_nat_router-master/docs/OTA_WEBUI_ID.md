# Update Firmware (OTA) & TTL Rewrite lewat Web UI

Berlaku untuk semua varian (esp32, esp32s3, esp32c3, esp32c5, esp32c6, wt32_eth01, esp32_poe_iso).
Tampilan Web UI tetap berbahasa Inggris, sama seperti halaman lain.

## Yang berubah

| Area | Perubahan |
|---|---|
| TTL | Bagian **TTL Rewrite** baru di halaman *Configuration*: toggle, preset 64/128/Other, input 1–255, tombol **Save** dan **Apply**. Memakai key NVS `sta_ttl` yang sama dengan CLI `set_ttl`. Key tambahan `sta_ttl_last` hanya mengingat angka terakhir saat TTL dimatikan. |
| OTA | Menu baru **Update Firmware** (`/update`) di halaman utama: status firmware, upload `.bin` dengan progres, deteksi restart otomatis, tombol **Confirm now** dan **Roll back**. |
| Validasi | Header image dicek **sebelum** slot cadangan dihapus (magic, chip, descriptor aplikasi, nama project, ukuran). Setelah upload, `esp_ota_end()` memverifikasi checksum + SHA-256. |
| Rollback | Firmware baru **tidak lagi langsung dianggap valid** saat boot (perilaku lama). Ia dianggap valid setelah AP Wi-Fi + web server sehat selama 20 detik. Jika crash/restart sebelum itu, bootloader otomatis kembali ke firmware lama. Jika tidak sehat dalam 120 detik, rollback dipicu. |
| Ketahanan upload | Stall koneksi HP hingga ±16 detik tidak lagi membatalkan update (dulu >2 detik langsung gagal). Hanya satu update sekaligus. |
| Tidak diubah | NAT, DHCP, SSH, WireGuard, tabel partisi, isi NVS yang ada. Endpoint `/api/ota-upload` tetap kompatibel (uploader lama di halaman Configuration masih jalan). |

Tabel partisi (`partitions_example.csv`) **sudah** mendukung OTA: `ota_0` + `ota_1` masing-masing 1536K, `otadata`, `nvs`. `CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=y` sudah aktif di `sdkconfig.defaults`. Tidak perlu mengubah keduanya.

## Build

```bash
. $IDF_PATH/export.sh                 # ESP-IDF 5.5.x
idf.py set-target esp32c3             # sesuaikan chip
idf.py build
# hasil: build/esp32_nat_router.bin   <- file inilah yang diunggah lewat OTA
# atau semua varian: ./build_all_targets.sh
```

Cek ukuran (slot 1536 KiB): `idf.py size`. Tambahan kode ini diperkirakan 20–25 KB; binari upstream terbesar (C5) sisa ±94 KB.

## Pengujian di komputer (tanpa ESP32)

```bash
./tests/host/run_tests.sh             # gcc + python3
NODE_PATH=<folder playwright> node tests/ui/ui_test.js <dir html> <api_out.txt>   # uji UI di browser
```

## Cara update lewat Web UI (Android)

1. Sambungkan HP ke Wi-Fi AP router, buka `http://192.168.4.1`.
2. Ketuk **Update Firmware**.
3. Ketuk area "Tap to choose .bin file", pilih **`esp32_nat_router.bin`** (bukan `bootloader.bin`, `partition-table.bin`, atau image *merged/factory*). Pilih file untuk chip yang sama.
4. Ketuk **Upload & Install**, setujui dialog.
5. Biarkan halaman terbuka. Urutan status: *Uploading n%* → *Verifying and finishing flash write* → *Restarting* → *Router is back*.
6. Wi-Fi putus ±30 detik saat restart. Android bisa pindah ke jaringan lain karena "tanpa internet"; sambungkan kembali ke AP router bila perlu, halaman menyambung sendiri atau muat ulang.
7. Firmware baru berstatus **Pending validation**. Setelah 20 detik sehat otomatis menjadi **Valid**; atau ketuk **Confirm now**.

Jika sebuah file ditolak, pesan alasannya muncul dan firmware yang berjalan tidak berubah. Jika nama project berbeda (mis. build custom), muncul opsi *Allow firmware with a different project name*; opsi ini hanya melewati cek nama project.

## Rollback

* **Otomatis**: crash, reset, atau cabut daya saat status *Pending validation*, atau AP/web server tidak sehat dalam 120 detik.
* **Manual**: tombol **Roll back to previous firmware** (aktif bila slot lain berisi image yang belum pernah gagal boot).
* **Darurat lewat kabel** (firmware tidak bisa diakses sama sekali): flash ulang hanya app tanpa menghapus NVS, mis. `idf.py app-flash`. Bila `otadata` menunjuk slot lain, hapus dulu: `esptool.py erase_region 0xf000 0x2000` (bootloader lalu menjalankan `ota_0`). Jangan `erase_flash` kecuali ingin menghapus semua pengaturan.

## TTL

*Configuration → TTL Rewrite*:

* **Save**: simpan ke NVS saja; status menampilkan "saved but not active - press Apply".
* **Apply**: simpan **dan** aktifkan sekarang, tanpa reboot.
* Toggle off + Apply = TTL 0 (tidak mengubah paket). Nilai 1 hanya berlaku ke arah upstream.
* Sinkron dengan CLI: `set_ttl 64` muncul di Web UI, dan sebaliknya; aktif setelah boot karena sama-sama dibaca dari `sta_ttl`.

## Keterbatasan yang perlu diketahui

* Update **dari** firmware upstream lama **ke** build ini aman. Perlindungan rollback otomatis baru berlaku untuk update **berikutnya** (karena firmware lama yang menandai valid terlalu dini).
* Upload memblokir server HTTP tunggal selama prosesnya; halaman lain tidak merespons sampai selesai.
* HTTP tanpa TLS: siapa pun di jaringan AP yang lolos login web bisa memasang firmware. Setel password router (`set_router_password`) dan batasi antarmuka yang boleh membuka UI (`web_ui`).
* Tidak ada tanda tangan firmware (secure boot) di build ini; validasi bersifat integritas + kecocokan chip/project, bukan keaslian.
