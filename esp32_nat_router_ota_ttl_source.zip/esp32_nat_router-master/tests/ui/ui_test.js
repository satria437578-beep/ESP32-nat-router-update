// Browser test of the Update Firmware page and the TTL section against a mock
// device. JSON field names/shape are taken from the REAL C handler output
// captured by tests/host/run_tests.sh (api_out.txt), so contract drift between
// firmware and UI is detected.
//   NODE_PATH=<dir with playwright> PLAYWRIGHT_BROWSERS_PATH=... node tests/ui/ui_test.js <html dir> <api_out.txt>
const http = require('http');
const fs = require('fs');
const { chromium } = require('playwright');

const htmlDir = process.argv[2], apiOut = process.argv[3];
const updateHtml = fs.readFileSync(htmlDir + '/update.html', 'utf8');
const ttlHtml = fs.readFileSync(htmlDir + '/ttl.html', 'utf8');
const real = fs.readFileSync(apiOut, 'utf8').split('\n').filter(l => l.startsWith('JSON:')).map(l => JSON.parse(l.slice(5)));
const realStatus = real.find(j => 'slot_size' in j);
const realTtl = real.find(j => 'display' in j);
if (!realStatus || !realTtl) { console.error('no real JSON samples found'); process.exit(2); }

let fails = 0, checks = 0;
function check(c, msg) { checks++; if (!c) { fails++; console.log('FAIL: ' + msg); } else { console.log('ok   ' + msg); } }
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------------- mock device ----------------
const dev = { st: { ...realStatus, slot: 'ota_0', other: 'ota_1', version: '2.5.0', prev: '2.4.0', pending: false, pending_left: -1, state: 'valid', rollback: true, uptime_s: 500 },
  downUntil: 0, uploads: [], uploadMode: 'ok', ttl: { active: 0, saved: 0, last: 0 }, posts: [], resetMidUpload: false };
function ttlJson(ok, msg) { const d = dev.ttl.saved > 0 ? dev.ttl.saved : (dev.ttl.last > 0 ? dev.ttl.last : 64); return JSON.stringify({ ok, msg, active: dev.ttl.active, saved: dev.ttl.saved, last: dev.ttl.last, display: d }); }
const server = http.createServer((req, res) => {
  if (Date.now() < dev.downUntil) { req.socket.destroy(); return; }
  const url = req.url.split('?')[0];
  const send = (o, code = 200) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(typeof o === 'string' ? o : JSON.stringify(o)); };
  if (url === '/update') { res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end(updateHtml); }
  if (url === '/config') { res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end('<html><style>.ok-button{width:100%}</style><body>' + ttlHtml + '</body></html>'); }
  if (url === '/api/ota-status') return send(dev.st);
  if (url === '/api/ota-confirm') { dev.st.pending = false; dev.st.state = 'valid'; return send({ ok: true, code: 'ok', msg: 'Firmware confirmed' }); }
  if (url === '/api/ota-rollback') { send({ ok: true, code: 'ok', msg: 'Rolling back. Rebooting...' }); setTimeout(() => reboot('2.4.0', '2.5.0', false), 300); return; }
  if (url === '/api/ota-upload') {
    let n = 0; const q = req.url.split('?')[1] || '';
    req.on('data', c => { n += c.length; if (dev.resetMidUpload && n > 100000) { req.socket.destroy(); } });
    req.on('end', () => {
      dev.uploads.push({ bytes: n, query: q, ctype: req.headers['content-type'] });
      if (dev.uploadMode === 'wrong_chip') return send({ ok: false, code: 'wrong_chip', msg: 'Firmware is for chip id 0x0000, this device is 0x0005' });
      if (dev.uploadMode === 'wrong_project' && !q.includes('force=1')) return send({ ok: false, code: 'wrong_project', msg: 'Firmware is from a different project than the running one' });
      send({ ok: true, code: 'ok', msg: 'Firmware installed. Rebooting...' });
      setTimeout(() => reboot('2.6.0', dev.st.version, true), 3000);
    });
    return;
  }
  if (url === '/api/ttl' && req.method === 'GET') return send(ttlJson(true, 'ok'));
  if (url === '/api/ttl' && req.method === 'POST') {
    let b = ''; req.on('data', c => b += c); req.on('end', () => {
      dev.posts.push(b); const p = new URLSearchParams(b);
      if (dev.ttlFail) return send(ttlJson(false, 'Failed to write setting to flash'), 500);
      const eff = p.get('enabled') === '1' ? parseInt(p.get('value')) : 0;
      dev.ttl.saved = eff; if (p.get('value')) dev.ttl.last = parseInt(p.get('value'));
      if (p.get('action') === 'apply') dev.ttl.active = eff;
      send(ttlJson(true, p.get('action') === 'apply' ? 'Applied' : 'Saved'));
    }); return;
  }
  res.writeHead(404); res.end('nf');
});
function reboot(newVer, prevVer, pending) {
  dev.downUntil = Date.now() + 5000;
  const flip = dev.st.slot === 'ota_0' ? ['ota_1', 'ota_0'] : ['ota_0', 'ota_1'];
  setTimeout(() => { Object.assign(dev.st, { slot: flip[0], other: flip[1], version: newVer, prev: prevVer, pending, state: pending ? 'pending' : 'valid', pending_left: pending ? 100 : -1, uptime_s: 3 }); }, 4900);
}

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 390, height: 800 } });   // phone-sized
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  page.on('dialog', d => d.accept());
  const fw = (name, size) => ({ name, mimeType: 'application/octet-stream', buffer: Buffer.alloc(size, 7) });

  // ---- Update page: initial render
  await page.goto(base + '/update'); await page.waitForFunction(() => document.getElementById('iVer').textContent !== '...');
  check(await page.textContent('#iVer') === '2.5.0', 'status table shows running version');
  check((await page.textContent('#iSlot')) === 'ota_0' && (await page.textContent('#iProj')).includes('esp32c3'), 'slot + project/chip rendered from real status JSON');
  check((await page.textContent('#iState')).includes('Valid'), 'state "valid" rendered');
  check((await page.textContent('#iPrev')).includes('2.4.0'), 'previous firmware shown');
  check(await page.isEnabled('#rbBtn'), 'rollback enabled when previous firmware exists');
  check((await page.getAttribute('#fw', 'accept')) === null, 'file input has no accept filter (Android picker compatibility)');

  // ---- client-side validation
  await page.setInputFiles('#fw', fw('firmware.txt', 300000)); await page.click('#upBtn');
  check((await page.textContent('#msg')).includes('.bin'), 'rejects non-.bin file locally');
  await page.setInputFiles('#fw', fw('tiny.bin', 1000)); await page.click('#upBtn');
  check((await page.textContent('#msg')).includes('too small'), 'rejects tiny file locally');
  await page.setInputFiles('#fw', fw('huge.bin', 1700000)); await page.click('#upBtn');
  check((await page.textContent('#msg')).includes('larger than the update slot'), 'rejects file larger than slot locally');
  check(dev.uploads.length === 0, 'nothing was sent to the device for invalid files');

  // ---- device-side rejection, then force flow
  dev.uploadMode = 'wrong_chip';
  await page.setInputFiles('#fw', fw('esp32_nat_router.bin', 300000)); await page.click('#upBtn');
  await page.waitForFunction(() => document.getElementById('msg').textContent.includes('chip id'));
  check(await page.isEnabled('#upBtn') && await page.isEnabled('#fw'), 'UI unlocked after device rejects the file');
  check(!(await page.isVisible('#forceRow')), 'force option hidden for wrong chip');
  dev.uploadMode = 'wrong_project';
  await page.click('#upBtn'); await page.waitForFunction(() => document.getElementById('msg').textContent.includes('different project'));
  check(await page.isVisible('#forceRow'), 'force option appears only after project mismatch');
  await page.check('#force'); dev.uploadMode = 'ok';
  dev.uploads.length = 0;
  await page.click('#upBtn');

  // ---- progress, verify stage, reboot wait, success
  await page.waitForFunction(() => /Restarting|Verifying/.test(document.getElementById('stage').textContent), null, { timeout: 15000 });
  check(dev.uploads.length === 1 && dev.uploads[0].query === 'force=1', 'upload POSTed with ?force=1 after override');
  check(dev.uploads[0].bytes === 300000 && dev.uploads[0].ctype === 'application/octet-stream', 'raw binary body, full size, correct content-type');
  check(await page.isDisabled('#upBtn'), 'upload button locked during update');
  await page.waitForFunction(() => document.getElementById('msg').textContent.includes('Router is back'), null, { timeout: 40000 });
  check((await page.textContent('#msg')).includes('2.6.0') && (await page.textContent('#msg')).includes('ota_1'), 'UI detects reboot into new slot/version');
  check((await page.textContent('#iVer')) === '2.6.0' && (await page.textContent('#pendBox')).includes('not confirmed yet'), 'status refreshed; pending-validation banner shown');
  check(await page.isEnabled('#upBtn'), 'UI unlocked after update');

  // ---- confirm now
  await page.click('#cfBtn'); await page.waitForFunction(() => document.getElementById('pendBox').style.display === 'none');
  check((await page.textContent('#iState')).includes('Valid'), 'Confirm now marks firmware valid and hides banner');

  // ---- connection lost mid-upload
  dev.resetMidUpload = true; await page.setInputFiles('#fw', fw('again.bin', 900000)); await page.click('#upBtn');
  await page.waitForFunction(() => document.getElementById('msg').textContent.includes('Connection lost'), null, { timeout: 15000 });
  check(await page.isEnabled('#upBtn'), 'connection loss reported, UI recovers, device not changed');
  dev.resetMidUpload = false;

  // ---- manual rollback
  await page.click('#rbBtn');
  await page.waitForFunction(() => document.getElementById('msg').textContent.includes('Router is back'), null, { timeout: 40000 });
  check((await page.textContent('#iVer')) === '2.4.0', 'manual rollback ends on previous firmware');

  // ---- TTL section
  await page.goto(base + '/config'); await page.waitForFunction(() => document.getElementById('ttlStatus').textContent !== '...');
  check((await page.inputValue('#ttlVal')) === '64' && !(await page.isChecked('#ttlOn')), 'TTL: defaults to off, value 64');
  await page.selectOption('#ttlPreset', '128'); check((await page.inputValue('#ttlVal')) === '128', 'TTL: preset 128 fills the number box');
  await page.fill('#ttlVal', '100'); check((await page.inputValue('#ttlPreset')) === '', 'TTL: custom number switches preset to Other');
  await page.fill('#ttlVal', '64'); check((await page.inputValue('#ttlPreset')) === '64', 'TTL: typing 64 selects the 64 preset');
  await page.check('#ttlOn'); await page.fill('#ttlVal', '300'); await page.click('#ttlApply');
  check((await page.textContent('#ttlStatus')).includes('1 to 255') && dev.posts.length === 0, 'TTL: out-of-range rejected client-side, nothing sent');
  await page.fill('#ttlVal', '128'); await page.click('#ttlSave');
  await page.waitForFunction(() => document.getElementById('ttlStatus').textContent.includes('Saved: 128'));
  check((await page.textContent('#ttlStatus')).includes('Active: off') && (await page.textContent('#ttlStatus')).includes('press Apply'), 'TTL: Save persists but shows "not active - press Apply"');
  check(dev.posts[0] === 'action=save&enabled=1&value=128', 'TTL: Save request body');
  await page.click('#ttlApply'); await page.waitForFunction(() => document.getElementById('ttlStatus').textContent.includes('Active: 128'));
  check(!(await page.textContent('#ttlStatus')).includes('press Apply'), 'TTL: Apply activates, warning cleared');
  await page.uncheck('#ttlOn'); await page.click('#ttlApply');
  await page.waitForFunction(() => document.getElementById('ttlStatus').textContent.includes('Active: off'));
  check(dev.posts.at(-1) === 'action=apply&enabled=0&value=128' && (await page.inputValue('#ttlVal')) === '128', 'TTL: toggle off sends enabled=0 and remembers 128');
  await page.reload(); await page.waitForFunction(() => document.getElementById('ttlStatus').textContent !== '...');
  check((await page.inputValue('#ttlVal')) === '128' && !(await page.isChecked('#ttlOn')), 'TTL: after reload shows off with remembered 128');
  dev.ttlFail = true; await page.check('#ttlOn'); await page.click('#ttlApply');
  await page.waitForFunction(() => document.getElementById('ttlStatus').textContent.includes('flash'));
  check(true, 'TTL: device error is surfaced to the user');

  check(errors.length === 0, 'no JavaScript errors on any page' + (errors.length ? ': ' + errors.join('; ') : ''));
  await browser.close(); server.close();
  console.log(`\n${checks} checks, ${fails} failed`);
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
