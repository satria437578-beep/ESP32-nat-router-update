/* Host test for the OTA/TTL HTTP handlers in components/http_server/http_server.c.
 * The code between the @@API_BEGIN@@/@@API_END@@ markers is extracted verbatim
 * (run_tests.sh) and compiled here against tiny stubs of httpd, the OTA flash
 * API, NVS and the OTA manager. */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include "esp_err.h"
#include "esp_app_format.h"
#include "ota_manager.h"
#include "ota_validate.h"
#include "ttl_logic.h"

/* ---------------- stubs ---------------- */
#define CONFIG_IDF_FIRMWARE_CHIP_ID 5
#define CONFIG_IDF_TARGET "esp32c3"
#define ESP_LOGX(t, ...) do { (void)(t); if (0) printf(__VA_ARGS__); } while (0)
#define ESP_LOGI(t, ...) ESP_LOGX(t, __VA_ARGS__)
#define ESP_LOGW(t, ...) ESP_LOGX(t, __VA_ARGS__)
#define ESP_LOGE(t, ...) ESP_LOGX(t, __VA_ARGS__)
static const char *TAG = "test";
#define HTTPD_RESP_USE_STRLEN (-1)
#define HTTPD_SOCK_ERR_TIMEOUT (-3)
typedef enum { HTTPD_400_BAD_REQUEST = 400, HTTPD_403_FORBIDDEN = 403, HTTPD_500_INTERNAL_SERVER_ERROR = 500 } httpd_err_code_t;
typedef enum { HTTP_GET = 1, HTTP_POST = 3 } http_method;
typedef struct httpd_req { size_t content_len; const char *query; } httpd_req_t;
typedef esp_err_t (*httpd_handler_t)(httpd_req_t *);
typedef struct { const char *uri; http_method method; httpd_handler_t handler; void *user_ctx; } httpd_uri_t;
typedef struct { char label[17]; uint32_t size; uint32_t address; } esp_partition_t;
typedef int esp_ota_handle_t;
#define OTA_WITH_SEQUENTIAL_WRITES 0xfffffffe
typedef void *esp_timer_handle_t;
static esp_timer_handle_t restart_timer;
static int sta_ttl_override;

static struct {
    /* request side */
    const uint8_t *body; size_t body_len; size_t pos; size_t max_read;
    int stall_at; int stall_count;        /* inject N consecutive timeouts once pos >= stall_at */
    bool csrf_ok, pw_set, authed;
    /* response side */
    char resp[1024]; char status[48]; int err_code; int sends; int chunks;
    /* flash side */
    esp_partition_t part; bool have_part;
    int begin_calls, write_calls, end_calls, abort_calls, setboot_calls;
    size_t written; esp_err_t end_ret, write_ret, begin_ret;
    int fail_write_after;
    /* misc */
    int restart_started; int restart_delay;
    int nvs_sets; int nvs_saved, nvs_last; bool nvs_have_saved, nvs_have_last; bool nvs_set_fail;
    int confirm_ret, rollback_ret;
    char query_force[4];
} sim;

static bool check_csrf(httpd_req_t *r) { (void)r; return sim.csrf_ok; }
static bool is_web_password_set(void) { return sim.pw_set; }
static bool is_authenticated(httpd_req_t *r) { (void)r; return sim.authed; }
static char *get_client_ip(httpd_req_t *r, char *b, size_t l) { (void)r; snprintf(b, l, "1.2.3.4"); return b; }
static void resume_sta_if_scan_idle(void) {}
#define SEND_CHUNK(req, ...) do { if (httpd_resp_send_chunk((req), __VA_ARGS__) != ESP_OK) return ESP_FAIL; } while (0)
#define UPDATE_CHUNK_HEAD "<h>"
#define UPDATE_CHUNK_BODY "<b>"
#define UPDATE_CHUNK_SCRIPT "<s>"
static esp_err_t httpd_resp_send_chunk(httpd_req_t *r, const char *b, ssize_t l) { (void)r; (void)b; (void)l; sim.chunks++; return ESP_OK; }
static esp_err_t httpd_resp_send_err(httpd_req_t *r, httpd_err_code_t c, const char *m) { (void)r; (void)m; sim.err_code = c; return ESP_OK; }
static esp_err_t httpd_resp_set_type(httpd_req_t *r, const char *t) { (void)r; (void)t; return ESP_OK; }
static esp_err_t httpd_resp_set_hdr(httpd_req_t *r, const char *k, const char *v) { (void)r; (void)k; (void)v; return ESP_OK; }
static esp_err_t httpd_resp_set_status(httpd_req_t *r, const char *s) { (void)r; snprintf(sim.status, sizeof sim.status, "%s", s); return ESP_OK; }
static esp_err_t httpd_resp_send(httpd_req_t *r, const char *b, ssize_t l)
{
    (void)r; sim.sends++;
    snprintf(sim.resp, sizeof sim.resp, "%.*s", (int)(l < 0 ? (ssize_t)strlen(b) : l), b ? b : "");
    return ESP_OK;
}
static int httpd_req_recv(httpd_req_t *r, char *buf, size_t len)
{
    (void)r;
    if (sim.stall_count > 0 && sim.pos >= (size_t)sim.stall_at) { sim.stall_count--; return HTTPD_SOCK_ERR_TIMEOUT; }
    size_t left = sim.body_len - sim.pos;
    if (left == 0) return 0;
    size_t n = MIN(MIN(len, left), sim.max_read);
    memcpy(buf, sim.body + sim.pos, n);
    sim.pos += n;
    return (int)n;
}
static esp_err_t httpd_req_get_url_query_str(httpd_req_t *r, char *buf, size_t l)
{
    if (!r->query) return ESP_FAIL;
    snprintf(buf, l, "%s", r->query);
    return ESP_OK;
}
static esp_err_t httpd_query_key_value(const char *qs, const char *key, char *val, size_t l)
{
    size_t kl = strlen(key);
    for (const char *p = qs; p && *p; ) {
        if (strncmp(p, key, kl) == 0 && p[kl] == '=') {
            const char *e = strchr(p + kl + 1, '&'); size_t n = e ? (size_t)(e - p - kl - 1) : strlen(p + kl + 1);
            if (n >= l) return ESP_FAIL;
            memcpy(val, p + kl + 1, n); val[n] = 0; return ESP_OK;
        }
        p = strchr(p, '&'); if (p) p++;
    }
    return ESP_FAIL;
}
static const esp_partition_t *esp_ota_get_next_update_partition(const esp_partition_t *s) { (void)s; return sim.have_part ? &sim.part : NULL; }
static esp_err_t esp_ota_begin(const esp_partition_t *p, size_t sz, esp_ota_handle_t *h) { (void)p; (void)sz; sim.begin_calls++; *h = 7; return sim.begin_ret; }
static esp_err_t esp_ota_write(esp_ota_handle_t h, const void *d, size_t n)
{
    (void)h; (void)d; sim.write_calls++;
    if (sim.fail_write_after >= 0 && sim.write_calls > sim.fail_write_after) return 0x104;
    sim.written += n; return sim.write_ret;
}
static esp_err_t esp_ota_end(esp_ota_handle_t h) { (void)h; sim.end_calls++; return sim.end_ret; }
static esp_err_t esp_ota_abort(esp_ota_handle_t h) { (void)h; sim.abort_calls++; return ESP_OK; }
static esp_err_t esp_ota_set_boot_partition(const esp_partition_t *p) { (void)p; sim.setboot_calls++; return ESP_OK; }
static const char *esp_err_to_name(esp_err_t e) { static char b[16]; snprintf(b, sizeof b, "0x%x", e); return b; }
static esp_app_desc_t g_desc;
static const esp_app_desc_t *esp_app_get_description(void) { return &g_desc; }
static esp_err_t esp_timer_start_once(esp_timer_handle_t t, uint64_t us) { (void)t; sim.restart_started++; sim.restart_delay = (int)(us / 1000); return ESP_OK; }
static esp_err_t get_config_param_int(char *name, int *p)
{
    if (!strcmp(name, "sta_ttl") && sim.nvs_have_saved) { *p = sim.nvs_saved; return ESP_OK; }
    if (!strcmp(name, "sta_ttl_last") && sim.nvs_have_last) { *p = sim.nvs_last; return ESP_OK; }
    return ESP_FAIL;
}
static esp_err_t set_config_param_int(const char *name, int32_t v)
{
    if (sim.nvs_set_fail) return ESP_FAIL;
    sim.nvs_sets++;
    if (!strcmp(name, "sta_ttl")) { sim.nvs_saved = v; sim.nvs_have_saved = true; }
    else if (!strcmp(name, "sta_ttl_last")) { sim.nvs_last = v; sim.nvs_have_last = true; }
    else { printf("UNEXPECTED NVS KEY %s\n", name); exit(2); }
    return ESP_OK;
}
void ota_manager_get_info(ota_info_t *o)
{
    memset(o, 0, sizeof *o);
    strcpy(o->running_label, "ota_0"); strcpy(o->other_label, "ota_1"); strcpy(o->state, "pending");
    strcpy(o->version, "2.5.\"x\"\\1"); strcpy(o->project, "esp32_nat_router"); strcpy(o->prev_version, "2.4.0");
    o->slot_size = 1572864; o->uptime_s = 42; o->pending = true; o->pending_left_s = 100; o->rollback_possible = true;
}
esp_err_t ota_manager_confirm(void) { return sim.confirm_ret; }
esp_err_t ota_manager_rollback_previous(void) { return sim.rollback_ret; }

/* ---------------- code under test (extracted verbatim) ---------------- */
#include "api_block.inc"

/* ---------------- test helpers ---------------- */
static int fails, checks;
#define CHECK(c) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: %s\n   resp=%s\n", __LINE__, #c, sim.resp); } } while (0)
#define CHECK_RESP(sub) do { checks++; if (!strstr(sim.resp, sub)) { fails++; printf("FAIL line %d: resp lacks %s\n   resp=%s\n", __LINE__, sub, sim.resp); } } while (0)

static void reset(void)
{
    memset(&sim, 0, sizeof sim);
    sim.max_read = 1460; sim.csrf_ok = true; sim.have_part = true;
    strcpy(sim.part.label, "ota_1"); sim.part.size = 1572864; sim.part.address = 0x1a0000;
    sim.fail_write_after = -1; sim.stall_at = -1;
    s_ota_busy = false; sta_ttl_override = 0;
    memset(&g_desc, 0, sizeof g_desc); strcpy(g_desc.project_name, "esp32_nat_router");
}

static uint8_t *make_fw(size_t n, uint16_t chip, uint32_t dmagic, const char *proj, uint8_t magic)
{
    uint8_t *b = calloc(1, n < 600 ? 600 : n);   /* header+descriptor always fit; n may be a "truncated" length */
    esp_image_header_t h; memset(&h, 0, sizeof h); h.magic = magic; h.chip_id = chip;
    memcpy(b, &h, sizeof h);
    esp_app_desc_t d; memset(&d, 0, sizeof d); d.magic_word = dmagic; strncpy(d.project_name, proj, 31);
    memcpy(b + 32, &d, sizeof d);
    for (size_t i = 300; i < n; i++) b[i] = (uint8_t)(i * 31);
    return b;
}

static esp_err_t upload(uint8_t *fw, size_t len, const char *query)
{
    httpd_req_t req = { .content_len = len, .query = query };
    sim.body = fw; sim.body_len = len; sim.pos = 0;
    sim.resp[0] = 0;
    esp_err_t r = ota_upload_handler(&req);
    if (sim.resp[0]) printf("JSON:%s\n", sim.resp);   /* no reply when the connection is dead / rejected */
    return r;
}
static esp_err_t post_ttl(const char *body)
{
    httpd_req_t req = { .content_len = strlen(body) };
    sim.body = (const uint8_t *)body; sim.body_len = strlen(body); sim.pos = 0;
    sim.resp[0] = 0;
    esp_err_t r = ttl_post_handler(&req);
    if (sim.resp[0]) printf("JSON:%s\n", sim.resp);
    return r;
}

/* ---------------- tests ---------------- */
static void t_upload_ok(void)
{
    reset();
    size_t n = 300000; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    CHECK(upload(fw, n, NULL) == ESP_OK);
    CHECK_RESP("\"ok\":true");
    CHECK(sim.begin_calls == 1 && sim.end_calls == 1 && sim.setboot_calls == 1 && sim.abort_calls == 0);
    CHECK(sim.written == n);                     /* every byte reached flash, none twice */
    CHECK(sim.restart_started == 1 && sim.restart_delay == 3000);
    CHECK(!s_ota_busy);
    free(fw);
}
static void t_upload_sizes(void)
{
    /* sizes around the chunk (4096) and the first-chunk header boundary */
    size_t sizes[] = { 288, 289, 4095, 4096, 4097, 8192, 12289, 1572864 };
    for (unsigned i = 0; i < sizeof sizes / sizeof *sizes; i++) {
        reset();
        uint8_t *fw = make_fw(sizes[i], 5, 0xABCD5432, "esp32_nat_router", 0xE9);
        CHECK(upload(fw, sizes[i], NULL) == ESP_OK);
        CHECK(sim.written == sizes[i] && sim.setboot_calls == 1);
        free(fw);
    }
    /* 1 byte over the slot is rejected, exactly the slot size accepted (checked above) */
    reset();
    size_t n = 1572864 + 1; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    CHECK(upload(fw, n, NULL) == ESP_FAIL);      /* reply sent, connection closed */
    CHECK_RESP("\"code\":\"too_large\"");
    CHECK(sim.begin_calls == 0 && sim.pos == 0); /* nothing read, nothing erased */
    free(fw);
}
static void t_upload_rejects(void)
{
    struct { const char *name; uint16_t chip; uint32_t dm; const char *proj; uint8_t magic; const char *code; } c[] = {
        { "wrong chip",   0,  0xABCD5432, "esp32_nat_router", 0xE9, "wrong_chip" },
        { "bad magic",    5,  0xABCD5432, "esp32_nat_router", 0x00, "bad_magic" },
        { "no app desc",  5,  0,          "esp32_nat_router", 0xE9, "no_app_desc" },
        { "other project",5,  0xABCD5432, "someone_else",     0xE9, "wrong_project" },
    };
    for (unsigned i = 0; i < sizeof c / sizeof *c; i++) {
        reset();
        size_t n = 200000; uint8_t *fw = make_fw(n, c[i].chip, c[i].dm, c[i].proj, c[i].magic);
        CHECK(upload(fw, n, NULL) == ESP_OK);
        CHECK_RESP("\"ok\":false"); CHECK_RESP(c[i].code);
        CHECK(sim.begin_calls == 0 && sim.write_calls == 0 && sim.setboot_calls == 0 && sim.restart_started == 0);
        CHECK(sim.pos == n);                     /* body drained: client gets our message, not a reset */
        CHECK(!s_ota_busy);
        free(fw);
    }
    /* force=1 overrides only the project name */
    reset();
    size_t n = 100000; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "someone_else", 0xE9);
    CHECK(upload(fw, n, "force=1") == ESP_OK); CHECK_RESP("\"ok\":true"); CHECK(sim.setboot_calls == 1);
    free(fw);
    reset();
    fw = make_fw(n, 0, 0xABCD5432, "someone_else", 0xE9);
    CHECK(upload(fw, n, "force=1") == ESP_OK); CHECK_RESP("wrong_chip"); CHECK(sim.begin_calls == 0);
    free(fw);
    /* empty and tiny uploads */
    reset(); CHECK(upload((uint8_t *)"", 0, NULL) == ESP_OK); CHECK_RESP("\"code\":\"empty\""); CHECK(sim.begin_calls == 0);
    reset(); fw = make_fw(100, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    CHECK(upload(fw, 100, NULL) == ESP_OK); CHECK_RESP("too_short"); CHECK(sim.begin_calls == 0 && sim.pos == 100);
    free(fw);
    /* no OTA partition */
    reset(); sim.have_part = false; fw = make_fw(1000, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    CHECK(upload(fw, 1000, NULL) == ESP_OK); CHECK_RESP("no_partition"); free(fw);
}
static void t_upload_flash_errors(void)
{
    size_t n = 200000; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    reset(); sim.end_ret = 0x10B;               /* esp_ota_end: image validation failed */
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"code\":\"verify\"");
    CHECK(sim.setboot_calls == 0 && sim.abort_calls == 0 && sim.restart_started == 0);   /* boot slot untouched */
    reset(); sim.begin_ret = 0x102;
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"code\":\"begin\""); CHECK(sim.abort_calls == 0 && sim.pos == n);
    reset(); sim.fail_write_after = 10;         /* flash write error mid-way */
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"code\":\"write\"");
    CHECK(sim.abort_calls == 1 && sim.setboot_calls == 0 && sim.end_calls == 0 && sim.restart_started == 0 && sim.pos == n);
    free(fw);
}
static void t_upload_network(void)
{
    size_t n = 200000; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    /* a 6 s Wi-Fi stall (3 x 2 s timeouts) mid-upload must not kill the update */
    reset(); sim.stall_at = 50000; sim.stall_count = 3;
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"ok\":true"); CHECK(sim.written == n);
    /* ... also during the very first (header) read */
    reset(); sim.stall_at = 0; sim.stall_count = 4;
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"ok\":true");
    /* a dead client (long stall) aborts cleanly: spare slot aborted, no boot change, no reply */
    reset(); sim.stall_at = 50000; sim.stall_count = 100; sim.resp[0] = 0;
    CHECK(upload(fw, n, NULL) == ESP_FAIL);
    CHECK(sim.abort_calls == 1 && sim.setboot_calls == 0 && sim.restart_started == 0 && sim.sends == 0);
    CHECK(!s_ota_busy);
    /* client closes early (EOF) */
    reset(); sim.body_len = 0;
    httpd_req_t req = { .content_len = n }; sim.body = fw; sim.body_len = 60000; sim.pos = 0;
    CHECK(ota_upload_handler(&req) == ESP_FAIL); CHECK(sim.abort_calls == 1 && sim.setboot_calls == 0 && !s_ota_busy);
    free(fw);
}
static void t_upload_guard(void)
{
    size_t n = 100000; uint8_t *fw = make_fw(n, 5, 0xABCD5432, "esp32_nat_router", 0xE9);
    reset(); sim.csrf_ok = false;
    CHECK(upload(fw, n, NULL) == ESP_FAIL); CHECK(sim.err_code == 403 && sim.begin_calls == 0 && sim.pos == 0);
    reset(); sim.pw_set = true; sim.authed = false;
    CHECK(upload(fw, n, NULL) == ESP_FAIL); CHECK(sim.err_code == 403 && sim.begin_calls == 0);
    reset(); sim.pw_set = true; sim.authed = true;
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"ok\":true");
    reset(); s_ota_busy = true;                 /* second upload while one is running */
    CHECK(upload(fw, n, NULL) == ESP_OK); CHECK_RESP("\"code\":\"busy\""); CHECK(strstr(sim.status, "409") && sim.begin_calls == 0);
    free(fw);
}
static void t_endpoints(void)
{
    httpd_req_t req = { 0 };
    reset(); CHECK(ota_status_handler(&req) == ESP_OK); printf("JSON:%s\n", sim.resp);
    CHECK_RESP("\"slot\":\"ota_0\""); CHECK_RESP("\"pending\":true"); CHECK_RESP("\"rollback\":true");
    CHECK_RESP("\"chip\":\"esp32c3\""); CHECK_RESP("\\\"x\\\"\\\\1");            /* version string was JSON-escaped */
    reset(); sim.pw_set = true; CHECK(ota_status_handler(&req) == ESP_FAIL && sim.err_code == 403);
    reset(); sim.confirm_ret = ESP_OK; CHECK(ota_confirm_handler(&req) == ESP_OK); CHECK_RESP("\"ok\":true");
    reset(); sim.confirm_ret = ESP_ERR_INVALID_STATE; CHECK(ota_confirm_handler(&req) == ESP_OK); CHECK_RESP("\"ok\":false");
    reset(); sim.rollback_ret = ESP_OK; CHECK(ota_rollback_handler(&req) == ESP_OK); CHECK_RESP("\"ok\":true"); CHECK(sim.restart_started == 1);
    reset(); sim.rollback_ret = ESP_ERR_NOT_FOUND; CHECK(ota_rollback_handler(&req) == ESP_OK); CHECK_RESP("\"ok\":false"); CHECK(sim.restart_started == 0);
    reset(); sim.csrf_ok = false; CHECK(ota_rollback_handler(&req) == ESP_FAIL); CHECK(sim.restart_started == 0);
    reset(); CHECK(update_get_handler(&req) == ESP_OK); CHECK(sim.chunks == 4);
    reset(); sim.pw_set = true; CHECK(update_get_handler(&req) == ESP_OK); CHECK(strstr(sim.status, "303") && sim.chunks == 0);
}
static void t_ttl(void)
{
    httpd_req_t req = { 0 };
    /* GET with nothing stored: defaults */
    reset(); CHECK(ttl_get_handler(&req) == ESP_OK); printf("JSON:%s\n", sim.resp);
    CHECK_RESP("\"active\":0"); CHECK_RESP("\"saved\":0"); CHECK_RESP("\"display\":64");
    /* Save: persisted to the CLI's key, NOT active yet */
    reset(); CHECK(post_ttl("action=save&enabled=1&value=128") == ESP_OK);
    CHECK_RESP("\"ok\":true"); CHECK_RESP("\"msg\":\"Saved\"");
    CHECK(sim.nvs_saved == 128 && sim.nvs_last == 128 && sta_ttl_override == 0);
    CHECK_RESP("\"active\":0"); CHECK_RESP("\"saved\":128");
    /* Apply: persisted and active immediately (packet path reads sta_ttl_override) */
    reset(); CHECK(post_ttl("action=apply&enabled=1&value=64") == ESP_OK);
    CHECK(sim.nvs_saved == 64 && sta_ttl_override == 64); CHECK_RESP("\"msg\":\"Applied\"");
    /* Toggle OFF + Apply: runtime and NVS 0, previous number remembered for the UI */
    CHECK(post_ttl("action=apply&enabled=0&value=64") == ESP_OK);
    CHECK(sim.nvs_saved == 0 && sta_ttl_override == 0 && sim.nvs_last == 64); CHECK_RESP("\"display\":64");
    /* OFF without a value must not clobber the remembered one */
    reset(); sim.nvs_have_last = true; sim.nvs_last = 128;
    CHECK(post_ttl("action=apply&enabled=0") == ESP_OK); CHECK(sim.nvs_saved == 0 && sim.nvs_last == 128); CHECK_RESP("\"display\":128");
    /* CLI-set value (sta_ttl=77, no sta_ttl_last) shows up in the UI */
    reset(); sim.nvs_have_saved = true; sim.nvs_saved = 77; sta_ttl_override = 77;
    CHECK(ttl_get_handler(&req) == ESP_OK); CHECK_RESP("\"active\":77"); CHECK_RESP("\"saved\":77"); CHECK_RESP("\"display\":77");
    /* Invalid requests change nothing */
    const char *bad[] = { "action=apply&enabled=1&value=0", "action=apply&enabled=1&value=256", "action=apply&enabled=1",
                          "action=x&enabled=1&value=64", "enabled=1&value=64", "garbage" };
    for (unsigned i = 0; i < sizeof bad / sizeof *bad; i++) {
        reset(); sta_ttl_override = 55;
        CHECK(post_ttl(bad[i]) == ESP_OK); CHECK_RESP("\"ok\":false"); CHECK(strstr(sim.status, "400"));
        CHECK(sim.nvs_sets == 0 && sta_ttl_override == 55);
    }
    /* NVS write failure: report it, do not activate */
    reset(); sim.nvs_set_fail = true;
    CHECK(post_ttl("action=apply&enabled=1&value=64") == ESP_OK); CHECK_RESP("\"ok\":false"); CHECK(sta_ttl_override == 0);
    /* oversize / empty bodies and guards */
    reset(); { char big[200]; memset(big, 'a', 199); big[199] = 0; CHECK(post_ttl(big) == ESP_FAIL); CHECK(sim.err_code == 400 && sim.nvs_sets == 0); }
    reset(); CHECK(post_ttl("") == ESP_FAIL && sim.err_code == 400);
    reset(); sim.csrf_ok = false; CHECK(post_ttl("action=apply&enabled=1&value=64") == ESP_FAIL); CHECK(sim.nvs_sets == 0 && sta_ttl_override == 0);
    reset(); sim.pw_set = true; CHECK(post_ttl("action=apply&enabled=1&value=64") == ESP_FAIL); CHECK(sim.nvs_sets == 0);
}

static void t_uris(void)
{
    httpd_uri_t *u[] = { &ota_uploadp, &ota_statusp, &ota_confirmp, &ota_rollbackp, &updatep, &ttl_getp, &ttl_postp };
    const char *want[] = { "POST /api/ota-upload", "GET /api/ota-status", "POST /api/ota-confirm", "POST /api/ota-rollback",
                           "GET /update", "GET /api/ttl", "POST /api/ttl" };
    for (unsigned i = 0; i < sizeof u / sizeof *u; i++) {
        char got[64]; snprintf(got, sizeof got, "%s %s", u[i]->method == HTTP_POST ? "POST" : "GET", u[i]->uri);
        CHECK(strcmp(got, want[i]) == 0 && u[i]->handler != NULL);
        for (unsigned j = i + 1; j < sizeof u / sizeof *u; j++) CHECK(u[i]->handler != u[j]->handler);
    }
}

int main(void)
{
    t_uris(); t_upload_ok(); t_upload_sizes(); t_upload_rejects(); t_upload_flash_errors();
    t_upload_network(); t_upload_guard(); t_endpoints(); t_ttl();
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
