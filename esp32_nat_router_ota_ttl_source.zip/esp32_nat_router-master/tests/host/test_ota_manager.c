/* Host test of ota_manager.c: deferred validation + automatic rollback logic,
 * run on a virtual clock against stubs of the ESP-IDF OTA/netif/FreeRTOS APIs.
 * ota_manager.c is #included so its statics can be reset between scenarios. */
#include <setjmp.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "ota_manager.c"

static int fails, checks;
#define CHECK(c) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

/* ---- simulated device ---- */
static struct {
    esp_partition_t run, other;
    esp_ota_img_states_t run_state; bool run_state_known;
    esp_ota_img_states_t other_state; bool other_state_known; bool other_has_image;
    char other_ver[32];
    bool ap_up; int64_t now_us;
    int tasks_created; int valid_calls; int rollback_calls; int setboot_calls;
    int second; int (*per_second)(int sec);   /* scenario hook, runs once per virtual second */
    bool create_fails; bool rollback_returns;
    jmp_buf reboot;
} sim;
static esp_netif_t *AP = (esp_netif_t *)0x1;
static TaskFunction_t task_fn;

const esp_partition_t *esp_ota_get_running_partition(void) { return &sim.run; }
const esp_partition_t *esp_ota_get_next_update_partition(const esp_partition_t *s) { (void)s; return &sim.other; }
esp_err_t esp_ota_get_state_partition(const esp_partition_t *p, esp_ota_img_states_t *s)
{
    if (p == &sim.run) { if (!sim.run_state_known) return ESP_ERR_NOT_FOUND; *s = sim.run_state; return ESP_OK; }
    if (!sim.other_state_known) return ESP_ERR_NOT_FOUND;
    *s = sim.other_state;
    return ESP_OK;
}
esp_err_t esp_ota_get_partition_description(const esp_partition_t *p, esp_app_desc_t *d)
{
    if (p != &sim.other || !sim.other_has_image) return ESP_ERR_NOT_FOUND;
    memset(d, 0, sizeof *d); strcpy(d->version, sim.other_ver); return ESP_OK;
}
esp_err_t esp_ota_mark_app_valid_cancel_rollback(void)
{
    sim.valid_calls++;
    if (sim.run_state_known && sim.run_state == ESP_OTA_IMG_PENDING_VERIFY) { sim.run_state = ESP_OTA_IMG_VALID; return ESP_OK; }
    return ESP_ERR_INVALID_STATE;
}
esp_err_t esp_ota_mark_app_invalid_rollback_and_reboot(void)
{
    sim.rollback_calls++;
    if (sim.rollback_returns) return ESP_FAIL;   /* no previous image: the real call returns an error */
    longjmp(sim.reboot, 1);                      /* ...and never returns on success */
}
esp_err_t esp_ota_set_boot_partition(const esp_partition_t *p) { (void)p; sim.setboot_calls++; return ESP_OK; }
static esp_app_desc_t app = { .version = "2.6.0", .project_name = "esp32_nat_router" };
const esp_app_desc_t *esp_app_get_description(void) { return &app; }
esp_netif_t *esp_netif_get_handle_from_ifkey(const char *k) { return strcmp(k, "WIFI_AP_DEF") == 0 ? AP : NULL; }
bool esp_netif_is_netif_up(esp_netif_t *n) { return n == AP && sim.ap_up; }
int64_t esp_timer_get_time(void) { return sim.now_us; }
BaseType_t xTaskCreate(TaskFunction_t f, const char *n, uint32_t st, void *a, unsigned p, void *h)
{ (void)n; (void)st; (void)a; (void)p; (void)h; if (sim.create_fails) return 0; sim.tasks_created++; task_fn = f; return pdPASS; }
void vTaskDelay(TickType_t t) { (void)t; sim.second++; sim.now_us += 1000000; if (sim.per_second) sim.per_second(sim.second); }
void vTaskDelete(void *h) { (void)h; }

static void reset(esp_ota_img_states_t st, bool known)
{
    memset(&sim, 0, sizeof sim);
    strcpy(sim.run.label, "ota_1"); sim.run.size = 1572864; strcpy(sim.other.label, "ota_0"); sim.other.size = 1572864;
    sim.run_state = st; sim.run_state_known = known;
    sim.other_has_image = true; strcpy(sim.other_ver, "2.4.0");
    s_ready_bits = 0; s_pending_left_s = -1; s_confirmed = false; task_fn = NULL;
}
/* run the validation task to completion; returns true if it ended in a rollback */
static bool run_task(void)
{
    if (!task_fn) return false;
    if (setjmp(sim.reboot) == 0) { task_fn(NULL); return false; }
    return true;
}

static int http_up_at_3_ap_up(int s) { if (s == 3) { s_ready_bits |= OTA_READY_HTTP; sim.ap_up = true; } return 0; }
static int flap_at_15(int s) { if (s == 2) { s_ready_bits |= OTA_READY_HTTP; sim.ap_up = true; } sim.ap_up = !(s == 15); return 0; }
static int user_confirms_at_8(int s) { if (s == 1) { s_ready_bits |= OTA_READY_HTTP; sim.ap_up = true; } if (s == 8) { CHECK(ota_manager_confirm() == ESP_OK); } return 0; }
static int only_http(int s) { (void)s; s_ready_bits |= OTA_READY_HTTP; return 0; }

int main(void)
{
    /* 1. healthy boot: confirmed after 3 s startup + 20 s stable, not before */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.per_second = http_up_at_3_ap_up;
    ota_manager_init(); CHECK(sim.tasks_created == 1);
    bool rb = run_task();
    CHECK(!rb && sim.valid_calls == 1 && sim.run_state == ESP_OTA_IMG_VALID && sim.rollback_calls == 0);
    CHECK(sim.second == 3 + OTA_VALIDATE_STABLE_S - 1);          /* healthy from s3 -> 20th stable second is s22 */

    /* 2. never healthy (AP/HTTP never up): rollback exactly at the timeout */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.per_second = NULL;
    ota_manager_init(); rb = run_task();
    CHECK(rb && sim.rollback_calls == 1 && sim.valid_calls == 0 && sim.second == OTA_VALIDATE_TIMEOUT_S);

    /* 3. HTTP server up but AP down (user could not reach the UI): rollback */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.per_second = only_http;
    ota_manager_init(); rb = run_task(); CHECK(rb && sim.rollback_calls == 1 && sim.valid_calls == 0);

    /* 4. a flap resets the stability counter, so confirmation is delayed, not skipped */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.per_second = flap_at_15;
    ota_manager_init(); rb = run_task();
    CHECK(!rb && sim.valid_calls == 1 && sim.second == 15 + OTA_VALIDATE_STABLE_S);

    /* 5. user presses Confirm: task stops, no rollback, no double confirm */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.per_second = user_confirms_at_8;
    ota_manager_init(); rb = run_task();
    CHECK(!rb && sim.run_state == ESP_OTA_IMG_VALID && sim.rollback_calls == 0 && sim.valid_calls == 1 && sim.second <= 9);
    CHECK(ota_manager_confirm() == ESP_ERR_INVALID_STATE);        /* nothing pending any more */

    /* 6. images that are not pending never start a task or allocate anything */
    reset(ESP_OTA_IMG_VALID, true); ota_manager_init(); CHECK(sim.tasks_created == 0 && sim.valid_calls == 0);
    reset(ESP_OTA_IMG_UNDEFINED, false); ota_manager_init(); CHECK(sim.tasks_created == 0);   /* flashed by cable */
    reset(ESP_OTA_IMG_VALID, true); CHECK(ota_manager_confirm() == ESP_ERR_INVALID_STATE);

    /* 7. cannot create the task: do not leave the image pending forever */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.create_fails = true; ota_manager_init();
    CHECK(sim.valid_calls == 1 && sim.run_state == ESP_OTA_IMG_VALID);

    /* 8. rollback impossible (no previous image): keep the device usable instead of looping */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); sim.rollback_returns = true;
    ota_manager_init(); rb = run_task();
    CHECK(!rb && sim.rollback_calls == 1 && sim.valid_calls == 1 && sim.run_state == ESP_OTA_IMG_VALID);

    /* 9. info for the UI */
    reset(ESP_OTA_IMG_PENDING_VERIFY, true); s_pending_left_s = 77; sim.now_us = 123 * 1000000LL;
    ota_info_t i; ota_manager_get_info(&i);
    CHECK(!strcmp(i.running_label, "ota_1") && !strcmp(i.other_label, "ota_0") && !strcmp(i.state, "pending"));
    CHECK(i.pending && i.pending_left_s == 77 && i.rollback_possible && !strcmp(i.prev_version, "2.4.0") && i.uptime_s == 123);
    CHECK(i.slot_size == 1572864 && !strcmp(i.version, "2.6.0") && !strcmp(i.project, "esp32_nat_router"));
    reset(ESP_OTA_IMG_VALID, true); ota_manager_get_info(&i); CHECK(!i.pending && i.pending_left_s == -1 && !strcmp(i.state, "valid"));
    reset(ESP_OTA_IMG_UNDEFINED, false); ota_manager_get_info(&i); CHECK(!strcmp(i.state, "undefined") && !i.pending);
    reset(ESP_OTA_IMG_VALID, true); sim.other_has_image = false; ota_manager_get_info(&i); CHECK(!i.rollback_possible && i.prev_version[0] == 0);
    reset(ESP_OTA_IMG_VALID, true); sim.other_state = ESP_OTA_IMG_ABORTED; sim.other_state_known = true;
    ota_manager_get_info(&i); CHECK(!i.rollback_possible);                 /* a slot that already failed is not offered */
    reset(ESP_OTA_IMG_VALID, true); sim.other_state = ESP_OTA_IMG_INVALID; sim.other_state_known = true;
    ota_manager_get_info(&i); CHECK(!i.rollback_possible);

    /* 10. manual rollback */
    reset(ESP_OTA_IMG_VALID, true); CHECK(ota_manager_rollback_previous() == ESP_OK && sim.setboot_calls == 1);
    reset(ESP_OTA_IMG_VALID, true); sim.other_has_image = false; CHECK(ota_manager_rollback_previous() == ESP_ERR_NOT_FOUND && sim.setboot_calls == 0);
    reset(ESP_OTA_IMG_VALID, true); sim.other_state = ESP_OTA_IMG_ABORTED; sim.other_state_known = true;
    CHECK(ota_manager_rollback_previous() == ESP_ERR_NOT_FOUND && sim.setboot_calls == 0);

    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
