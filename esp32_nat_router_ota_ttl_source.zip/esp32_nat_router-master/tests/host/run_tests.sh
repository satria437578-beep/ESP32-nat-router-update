#!/bin/sh
# Host-side tests (no ESP-IDF required): gcc + python3 only.
#   ./tests/host/run_tests.sh
set -e
cd "$(dirname "$0")/../.."
OUT=${TMPDIR:-/tmp}/esp32_nat_router_host_tests
mkdir -p "$OUT"
CFLAGS="-std=gnu11 -Wall -Wextra -Werror -g -fsanitize=address,undefined -fno-sanitize-recover=undefined \
  -Itests/host/shim -Icomponents/http_server -Icomponents/ota_manager/include -I$OUT"

echo "== unit tests (ttl_logic, ota_validate)"
gcc $CFLAGS tests/host/test_units.c components/http_server/ttl_logic.c \
    components/ota_manager/ota_validate.c -o "$OUT/test_units"
"$OUT/test_units"

echo "== HTTP API tests (code extracted from http_server.c)"
sed -n '/@@API_BEGIN@@/,/@@API_END@@/p' components/http_server/http_server.c > "$OUT/api_block.inc"
gcc $CFLAGS -Wno-unused-function tests/host/test_http_api.c components/http_server/ttl_logic.c \
    components/ota_manager/ota_validate.c -o "$OUT/test_http_api"
"$OUT/test_http_api" | tee "$OUT/api_out.txt" | grep -v '^JSON:'

echo "== ota_manager (validation / auto-rollback, virtual clock)"
gcc $CFLAGS -Icomponents/ota_manager tests/host/test_ota_manager.c -o "$OUT/test_ota_manager"
"$OUT/test_ota_manager"

echo "== every JSON reply parses"
grep '^JSON:' "$OUT/api_out.txt" | sed 's/^JSON://' | python3 -c "
import sys, json
n = 0
for line in sys.stdin:
    json.loads(line); n += 1
print(n, 'JSON replies valid')"
