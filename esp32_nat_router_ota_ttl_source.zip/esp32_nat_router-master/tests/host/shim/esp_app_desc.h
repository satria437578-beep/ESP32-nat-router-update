#pragma once
#include "esp_app_format.h"
const esp_app_desc_t *esp_app_get_description(void);
