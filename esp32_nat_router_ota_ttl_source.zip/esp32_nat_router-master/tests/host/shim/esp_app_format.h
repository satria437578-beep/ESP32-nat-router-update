/* Host-test shim: layout of the ESP-IDF image structures (IDF 5.x). */
#pragma once
#include <stdint.h>
#include <assert.h>
#define ESP_IMAGE_HEADER_MAGIC 0xE9
#define ESP_APP_DESC_MAGIC_WORD 0xABCD5432
typedef struct {
    uint8_t magic, segment_count, spi_mode;
    uint8_t spi_speed : 4, spi_size : 4;
    uint32_t entry_addr;
    uint8_t wp_pin;
    uint8_t spi_pin_drv[3];
    uint16_t chip_id;
    uint8_t min_chip_rev;
    uint16_t min_chip_rev_full, max_chip_rev_full;
    uint8_t reserved[4];
    uint8_t hash_appended;
} __attribute__((packed)) esp_image_header_t;
typedef struct { uint32_t load_addr, data_len; } esp_image_segment_header_t;
typedef struct {
    uint32_t magic_word, secure_version, reserv1[2];
    char version[32], project_name[32], time[16], date[16], idf_ver[32];
    uint8_t app_elf_sha256[32];
    uint16_t min_efuse_blk_rev_full, max_efuse_blk_rev_full;
    uint8_t mmu_page_size, reserv3[3];
    uint32_t reserv2[18];
} esp_app_desc_t;
static_assert(sizeof(esp_image_header_t) == 24, "image header is 24 bytes");
static_assert(sizeof(esp_image_segment_header_t) == 8, "segment header is 8 bytes");
static_assert(sizeof(esp_app_desc_t) == 256, "app desc is 256 bytes");
