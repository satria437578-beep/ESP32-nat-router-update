#pragma once
#include <stdio.h>
#define ESP_LOGX(t, ...) do { (void)(t); if (0) printf(__VA_ARGS__); } while (0)
#define ESP_LOGI(t, ...) ESP_LOGX(t, __VA_ARGS__)
#define ESP_LOGW(t, ...) ESP_LOGX(t, __VA_ARGS__)
#define ESP_LOGE(t, ...) ESP_LOGX(t, __VA_ARGS__)
