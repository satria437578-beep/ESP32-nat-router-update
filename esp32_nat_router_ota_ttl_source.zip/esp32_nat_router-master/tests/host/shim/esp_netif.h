#pragma once
#include <stdbool.h>
typedef struct esp_netif_obj esp_netif_t;
esp_netif_t *esp_netif_get_handle_from_ifkey(const char *if_key);
bool esp_netif_is_netif_up(esp_netif_t *n);
