#pragma once
#include "FreeRTOS.h"
typedef void (*TaskFunction_t)(void *);
BaseType_t xTaskCreate(TaskFunction_t f, const char *name, uint32_t stack, void *arg, unsigned prio, void *handle);
void vTaskDelay(TickType_t t);
void vTaskDelete(void *h);
