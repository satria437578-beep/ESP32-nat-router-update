/* Host unit tests for ttl_logic.c and ota_validate.c (no ESP-IDF needed). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ttl_logic.h"
#include "ota_validate.h"
#include "esp_app_format.h"

static int fails, checks;
#define CHECK(c) do { checks++; if (!(c)) { fails++; printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); } } while (0)

static ttl_err_t parse(const char *s, ttl_req_t *r) { return ttl_parse_request(s, r); }

static void test_ttl(void)
{
    ttl_req_t r;
    /* happy path */
    CHECK(parse("action=apply&enabled=1&value=64", &r) == TTL_OK);
    CHECK(r.action == TTL_ACT_APPLY && r.enabled && r.has_value && r.value == 64);
    CHECK(ttl_effective_value(&r) == 64);
    CHECK(parse("action=save&enabled=1&value=128", &r) == TTL_OK && r.action == TTL_ACT_SAVE && r.value == 128);
    /* parameter order / extra params */
    CHECK(parse("value=65&junk=1&enabled=1&action=save", &r) == TTL_OK && r.value == 65);
    /* boundaries */
    CHECK(parse("action=save&enabled=1&value=1", &r) == TTL_OK && r.value == 1);
    CHECK(parse("action=save&enabled=1&value=255", &r) == TTL_OK && r.value == 255);
    CHECK(parse("action=save&enabled=1&value=0", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=256", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=-1", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=64a", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=0064", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=6 4", &r) == TTL_ERR_VALUE);
    CHECK(parse("action=save&enabled=1&value=%34", &r) == TTL_ERR_VALUE);   /* no decoding: reject */
    /* enabled=1 requires a value */
    CHECK(parse("action=save&enabled=1", &r) == TTL_ERR_VALUE);
    /* disabled: value optional, remembered when valid, validated when present */
    CHECK(parse("action=apply&enabled=0", &r) == TTL_OK && !r.has_value && ttl_effective_value(&r) == 0);
    CHECK(parse("action=apply&enabled=0&value=128", &r) == TTL_OK && r.has_value && ttl_effective_value(&r) == 0);
    CHECK(parse("action=apply&enabled=0&value=999", &r) == TTL_ERR_VALUE);
    /* bad action / enabled */
    CHECK(parse("enabled=1&value=64", &r) == TTL_ERR_ACTION);
    CHECK(parse("action=delete&enabled=1&value=64", &r) == TTL_ERR_ACTION);
    CHECK(parse("action=&enabled=1&value=64", &r) == TTL_ERR_ACTION);
    CHECK(parse("action=save&value=64", &r) == TTL_ERR_ENABLED);
    CHECK(parse("action=save&enabled=2&value=64", &r) == TTL_ERR_ENABLED);
    CHECK(parse("action=save&enabled=true&value=64", &r) == TTL_ERR_ENABLED);
    /* key must match exactly, not as prefix/suffix */
    CHECK(parse("xaction=save&enabled=1&value=64", &r) == TTL_ERR_ACTION);
    CHECK(parse("action2=save&enabled=1&value=64", &r) == TTL_ERR_ACTION);
    CHECK(parse("action=save&xenabled=1&value=64", &r) == TTL_ERR_ENABLED);
    /* degenerate input */
    CHECK(parse("", &r) == TTL_ERR_ACTION);
    CHECK(parse("&&&", &r) == TTL_ERR_ACTION);
    CHECK(parse(NULL, &r) == TTL_ERR_ACTION);
    CHECK(parse("action=save", NULL) == TTL_ERR_ACTION);
    char big[300]; memset(big, 'a', sizeof(big) - 1); big[sizeof(big) - 1] = 0;
    CHECK(parse(big, &r) == TTL_ERR_ACTION);
    /* display value */
    CHECK(ttl_display_value(128, 64) == 128);
    CHECK(ttl_display_value(0, 128) == 128);
    CHECK(ttl_display_value(0, 0) == 64);
    CHECK(ttl_display_value(0, 999) == 64);
    CHECK(ttl_display_value(-5, -5) == 64);
    for (int e = 0; e <= TTL_ERR_VALUE; e++) CHECK(ttl_err_msg((ttl_err_t)e)[0] != 0);
}

#define CHIP_C3 5
static size_t make_image(uint8_t *b, size_t n, uint8_t magic, uint16_t chip, uint32_t desc_magic, const char *proj, size_t proj_len)
{
    memset(b, 0, n);
    esp_image_header_t h; memset(&h, 0, sizeof h);
    h.magic = magic; h.segment_count = 3; h.chip_id = chip;
    memcpy(b, &h, sizeof h);
    esp_app_desc_t d; memset(&d, 0, sizeof d);
    d.magic_word = desc_magic;
    memcpy(d.project_name, proj, proj_len > 32 ? 32 : proj_len);
    memcpy(b + sizeof(h) + sizeof(esp_image_segment_header_t), &d, sizeof d);
    return n;
}

static void test_validate(void)
{
    uint8_t img[4096];
    size_t min = ota_validate_min_bytes();
    CHECK(min == 24 + 8 + 256);

    make_image(img, sizeof img, 0xE9, CHIP_C3, 0xABCD5432, "esp32_nat_router", 16);
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_OK);
    CHECK(ota_validate_header(img, min, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_OK);        /* exactly min */
    CHECK(ota_validate_header(img, min - 1, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_TOO_SHORT);
    CHECK(ota_validate_header(img, 0, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_TOO_SHORT);
    CHECK(ota_validate_header(NULL, 4096, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_TOO_SHORT);
    CHECK(ota_validate_header(img, sizeof img, 0 /* ESP32 */, "esp32_nat_router", false) == OTA_HDR_WRONG_CHIP);
    CHECK(ota_validate_header(img, sizeof img, 9, "esp32_nat_router", false) == OTA_HDR_WRONG_CHIP);
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "other_project", false) == OTA_HDR_WRONG_PROJECT);
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "other_project", true) == OTA_HDR_OK);      /* force */
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, NULL, false) == OTA_HDR_OK);               /* skip check */
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_route", false) == OTA_HDR_WRONG_PROJECT); /* prefix */

    make_image(img, sizeof img, 0x00, CHIP_C3, 0xABCD5432, "esp32_nat_router", 16);               /* e.g. random data */
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_BAD_MAGIC);
    make_image(img, sizeof img, 0xE9, CHIP_C3, 0x00000000, "esp32_nat_router", 16);               /* bootloader/ptable-like */
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_NO_APP_DESC);
    /* force must NOT bypass magic/chip/app-desc checks */
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", true) == OTA_HDR_NO_APP_DESC);
    make_image(img, sizeof img, 0xE9, 9, 0xABCD5432, "esp32_nat_router", 16);
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", true) == OTA_HDR_WRONG_CHIP);

    /* 32-char project name with no NUL terminator must not be over-read */
    char p32[32]; memset(p32, 'x', 32);
    make_image(img, sizeof img, 0xE9, CHIP_C3, 0xABCD5432, p32, 32);
    CHECK(ota_validate_header(img, sizeof img, CHIP_C3, "esp32_nat_router", false) == OTA_HDR_WRONG_PROJECT);

    for (int r = 0; r <= OTA_HDR_WRONG_PROJECT; r++) {
        CHECK(ota_hdr_result_code((ota_hdr_result_t)r)[0] != 0);
        CHECK(ota_hdr_result_msg((ota_hdr_result_t)r)[0] != 0);
        CHECK(strchr(ota_hdr_result_code((ota_hdr_result_t)r), '"') == NULL);   /* safe to embed in JSON */
        CHECK(strchr(ota_hdr_result_msg((ota_hdr_result_t)r), '"') == NULL);
    }
}

int main(void)
{
    test_ttl();
    test_validate();
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
